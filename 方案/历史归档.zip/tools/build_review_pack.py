#!/usr/bin/env python3
"""Build the graduation-project review pack with the Python standard library.

This writes planning documents and illustrative contracts. It runs no image
generation, downloads no model weights, and records no real user approval.
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "方案"
VERSION = "0.1"
DATE = "2026-11-01"


SOURCES = [
    {
        "id": "MED01",
        "title": "The Lung Image Database Consortium (LIDC) and Image Database Resource Initiative (IDRI): A Completed Reference Database of Lung Nodules on CT Scans",
        "year": 2011,
        "doi": "10.1118/1.3528204",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC3041807/",
        "reviewed": "原始研究的标注流程与特征说明",
        "supports": "肺结节轮廓、位置及毛刺、分叶、球形程度、实性程度、边缘、内部结构、显著性和恶性可能性等医师评分。",
        "limits": "医师评分和影像学恶性可能性不能直接替代病理确诊；保留多医师原始分歧。",
    },
    {
        "id": "MED02",
        "title": "Fleischner Society: Glossary of Terms for Thoracic Imaging",
        "year": 2024,
        "doi": "10.1148/radiol.232558",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC10902601/",
        "reviewed": "摘要、元数据及定向术语检索；本轮未完整获取全文",
        "supports": "建立胸部影像标准术语和定义的来源。",
        "limits": "具体词条、枚举和判读规则进入实现前仍需逐条核对；不能据摘要自动填入临床阈值。",
    },
    {
        "id": "MED03",
        "title": "Structured reporting of computed tomography in the staging of colon cancer: a Delphi consensus proposal",
        "year": 2022,
        "online_year": 2021,
        "doi": "10.1007/s11547-021-01418-9",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8795004/",
        "alternate_url": "https://pubmed.ncbi.nlm.nih.gov/34741722/",
        "reviewed": "PubMed 摘要及报告部分的定向摘录；PMC 全文访问间歇受限",
        "supports": "结肠癌 CT 结构化报告中的病灶部位、类型、大小、局部侵犯、分期和转移等字段。",
        "limits": "本文提供报告字段，不证明公开分割数据集包含所有这些标签。",
    },
    {
        "id": "MED04",
        "title": "Rectal cancer lexicon 2023 revised and updated consensus statement from the Society of Abdominal Radiology Colorectal and Anal Cancer Disease-Focused Panel",
        "year": 2023,
        "doi": "10.1007/s00261-023-03893-2",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC10444656/",
        "reviewed": "原文的术语、初始分期、解剖和 MRI 序列说明",
        "supports": "直肠癌 MRI 的局部分期、壁外侵犯、MRF、淋巴结和括约肌关系等。",
        "limits": "存在适用序列、解剖定位及判读能力限制；应与更新共识核对。",
    },
    {
        "id": "MED05",
        "title": "MRI to guide clinical management of rectal cancer: updated consensus recommendations from the European Society of Gastrointestinal and Abdominal Radiology (ESGAR)—PART I primary staging",
        "year": 2026,
        "doi": "10.1007/s00330-025-12274-w",
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC13212678/",
        "reviewed": "原文主要建议、表 2 和表 3，结构化报告说明",
        "supports": "STO 定位、MRF、EMVI、淋巴结及初始分期的序列适用范围。",
        "limits": "初始分期与再分期分开；DWI 不应单独承担初始 cT、MRF 或 EMVI 判定。",
    },
    {
        "id": "DATA01",
        "title": "The Medical Segmentation Decathlon",
        "year": 2022,
        "doi": "10.1038/s41467-022-30695-9",
        "url": "https://www.nature.com/articles/s41467-022-30695-9",
        "reviewed": "原始数据说明和数据可用性",
        "supports": "肺肿瘤 CT 与结肠癌 CT 分割任务，可作为首版数据候选。",
        "limits": "当前工作区尚未下载数据；分割标签不能自动补全形态、病理、侵犯和报告标签。",
    },
    {
        "id": "DATA02",
        "title": "LIDC-IDRI collection",
        "year": None,
        "doi": "10.7937/K9/TCIA.2015.LO9QL9SX",
        "url": "https://www.cancerimagingarchive.net/collection/lidc-idri/",
        "reviewed": "TCIA 集合说明及 MED01 原始论文",
        "supports": "肺结节 CT、轮廓和多医师特征标注的候选数据。",
        "limits": "尚未下载；使用 XML 标注时需核对病例、结节、医师和标签对应关系。",
    },
    {
        "id": "DATA03",
        "title": "Towards semi-supervised multi-modal rectal cancer segmentation: A large-scale dataset and a multi-teacher uncertainty-aware network",
        "year": 2024,
        "doi": "10.1016/j.eswa.2024.124734",
        "url": "https://www.sciencedirect.com/science/article/pii/S0957417424016014",
        "repository": "https://github.com/yuqiuyuqiu/RC4",
        "reviewed": "出版者摘要和作者仓库",
        "supports": "RC4 是直肠癌 MRI 数据候选。",
        "limits": "2026-11-01 查阅仓库仅见 README 与 LICENSE，未核实可用下载入口；暂不视为已取得数据。",
    },
    {
        "id": "MOD01",
        "title": "NVIDIA NGC monai_maisi_ct_generative model description",
        "year": None,
        "url": "https://catalog.ngc.nvidia.com/orgs/nvidia/monaitoolkit/models/monai_maisi_ct_generative",
        "reviewed": "官方输入、输出、大小控制、参数优先关系和显存要求",
        "supports": "CT 与配套分割掩膜；肺部肿瘤和结肠原发癌的归一化大小控制。",
        "limits": "大小参数不等于毫米直径；有条件参数优先级；细粒度征象未获生成保证。文档描述尚未在本项目试跑。",
    },
    {
        "id": "MOD02",
        "title": "NVIDIA MAISI NIM 1.0.1 Model Details",
        "year": None,
        "url": "https://docs.nvidia.com/nim/medical/maisi/1.0.1/model-details",
        "reviewed": "官方参数、输出和测试硬件",
        "supports": "CT 三维生成接口、部分解剖大小控制及 512³ 生成的 80GB 级测试配置。",
        "limits": "NIM 与 MONAI bundle 是不同后端形态，参数取值、优先级和硬件要求分别核对。",
    },
    {
        "id": "MOD03",
        "title": "Qwen3-8B official model card",
        "year": None,
        "url": "https://huggingface.co/Qwen/Qwen3-8B",
        "reviewed": "官方模型卡",
        "supports": "需求解析与受约束文本生成的候选语言模型。",
        "limits": "本项目的医学需求解析效果尚未验证。",
    },
    {
        "id": "MOD04",
        "title": "Qwen3-VL-8B-Instruct official model card",
        "year": None,
        "url": "https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct",
        "reviewed": "官方模型卡",
        "supports": "首个图文数据格式适配对象的候选。",
        "limits": "数据可读取与医学能力有效是不同验收项；尚未训练或测评。",
    },
    {
        "id": "OPT01",
        "title": "pymoo constraint handling and multi-objective optimization documentation",
        "year": None,
        "url": "https://pymoo.org/constraints/index.html",
        "reviewed": "官方约束处理和算法目录",
        "supports": "NSGA-II 等约束多目标优化方法的实现候选。",
        "limits": "尚未验证在本任务中的生成成本、效率和适应性。",
    },
    {
        "id": "SEG01",
        "title": "nnU-Net official repository",
        "year": None,
        "url": "https://github.com/MIC-DKFZ/nnUNet",
        "reviewed": "官方仓库说明",
        "supports": "训练独立病灶分割检查器的候选工具。",
        "limits": "尚无本项目训练好的检查器；分割一致性不能单独证明医学合理性。",
    },
    {
        "id": "ENG01",
        "title": "本方案提出的工程度量与数据契约",
        "year": 2026,
        "url": None,
        "reviewed": "工程设计建议",
        "supports": "几何测量、配置字段、缺失值和状态管理的实现约定。",
        "limits": "不作为临床共识、诊断依据或原论文公式；实现后需用已知几何体和实测样本核验。",
    },
    {
        "id": "TOOL01",
        "title": "Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents",
        "authors": ["Timothy Kassis", "Vinayak Agarwal", "Yuhuan He", "Darshil Patel", "Aubrey M. Brueckner"],
        "year": 2026,
        "doi": "10.48550/arXiv.2609.00065",
        "url": "https://arxiv.org/abs/2609.00065",
        "reviewed": "arXiv 当前记录和摘要；2026-11-01 所见为 v2，引用使用无版本后缀的当前记录",
        "supports": "本次使用 literature-review 技能组织定向检索、来源核对和记录的方法出处。",
        "limits": "检索工具来源，单列说明；不作为医学特征、算法性能或临床结论的证据。",
    },
]


# These are seed entries, not a claim of exhaustive medical coverage.
# Definitions and evidence-support boundaries are deliberately separate.
FEATURE_ROWS = [
    ("META01", "工程元数据", "影像模态", "CT 或 MRI；优先读取可靠元数据，缺失时由用户确认。", "enum", "", "体积", "ENG01;MOD01;MOD02", "输入配置与元数据", "P0", "后端文档提供 CT；MRI 需其他后端", "元数据核对；PNG 缺失时不可仅凭外观确认为模态。"),
    ("META02", "工程元数据", "体积尺寸", "三个空间轴上的体素数；与空间视野共同解释。", "integer_vector", "voxel", "体积", "ENG01;MOD01;MOD02", "output_size", "P0", "后端文档提供配置，尚未试跑", "检查维度及后端支持范围；不能仅缩小体积而忽略解剖覆盖。"),
    ("META03", "工程元数据", "体素间距与仿射", "记录三维间距、方向、原点及单位；不把层厚直接当作层间距。", "geometry_metadata", "mm", "体积", "ENG01;MOD01;MOD02", "spacing 与空间元数据", "P0", "后端文档提供 spacing，尚未试跑", "核对 NIfTI 仿射与单位；DICOM 结合切片位置和方向计算。"),
    ("GEO01", "工程几何", "病灶体积", "在确认的病灶掩膜中，前景体素数乘仿射三维线性部分行列式的绝对值。", "number", "mm3", "病灶", "ENG01;MOD01", "工程度量，非临床诊断规则", "P0", "存在间接大小控制；实际体积需测量", "先验证掩膜、仿射和单位；数值不得写成已经测得。"),
    ("GEO02", "工程几何", "最大轴位长径", "按确认的轴位重建，在每个轴位轮廓上计算最长面内距离，取最大值。", "number", "mm", "病灶", "ENG01;MED01", "工程操作定义；与 MED01 面内尺寸概念相关", "P0", "存在间接大小控制；毫米范围需校准", "明确轴位、插值、边界算法和间距；该定义不自动等于 RECIST 或平均直径。"),
    ("GEO03", "工程几何", "病灶空间定位", "保存病灶掩膜、体素框和世界坐标框；裁剪或重采样后同步变换。", "geometry", "voxel/mm", "病灶", "ENG01;MED01", "轮廓与空间定位；具体坐标契约由本方案制定", "P0", "配套掩膜提供候选定位，需独立检查", "坐标必须声明轴序、原点、方向及闭区间或半开区间约定。"),
    ("GEO04", "工程几何", "目标病灶可见性", "记录目标病灶在最终图像中的可见、不可见或不确定状态。", "enum", "", "病灶", "ENG01;MED01", "标注与图像一致性检查", "P0", "候选病灶掩膜不能直接证明图像中病灶可见", "独立图像检查并人工复核首批样本；掩膜非空不直接判为阳性。"),
    ("GEO05", "工程几何", "掩膜连通域数量", "在指定连通性与最小体积规则下计算前景连通域个数。", "integer", "个", "体积", "ENG01", "工程操作定义", "P0", "掩膜产生后可计算；不承诺等于临床病灶数", "连通性、最小体积和粘连处理先确认；临床多灶性另行审核。"),
    ("LUNG01", "肺部CT", "病灶解剖部位", "按左右肺、肺叶或其他明确粒度记录位置，未知时保留未知。", "enum", "", "病灶", "MED01;MED02", "肺结节空间标注与胸部术语；细粒度词条待逐项核对", "P1", "精确肺叶控制未证实", "需要可靠肺叶分割、空间方向和定位规则；世界坐标不直接等于肺叶。"),
    ("LUNG02", "肺部CT", "实性程度与密度类型", "保留来源体系中的 solidity/texture 定义；映射到实性、部分实性等类别需单独审定。", "enum_or_ordinal", "", "病灶", "MED01;MED02", "MED01 主观特征段；术语映射待核对", "P1", "细粒度控制未证实", "保留原始医师评分及标注体系，不能未经验证将序数分直接变成临床类别。"),
    ("LUNG03", "肺部CT", "边缘清晰程度", "按原始标注或经审定定义记录边缘表现。", "ordinal", "", "病灶", "MED01", "原文 subjective characteristics 段", "P1", "精确控制未证实", "拟用真实标注建立检查器；多医师分歧保留。"),
    ("LUNG04", "肺部CT", "毛刺程度", "记录 spiculation 的来源定义和原始评分。", "ordinal", "", "病灶", "MED01", "原文 subjective characteristics 段", "P1", "精确控制未证实", "需要有标注的特征检查器及人工审核；尚不支持自动保证。"),
    ("LUNG05", "肺部CT", "分叶程度", "记录 lobulation 的来源定义和原始评分。", "ordinal", "", "病灶", "MED01", "原文 subjective characteristics 段", "P1", "精确控制未证实", "需要特征检查器与人工审核；不能仅靠生成提示词认定满足。"),
    ("LUNG06", "肺部CT", "球形程度评分", "保留来源中的主观 sphericity 评分，与数学球形度另设字段。", "ordinal", "", "病灶", "MED01", "原文 shape/sphericity 主观评分", "P1", "精确控制未证实", "主观评分不能直接用几何球形度替代。"),
    ("LUNG07", "肺部CT", "内部结构", "按来源标注记录 internal structure；枚举值需随数据版本核对。", "enum", "", "病灶", "MED01", "原文 subjective characteristics 段", "P1", "精确控制未证实", "数据集标签核对后再建立识别与生成评估。"),
    ("LUNG08", "肺部CT", "显著性评分", "记录医师对病灶显著性的主观评分。", "ordinal", "", "病灶", "MED01", "原文 subtlety 主观评分", "P1", "精确控制未证实", "不把显著性评分解释为一般图像质量评分。"),
    ("LUNG09", "肺部CT", "影像学恶性可能性评分", "保留医师影像学怀疑程度及其来源，不作为病理确诊标签。", "ordinal", "", "病灶", "MED01", "原文 likelihood of malignancy", "P2", "不作首版诊断控制目标", "需要区分影像评分、临床诊断和病理证据；缺失证据不能补写。"),
    ("COLON01", "结肠癌CT", "原发病灶部位", "按结肠解剖分段描述，分类粒度由报告模板和用户共同明确。", "enum", "", "病灶", "MED03", "Report 部分 lesion site", "P1", "支持结肠原发癌类别；精确分段控制未证实", "MSD 肿瘤掩膜不自动提供可靠结肠分段，需要额外解剖标注。"),
    ("COLON02", "结肠癌CT", "病灶形态类型", "按来源报告模板描述病灶类型，具体枚举待全文和医学审核。", "enum", "", "病灶", "MED03", "Report 部分 lesion type", "P2", "精确形态控制未证实", "不从单一肿瘤掩膜推断全部影像形态。"),
    ("COLON03", "结肠癌CT", "病灶大小", "采用明确的测量定义；初版可选择 GEO01 或 GEO02，不能混用。", "number", "mm/mm3", "病灶", "MED03;ENG01", "Report 部分 size；操作定义采用工程契约", "P0", "存在间接大小控制；需测量与校准", "用户必须选择体积或具体直径定义；不同指标的单位分别保存。"),
    ("COLON04", "结肠癌CT", "局部侵犯表现", "描述局部侵犯对象、影像证据和不确定性。", "structured", "", "病例", "MED03", "Report 部分 local invasion", "P2", "特定侵犯关系控制未证实", "需邻近结构、完整视野及医学审核；不能从肿瘤体积直接推定。"),
    ("COLON05", "结肠癌CT", "区域淋巴结评估", "记录来源定义下的区域淋巴结表现及评估状态。", "structured", "", "病例", "MED03", "Report 部分 node stage", "P2", "精确控制未证实", "需要额外淋巴结标注和评价规则；未评估不能写为阴性。"),
    ("COLON06", "结肠癌CT", "远处转移评估", "保留检查范围、可见证据和未评估状态。", "structured", "", "病例", "MED03", "Report 部分 metastases stage", "P2", "全身或特定转移控制未证实", "局部裁剪不支持完整远处转移判断；不输出无依据的 M0。"),
    ("COLON07", "结肠癌CT", "临床T分期字段", "作为复合报告字段，绑定规则版本与所需证据。", "enum", "", "病例", "MED03", "Report 部分 tumor stage", "P2", "不作首版自动生成承诺", "大小不等于侵犯深度；无法满足证据要求时仅存未评估。"),
    ("COLON08", "结肠癌CT", "临床N分期字段", "作为复合报告字段，绑定淋巴结评价证据与规则版本。", "enum", "", "病例", "MED03", "Report 部分 node stage", "P2", "不作首版自动生成承诺", "不能把分割数据中的标签缺失当作 N0。"),
    ("RECT01", "直肠癌MRI", "与乙状结肠起始部的关系", "记录病灶与 sigmoid take-off（STO）的关系及定位依据。", "structured", "", "病例", "MED04;MED05", "解剖定位与 STO 建议", "P2", "MAISI CT 后端不提供 MRI 生成", "需要足够视野、解剖定位和可用 MRI 数据。"),
    ("RECT02", "直肠癌MRI", "肿瘤高度", "说明测量起点、终点和所采用的解剖参照；不同参照不混用。", "number", "mm", "病灶", "MED04;MED05", "解剖术语与 tumour height 讨论", "P2", "需要 MRI 后端", "肛缘和肛直肠交界等参照需显式区分并标注。"),
    ("RECT03", "直肠癌MRI", "壁外侵犯深度", "在明确肠壁层次和测量规则下记录壁外侵犯程度。", "number", "mm", "病灶", "MED04", "T3 subclassification 与 extramural invasion", "P2", "需要 MRI 后端和关系控制", "需要肠壁结构证据；不从包围框估算侵犯深度。"),
    ("RECT04", "直肠癌MRI", "与直肠系膜筋膜的最短距离", "记录距离及其对应对象，区分原发灶、EMVI、结节等来源。", "structured", "mm", "病例", "MED04;MED05", "MRF 建议及更新", "P2", "需要 MRI 后端和多结构控制", "距离、相关对象与规则版本共同保存；不使用一个距离字段替代全部判定。"),
    ("RECT05", "直肠癌MRI", "MRF受累状态", "依据明确版本的规则结合相关结构判读，保存不确定性。", "enum", "", "病例", "MED05", "表 2 和表 3 MRF 规则", "P2", "不作首版自动生成承诺", "当前仅列字段；规则细节需医学审核，不能单靠 DWI 判定。"),
    ("RECT06", "直肠癌MRI", "壁外血管侵犯", "记录 EMVI 的影像表现、等级或状态及其依据。", "structured", "", "病例", "MED04;MED05", "EMVI 与序列适用性建议", "P2", "精确控制未证实，需 MRI 后端", "保留所用规则；初始分期不能单靠 DWI 判定。"),
    ("RECT07", "直肠癌MRI", "区域淋巴结风险评估", "按当前共识记录 cN 相关影像评估及可信程度。", "structured", "", "病例", "MED04;MED05", "淋巴结分期和不确定性", "P2", "精确控制未证实，需 MRI 后端", "分区、形态和病例层面评估分开记录；不能只按尺寸自动确诊。"),
    ("RECT08", "直肠癌MRI", "腹膜反折相关关系", "描述原发灶与腹膜反折及腹膜侵犯相关表现。", "structured", "", "病例", "MED04;MED05", "T4a 与 peritoneal reflection 说明", "P2", "关系控制未证实，需 MRI 后端", "需要完整解剖视野和结构标注。"),
    ("RECT09", "直肠癌MRI", "括约肌及邻近结构关系", "区分相关肌层或邻近结构，按来源定义描述受累证据。", "structured", "", "病例", "MED04", "external sphincter 与 T4b 相关说明", "P2", "关系控制未证实，需 MRI 后端", "需医学审核和多结构标注；不由文字提示直接生成确诊标签。"),
    ("RECT10", "直肠癌MRI", "DWI与ADC相关表现", "在配准的序列及已知采集参数下描述信号表现和适用任务。", "structured", "", "病例", "MED04;MED05", "MRI sequence utility 与 DWI 限制", "P2", "多序列 MRI 后端待选", "不同序列需对应；该字段不能单独替代初始 cT、MRF 或 EMVI 判定。"),
]

FEATURE_KEYS = [
    "feature_id", "category", "name", "operational_definition", "value_type",
    "unit", "assessment_level", "source_ids", "evidence_locator", "planned_stage",
    "generation_support", "evaluation_plan",
]
FEATURES = [dict(zip(FEATURE_KEYS, row)) | {"implementation_status": "planned_not_implemented"}
            for row in FEATURE_ROWS]


ACCEPTANCE_ROWS = [
    ("A01", "需求提取", "输入含癌种、模态、数量和大小范围的文本", "提取值、单位、来源原文；未说明项保持待确认", "展示文本与结构化字段对照", "P0"),
    ("A02", "默认参数", "缺少分辨率、保存格式或并发数", "逐项展示默认建议；每项均有独立确认状态", "默认项清单及交互事件", "P0"),
    ("A03", "确认门禁", "任一默认项未确认", "禁止启动生成；展示未确认项", "后端拒绝记录，不能只禁用按钮", "P0"),
    ("A04", "用户修改", "修改某指标的范围、单位或优先级", "检查变更并生成新需求版本，旧编译结果失效", "版本差异与编译版本", "P0"),
    ("A05", "指标删除", "删除一个软目标", "目标列表中同步删除；依赖该项的配置重新校验", "前后模型预览", "P0"),
    ("A06", "指标新增", "增加毛刺程度等尚未验证的指标", "允许记录为待支持，禁止直接承诺满足或执行硬约束", "能力状态及明确反馈", "P0"),
    ("A07", "数值冲突", "要求直径下限大于上限", "拒绝确认并定位到冲突字段", "校验结果", "P0"),
    ("A08", "计数冲突", "目标合格数高于交付数量上限", "拒绝启动，要求调整目标或上限", "后端语义校验", "P0"),
    ("A09", "分布约束", "同一互斥类别组比例不合计为100%", "提示缺额或超额；不能自动改写用户比例", "类别组与校验结果", "P0"),
    ("A10", "共现特征", "毛刺和分叶可同时存在，比例之和超过100%", "不按互斥类别误报；按各特征定义验证可满足性", "共现关系与校验结果", "P0"),
    ("A11", "单位", "毫米与体素混用且缺失空间信息", "停止该测量或约束求值；不得假设1体素等于1毫米", "缺失信息与未评估状态", "P0"),
    ("A12", "空间变换", "影像裁剪、重采样或旋转", "掩膜、框、仿射和导出切片坐标同步更新", "已知几何体核验结果", "P0"),
    ("A13", "生成标注", "生成器给出非空掩膜但图像中病灶不明确", "进入待复核或剔除；不直接作为可见阳性入库", "独立检查和复核结果", "P0"),
    ("A14", "图文一致性", "文字出现属性记录中没有的分期或尺寸", "拦截并修订文字，保留原因", "属性与文本核对记录", "P0"),
    ("A15", "数量上限", "合格目标数与候选尝试预算分别到达", "目标满足则完成；预算先耗尽则报告缺口并停止", "计数和结束原因", "P0"),
    ("A16", "失败恢复", "单次生成失败或进程中断", "在预算和用户确认的恢复规则内重试；不重复计入已导出的样本", "任务与样本账本", "P0"),
    ("A17", "数据划分", "同患者切片或同源编辑样本跨训练集和测试集", "按来源组阻止交叉；测试集保留真实独立来源", "来源组和划分清单", "P0"),
    ("A18", "导出", "导出影像、掩膜、文本和质量记录", "文件完整、关联可解析、单位和坐标可还原", "manifest与导出包检查", "P0"),
    ("A19", "默认后端差异", "把MONAI bundle参数直接传入NIM后端", "按后端版本检查参数、优先级和不支持项", "后端能力表及配置快照", "P0"),
    ("A20", "缺失值", "未评价淋巴结或转移", "保存not_assessed或unknown；禁止自动写成N0、M0或阴性", "属性和文本核对", "P0"),
    ("A21", "动态模型", "把一个指标由软目标改为硬约束，并新增另一指标", "目标集合、约束集合和求值接口均相应改变", "两份模型规范及追踪表", "P0"),
    ("A22", "生成算法比较", "在相同候选预算下运行随机基线与优化方法", "报告有效率、约束满足率、耗时和复核结果，不预设优化获胜", "固定配置、日志与对照结果", "P1"),
    ("A23", "形态特征", "启用毛刺或分叶的自动检查", "先完成真实标注验证并报告医师分歧，之后才放开相关能力", "验证集、指标与能力版本", "P1"),
    ("A24", "MRI扩展", "配置直肠癌MRI任务而仅安装CT生成后端", "展示可记录需求与缺失生成能力；禁止把CT结果标为MRI", "模态和后端检查", "P2"),
]


DEFAULTS = [
    ("图像体积尺寸", [512, 512, 256], "voxel", "尺寸与间距共同决定视野；需试跑检查完整解剖覆盖。"),
    ("体素间距", [1.0, 1.0, 2.0], "mm", "为CT首版配置建议，非临床扫描规范。"),
    ("标注粒度", "病灶体素掩膜及派生定位框", "", "配套掩膜仍需与图像核对。"),
    ("文本语言", "zh-CN", "", "可改为英文或其他输出约定。"),
    ("文本标签", "可验证属性JSON及中文征象短句", "", "报告诊断与分期字段另行启用。"),
    ("保存格式", ["NIfTI", "JSONL", "CSV"], "", "PNG切片导出作为可选项，保留医学主文件。"),
    ("生成并发数", 1, "任务", "试跑后按显存和资源上限调整。"),
    ("阳性样本比例", 1.0, "ratio", "这里的阳性指目标病灶可见，不等于病理确诊癌症。"),
    ("阴性样本比例", 0.0, "ratio", "首版不自动构造健康患者标签；调整时明确阴性定义。"),
    ("交付数量上限", 20, "volume", "示例建议，独立于候选尝试预算。"),
    ("候选生成预算", 100, "candidate_volume", "每个候选体积计一次；后端内部重试另记账并受资源预算限制。"),
    ("生成后端", "MAISI MONAI bundle 候选，版本待试跑锁定", "", "本建议不将MONAI bundle和NIM参数视为同一接口。"),
]


def make_example():
    text = "生成20份肺部肿瘤CT三维图文样本，病灶最大轴位长径10到20毫米，文字描述可见征象和病灶位置。"
    def item(rid, label, key, value, unit, kind, origin, quote, feature=None, limitation="需实现并验证后启用"):
        return {
            "id": rid, "label": label, "key": key, "kind": kind, "feature_id": feature,
            "value": value, "unit": unit,
            "provenance": {"kind": origin, "quote": quote, "note": "本文件为作者编写的需求示例"},
            "review": {"state": "pending", "action": None, "event_id": None,
                       "confirmed_at": None, "revision": 1},
            "capability": {"state": "planned_unvalidated", "note": limitation},
        }
    reqs = [
        item("REQ01", "任务分支", "task_branch", "lung_tumor_ct", "", "parameter",
             "example_user_text", "肺部肿瘤CT", limitation="候选模型含肺部肿瘤类别；本项目尚未试跑"),
        item("REQ02", "目标合格数量", "target_accepted_count", 20, "volume", "dataset_constraint",
             "example_user_text", "20份"),
        item("REQ03", "最大轴位长径", "max_axial_diameter_mm", {"min": 10.0, "max": 20.0},
             "mm", "hard_constraint", "example_user_text", "最大轴位长径10到20毫米",
             "GEO02", "归一化大小参数需校准到测量结果；毫米硬约束能力尚未验证"),
        item("REQ04", "输出任务", "text_task", "visible_findings_and_location", "",
             "parameter", "example_user_text", "文字描述可见征象和病灶位置"),
        item("REQ05", "样本计数单位", "sample_unit", "volume", "", "parameter",
             "example_user_text", "三维图文样本"),
    ]
    default_keys = [
        "output_size", "spacing_mm", "annotation_granularity", "text_language",
        "text_label_format", "save_formats", "generation_concurrency",
        "visible_lesion_fraction", "non_visible_target_fraction", "output_count_cap",
        "candidate_budget", "generation_backend",
    ]
    for n, ((label, value, unit, note), key) in enumerate(zip(DEFAULTS, default_keys), 6):
        reqs.append(item(f"REQ{n:02}", label, key, value, unit, "parameter",
                         "default_proposal", "", limitation=note))
    return {
        "schema_version": VERSION,
        "is_example": True,
        "workflow_status": "draft",
        "execution_authorized": False,
        "request_id": "illustrative-lung-ct-001",
        "revision": 1,
        "raw_request": text,
        "requirements": reqs,
        "distribution_constraints": [],
        "compiler_preview": {
            "state": "proposal_not_executable",
            "generator": "MAISI candidate; exact backend and weight version not locked",
            "decision_variables": [
                {"id": "relative_tumor_size", "domain": "[0,1]",
                 "note": "文档中的归一化大小控制，非毫米值"},
                {"id": "seed_or_noise", "domain": "backend-dependent",
                 "note": "需后端支持；评估时固定种子集合或记录重复采样"},
            ],
            "objectives": [],
            "constraints": [
                {"requirement_id": "REQ03", "evaluator_id": "GEO02",
                 "expression": "10 - d(x,m,A) <= 0; d(x,m,A) - 20 <= 0",
                 "state": "planned_unvalidated"},
            ],
            "notes": "该示例只声明大小硬约束，没有替用户添加医学质量评分或任意软目标；工程质量检查仍需配置与验证。",
        },
        "approval_snapshot": None,
        "blockers": [
            "这是作者编写的示例，不是真实已确认任务",
            "所有需求和默认项均未确认",
            "生成后端、模型权重和资源配置未锁定或试跑",
            "毫米测量、图像掩膜检查与医学复核流程未验证",
        ],
    }


def make_schema():
    nullable_string = {"type": ["string", "null"]}
    review = {
        "type": "object", "additionalProperties": False,
        "required": ["state", "action", "event_id", "confirmed_at", "revision"],
        "properties": {
            "state": {"enum": ["pending", "confirmed", "needs_revision"]},
            "action": {"enum": [None, "confirm", "modify_and_confirm", "acknowledge", "request_change"]},
            "event_id": nullable_string,
            "confirmed_at": {"anyOf": [{"type": "null"}, {"type": "string", "format": "date-time"}]},
            "revision": {"type": "integer", "minimum": 1},
        },
        "allOf": [{
            "if": {"properties": {"state": {"const": "confirmed"}}, "required": ["state"]},
            "then": {"properties": {
                "action": {"enum": ["confirm", "modify_and_confirm", "acknowledge"]},
                "event_id": {"type": "string", "minLength": 1},
                "confirmed_at": {"type": "string", "format": "date-time"},
            }},
        }],
    }
    field = {
        "type": "object", "additionalProperties": False,
        "required": ["id", "label", "key", "kind", "feature_id", "value", "unit",
                     "provenance", "review", "capability"],
        "properties": {
            "id": {"type": "string", "pattern": "^REQ[0-9]{2,}$"},
            "label": {"type": "string", "minLength": 1},
            "key": {"type": "string", "minLength": 1},
            "kind": {"enum": ["parameter", "hard_constraint", "soft_objective", "dataset_constraint"]},
            "feature_id": {"enum": [None] + [f["feature_id"] for f in FEATURES]},
            "value": {},
            "unit": {"type": "string"},
            "provenance": {
                "type": "object", "additionalProperties": False,
                "required": ["kind", "quote", "note"],
                "properties": {
                    "kind": {"enum": ["example_user_text", "user_text", "default_proposal", "derived", "medical_source"]},
                    "quote": {"type": "string"}, "note": {"type": "string"},
                },
            },
            "review": review,
            "capability": {
                "type": "object", "additionalProperties": False, "required": ["state", "note"],
                "properties": {
                    "state": {"enum": ["planned_unvalidated", "supported_validated", "unsupported"]},
                    "note": {"type": "string"},
                },
            },
        },
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "医学读片数据生成任务需求确认契约草案",
        "description": "结构契约；不是已经实现的后端。语义冲突、能力真实性与真实交互事件须由后端另外核验。",
        "type": "object", "additionalProperties": False,
        "required": ["schema_version", "is_example", "workflow_status", "execution_authorized",
                     "request_id", "revision", "raw_request", "requirements",
                     "distribution_constraints", "compiler_preview", "approval_snapshot", "blockers"],
        "properties": {
            "schema_version": {"const": VERSION},
            "is_example": {"type": "boolean"},
            "workflow_status": {"enum": ["draft", "review_pending", "approved_for_pilot"]},
            "execution_authorized": {"type": "boolean"},
            "request_id": {"type": "string", "minLength": 1},
            "revision": {"type": "integer", "minimum": 1},
            "raw_request": {"type": "string", "minLength": 1},
            "requirements": {"type": "array", "minItems": 1, "items": field},
            "distribution_constraints": {
                "type": "array",
                "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["group_id", "feature_id", "selector", "group_kind", "sample_unit",
                                 "target_fraction", "absolute_tolerance", "provenance", "review",
                                 "capability"],
                    "properties": {
                        "group_id": {"type": "string", "minLength": 1},
                        "feature_id": {"enum": [f["feature_id"] for f in FEATURES]},
                        "selector": {
                            "type": "object", "additionalProperties": False,
                            "required": ["operator", "value"],
                            "properties": {
                                "operator": {"enum": ["equals", "interval", "present", "exists"]},
                                "value": {},
                            },
                            "description": "区间端点的开闭及单位须在value内明确，并由后端语义校验。",
                        },
                        "group_kind": {"enum": ["mutually_exclusive", "cooccurring"]},
                        "sample_unit": {"enum": ["volume", "lesion", "slice"]},
                        "target_fraction": {"type": "number", "minimum": 0, "maximum": 1},
                        "absolute_tolerance": {"type": "number", "minimum": 0, "maximum": 1},
                        "provenance": copy.deepcopy(field["properties"]["provenance"]),
                        "review": review,
                        "capability": copy.deepcopy(field["properties"]["capability"]),
                    },
                },
            },
            "compiler_preview": {
                "type": "object",
                "required": ["state", "generator", "decision_variables", "objectives", "constraints", "notes"],
                "properties": {
                    "state": {"enum": ["proposal_not_executable", "validated_compilation"]},
                    "generator": {"type": "string"}, "decision_variables": {"type": "array"},
                    "objectives": {"type": "array"}, "constraints": {"type": "array"},
                    "notes": {"type": "string"},
                },
                "additionalProperties": False,
            },
            "approval_snapshot": {
                "anyOf": [
                    {"type": "null"},
                    {
                        "type": "object", "additionalProperties": False,
                        "required": ["requirement_revision", "canonical_sha256", "event_id"],
                        "properties": {
                            "requirement_revision": {"type": "integer", "minimum": 1},
                            "canonical_sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
                            "event_id": {"type": "string", "minLength": 1},
                        },
                    },
                ],
            },
            "blockers": {"type": "array", "items": {"type": "string"}},
        },
        "allOf": [
            {
                "if": {"properties": {"workflow_status": {"const": "approved_for_pilot"}},
                       "required": ["workflow_status"]},
                "then": {"properties": {
                    "is_example": {"const": False}, "execution_authorized": {"const": True},
                    "requirements": {"items": {"properties": {
                        "review": {"properties": {"state": {"const": "confirmed"}}},
                        "capability": {"properties": {"state": {"const": "supported_validated"}}},
                    }}},
                    "distribution_constraints": {"items": {"properties": {
                        "review": {"properties": {"state": {"const": "confirmed"}}},
                        "capability": {"properties": {"state": {"const": "supported_validated"}}},
                    }}},
                    "compiler_preview": {"properties": {"state": {"const": "validated_compilation"}}},
                    "approval_snapshot": {"type": "object"}, "blockers": {"maxItems": 0},
                }},
            },
            {
                "if": {"properties": {"workflow_status": {"enum": ["draft", "review_pending"]}},
                       "required": ["workflow_status"]},
                "then": {"properties": {"execution_authorized": {"const": False}}},
            },
        ],
    }


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# A small native OOXML writer keeps the review document editable in Word/WPS
# without depending on a converter or unverified HTML-to-Word rendering.
NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "pr": "http://schemas.openxmlformats.org/package/2006/relationships",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
}
ET.register_namespace("w", NS["w"])
ET.register_namespace("r", NS["r"])


def q(name):
    prefix, local = name.split(":", 1)
    return "{" + NS[prefix] + "}" + local


def el(name, attrs=None, text=None):
    attrs = {q(k) if ":" in k else k: str(v) for k, v in (attrs or {}).items()}
    node = ET.Element(q(name), attrs)
    if text is not None:
        node.text = text
    return node


class Word:
    def __init__(
        self,
        title="医学读片图文训练数据生成工具毕业设计实施方案导师审核稿",
        subject="课题边界、特征依据、需求审核、动态建模和实施验收",
        header="医学读片图文训练数据生成工具  /  导师审核稿",
    ):
        self.title = title
        self.subject = subject
        self.header = header
        self.root = el("w:document")
        self.body = ET.SubElement(self.root, q("w:body"))
        self.links = []
        self.plaintext = []

    def run(self, parent, text, bold=False, color=None, size=None):
        r = ET.SubElement(parent, q("w:r"))
        if bold or color or size:
            pr = ET.SubElement(r, q("w:rPr"))
            if bold:
                pr.append(el("w:b"))
            if color:
                pr.append(el("w:color", {"w:val": color}))
            if size:
                pr.append(el("w:sz", {"w:val": size}))
        for i, part in enumerate(str(text).split("\n")):
            if i:
                r.append(el("w:br"))
            t = ET.SubElement(r, q("w:t"))
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            t.text = part
        return r

    def p(self, text="", style=None, bold=False, parent=None):
        p = ET.SubElement(self.body if parent is None else parent, q("w:p"))
        if style:
            props = ET.SubElement(p, q("w:pPr"))
            props.append(el("w:pStyle", {"w:val": style}))
        self.run(p, text, bold=bold)
        self.plaintext.append(str(text))
        return p

    def h(self, title):
        return self.p(title, "Heading1")

    def bullet(self, text):
        return self.p("• " + text, "ListParagraph")

    def table(self, headers, rows, widths=None):
        widths = widths or [9200 // len(headers)] * len(headers)
        widths[-1] += 9200 - sum(widths)
        t = ET.SubElement(self.body, q("w:tbl"))
        pr = ET.SubElement(t, q("w:tblPr"))
        pr.append(el("w:tblW", {"w:w": 9200, "w:type": "dxa"}))
        pr.append(el("w:tblLayout", {"w:type": "fixed"}))
        borders = ET.SubElement(pr, q("w:tblBorders"))
        for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
            borders.append(el("w:" + edge, {"w:val": "single", "w:sz": 4, "w:color": "C9D1D9"}))
        margins = ET.SubElement(pr, q("w:tblCellMar"))
        for edge in ["top", "left", "bottom", "right"]:
            margins.append(el("w:" + edge, {"w:w": 90, "w:type": "dxa"}))
        grid = ET.SubElement(t, q("w:tblGrid"))
        for width in widths:
            grid.append(el("w:gridCol", {"w:w": width}))
        for idx, row in enumerate([headers, *rows]):
            tr = ET.SubElement(t, q("w:tr"))
            trpr = ET.SubElement(tr, q("w:trPr"))
            trpr.append(el("w:cantSplit"))
            if idx == 0:
                trpr.append(el("w:tblHeader"))
            for width, value in zip(widths, row):
                tc = ET.SubElement(tr, q("w:tc"))
                tcpr = ET.SubElement(tc, q("w:tcPr"))
                tcpr.append(el("w:tcW", {"w:w": width, "w:type": "dxa"}))
                if idx == 0:
                    tcpr.append(el("w:shd", {"w:fill": "EAF1F7"}))
                self.p(value, "TableText", bold=(idx == 0), parent=tc)
        self.p("")

    def link(self, label, url):
        p = ET.SubElement(self.body, q("w:p"))
        pp = ET.SubElement(p, q("w:pPr"))
        pp.append(el("w:pStyle", {"w:val": "Reference"}))
        rid = f"rIdLink{len(self.links) + 1}"
        h = ET.SubElement(p, q("w:hyperlink"), {q("r:id"): rid})
        self.run(h, label, color="205781")
        self.links.append((rid, url))
        self.plaintext.append(label + " " + url)

    def save(self, path):
        sect = ET.SubElement(self.body, q("w:sectPr"))
        sect.append(el("w:headerReference", {"w:type": "default", "r:id": "rIdHeader"}))
        sect.append(el("w:footerReference", {"w:type": "default", "r:id": "rIdFooter"}))
        sect.append(el("w:pgSz", {"w:w": 11906, "w:h": 16838}))
        sect.append(el("w:pgMar", {"w:top": 1247, "w:right": 1353, "w:bottom": 1247,
                                  "w:left": 1353, "w:header": 567, "w:footer": 567, "w:gutter": 0}))

        styles = el("w:styles")
        defaults = ET.SubElement(styles, q("w:docDefaults"))
        rp = ET.SubElement(ET.SubElement(defaults, q("w:rPrDefault")), q("w:rPr"))
        rp.append(el("w:rFonts", {"w:ascii": "Calibri", "w:hAnsi": "Calibri", "w:eastAsia": "宋体"}))
        rp.append(el("w:sz", {"w:val": 22}))
        rp.append(el("w:lang", {"w:val": "zh-CN", "w:eastAsia": "zh-CN"}))
        pp = ET.SubElement(ET.SubElement(defaults, q("w:pPrDefault")), q("w:pPr"))
        pp.append(el("w:spacing", {"w:after": 100, "w:line": 300, "w:lineRule": "auto"}))
        pp.append(el("w:widowControl"))
        for sid, size, bold, color in [
            ("Normal", 22, False, "172B3A"),
            ("Title", 36, True, "17374F"),
            ("Subtitle", 22, False, "536775"),
            ("Heading1", 27, True, "17374F"),
            ("ListParagraph", 22, False, "172B3A"),
            ("TableText", 19, False, "172B3A"),
            ("Reference", 18, False, "536775"),
        ]:
            st = el("w:style", {"w:type": "paragraph", "w:styleId": sid})
            if sid == "Normal":
                st.set(q("w:default"), "1")
            st.append(el("w:name", {"w:val": sid}))
            if sid != "Normal":
                st.append(el("w:basedOn", {"w:val": "Normal"}))
            rpr = ET.SubElement(st, q("w:rPr"))
            rpr.append(el("w:sz", {"w:val": size}))
            rpr.append(el("w:color", {"w:val": color}))
            if bold:
                rpr.append(el("w:b"))
                rpr.append(el("w:rFonts", {"w:eastAsia": "黑体"}))
            ppr = ET.SubElement(st, q("w:pPr"))
            if sid in {"Heading1", "Title", "Subtitle"}:
                ppr.append(el("w:keepNext"))
            if sid == "Heading1":
                ppr.append(el("w:outlineLvl", {"w:val": 0}))
                ppr.append(el("w:spacing", {"w:before": 220, "w:after": 120}))
            if sid == "ListParagraph":
                ppr.append(el("w:ind", {"w:left": 220, "w:hanging": 150}))
            if sid in {"TableText", "Reference"}:
                ppr.append(el("w:spacing", {"w:after": 55, "w:line": 260, "w:lineRule": "auto"}))
            styles.append(st)

        header = el("w:hdr")
        hp = ET.SubElement(header, q("w:p"))
        hpp = ET.SubElement(hp, q("w:pPr"))
        hpp.append(el("w:pStyle", {"w:val": "Reference"}))
        self.run(hp, self.header)
        footer = el("w:ftr")
        fp = ET.SubElement(footer, q("w:p"))
        fpp = ET.SubElement(fp, q("w:pPr"))
        fpp.append(el("w:jc", {"w:val": "center"}))
        field = ET.SubElement(fp, q("w:fldSimple"), {q("w:instr"): "PAGE"})
        self.run(field, "1", size=18)

        rels = ET.Element("Relationships", {"xmlns": NS["pr"]})
        for rid, kind, target in [
            ("rIdStyles", "styles", "styles.xml"),
            ("rIdHeader", "header", "header1.xml"),
            ("rIdFooter", "footer", "footer1.xml"),
        ]:
            ET.SubElement(rels, "Relationship", {
                "Id": rid, "Type": NS["r"] + "/" + kind, "Target": target})
        for rid, url in self.links:
            ET.SubElement(rels, "Relationship", {
                "Id": rid, "Type": NS["r"] + "/hyperlink", "Target": url, "TargetMode": "External"})
        rootrels = ET.Element("Relationships", {"xmlns": NS["pr"]})
        for rid, kind, target in [
            ("rIdDocument", NS["r"] + "/officeDocument", "word/document.xml"),
            ("rIdCore", "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml"),
            ("rIdApp", NS["r"] + "/extended-properties", "docProps/app.xml"),
        ]:
            ET.SubElement(rootrels, "Relationship", {"Id": rid, "Type": kind, "Target": target})
        types = ET.Element("Types", {"xmlns": NS["ct"]})
        for ext, mime in [
            ("rels", "application/vnd.openxmlformats-package.relationships+xml"),
            ("xml", "application/xml"),
        ]:
            ET.SubElement(types, "Default", {"Extension": ext, "ContentType": mime})
        for part, mime in [
            ("/word/document.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"),
            ("/word/styles.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"),
            ("/word/header1.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"),
            ("/word/footer1.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"),
            ("/docProps/core.xml", "application/vnd.openxmlformats-package.core-properties+xml"),
            ("/docProps/app.xml", "application/vnd.openxmlformats-officedocument.extended-properties+xml"),
        ]:
            ET.SubElement(types, "Override", {"PartName": part, "ContentType": mime})
        core = ET.Element("{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}coreProperties")
        for name, text in [
            ("title", self.title),
            ("subject", self.subject),
            ("creator", "毕业设计工作区"),
        ]:
            ET.SubElement(core, "{http://purl.org/dc/elements/1.1/}" + name).text = text
        app = ET.Element("Properties", {"xmlns": "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"})
        ET.SubElement(app, "Application").text = "Graduation project review pack"
        parts = {
            "[Content_Types].xml": types, "_rels/.rels": rootrels,
            "word/document.xml": self.root, "word/styles.xml": styles,
            "word/header1.xml": header, "word/footer1.xml": footer,
            "word/_rels/document.xml.rels": rels,
            "docProps/core.xml": core, "docProps/app.xml": app,
        }
        with ZipFile(path, "w", ZIP_DEFLATED) as z:
            for name, node in parts.items():
                z.writestr(name, ET.tostring(node, encoding="utf-8", xml_declaration=True))


def build_document(document_version=None, include_subtask=False, literature_plan_mode="weekly", architecture_plan=None):
    pi_selected = architecture_plan is not None
    acceptance_count = architecture_plan["acceptance_count"] if pi_selected else len(ACCEPTANCE_ROWS)
    d = Word()
    d.p("医学读片图文训练数据生成工具", "Title")
    d.p("毕业设计实施方案  导师审核稿", "Subtitle")
    d.p(f"版本 {document_version or VERSION}    日期 {DATE}    状态：方案草案，尚未进行模型试跑", "Reference")
    d.p("建议课题名称：基于智能体动态优化建模的医学读片图文训练数据生成方法与系统。")
    d.p("面向医学读片大模型的数据制备，将少量参考影像和文字要求转成可审核的结构化需求，经用户修改与确认后，形成适配当前任务的优化目标、约束和生成配置，最终生成、检查并交付图文训练数据。")
    d.p("当前工作以肺部肿瘤 CT 和结肠癌 CT 的可测量特征为首批验证建议，保留直肠癌 MRI 扩展。生成模型、参数和数量安排均为待试跑及导师审核的建议；本材料没有产生医学影像数据或记录真实生成任务的参数确认。")
    if pi_selected:
        d.p("用户已确认采用Pi作为总课题及T1的智能体基座。生成需求参数确认由T2的独立前置模块完成，再输入Pi建模节点；T1直接接收论文，不设置逐项参数确认。界面、校验、解析和生成算法可由普通程序实现，Skill按需使用。业务存储与权限由项目自身负责，pi-durable不是必选依赖。Pi的具体接入方式和发布版本在接入阶段确定，其他模型与算法仍为候选。")
    if include_subtask:
        d.p("当前优先子任务为T1：医学论文肿瘤视觉特征文本提取智能体。它落实医学特征文字来自权威文献的来源环节，为后续特征整理、用户需求审核和动态建模提供可追溯文本。T1的文献范围可包含CT和MRI，不以MRI生成能力或三维生成算力为前提。")
        if literature_plan_mode == "stage_gated":
            d.p("T1面向持续新增的肿瘤相关医学论文，论文题名、癌种和术语不写死。此前举例的论文和肺部/结直肠文献仅用于启动和验证，不是输入白名单。T1按阶段成果验收推进，取消按工期或固定论文数量推进。首版已确认用户上传公开已发表PDF，逐篇交互并渐进展示候选及全文进度；面向国内用户，可租云服务器、调用付费LLM API并优先Docker，预算暂不约束。模态与语言边界、具体资源和质量性能门槛继续共同讨论。")

    d.h("一 课题依据与范围")
    d.table(["类别", "内容"], [
        ["导师要求", "少量参考影像、任务输入输出、特征说明、分布和数量要求、模型架构信息；默认项逐项交互确认；批量生成、筛选、下载或拷贝导出。"],
        ["研究主线", ("T1文献证据提取 → T2特征整理及需求审核与建模 → T3约束驱动生成 → T4筛选与交付；T5完成系统集成和验证。" if include_subtask else "医学文字要求 → 结构化需求 → 用户审核 → 动态优化模型 → 算法适配与生成 → 按原要求筛选 → 训练数据交付。")],
        ["用户明确的范围", "先考虑肠癌和肺癌，影像范围为放射学影像；考虑 CT、MRI，后续扩展癌种和特征。"],
        ["首版实施建议", "先验证肺部肿瘤 CT、结肠癌 CT；MRI 先进入需求与特征模型，取得数据并选定 MRI 生成后端后再进入生成验证。"],
        ["两篇候选论文", "TPARMI/可能的 TPAMI 与 TEVC 均不足以唯一识别具体论文；身份待补充。不能将相似论文当作原论文，也不预先保证80%—90%的复用比例。"],
    ], [1700, 7500])
    if include_subtask:
        d.table(["任务", "职责与交付", "依赖关系"], [
            ["T1 当前优先", "论文中的肿瘤视觉特征原文、出处、上下文和审核结果；详见子任务T1专项开发计划", "可独立启动，不依赖两篇生成算法论文或影像生成后端"],
            ["T2", "整理文献与医生口述的特征，审核用户需求并形成动态数学模型", "接收T1已审核证据；医生口述仍是独立输入来源"],
            ["T3", "根据模型选择或适配生成算法，产生候选影像与标注", "依赖T2的可执行模型和明确生成能力"],
            ["T4", "检查图文对应和分布，筛选并导出数据", "依赖T2的检查规则与T3的候选样本"],
            ["T5", "将各模块集成为交互工具并开展整体效果验证", "分阶段接入T1—T4，最终完成整体交付"],
        ], [1700, 4800, 2700])
        d.p("T1提供证据容器中的结构化字段，不自动产生已经医学确认的特征规范或数学约束；这部分属于T2。T1前端审核的是原文和证据，T2前端审核的是用户任务及其目标、约束，两种审核各自保留记录。")
    d.p("首版输出任务为病灶定位、可见影像征象和结构化描述。诊断、分级和临床分期作为需要证据与规则的扩展任务。有限特征字典用于限定需求语言与评价接口，不意味着连续影像空间的搜索或三维生成成本自动可控。")

    d.h("二 交付成果与当前状态")
    d.table(["成果", "用途", "当前状态"], [
        ["实施方案", "供导师审阅范围、技术路线与取舍", "本稿"],
        *([["T1子任务开发计划",
             ("跨肿瘤论文抽取、阶段验收、开源候选调研及待讨论实现决策" if literature_plan_mode == "stage_gated" else "论文文本提取智能体的范围、流程、四周排期和验收"),
             ("Pi已选定；其余组件与验收门槛待讨论，尚未开发" if pi_selected else ("修订讨论稿；技术选型与验收门槛待讨论，尚未开发" if literature_plan_mode == "stage_gated" else "计划已制定，智能体尚未开发"))]] if include_subtask else []),
        [f"首批特征字典 {len(FEATURES)} 项", "区分医学术语、工程度量、来源、生成与评价能力", "草案，见配套 CSV/JSON"],
        ["需求确认契约和示例", "指导前后端字段、交互和版本绑定", "结构草案，示例不可执行"],
        [f"验收清单 {acceptance_count} 项", "用于后续开发与检查", "尚未逐项实施验收"],
        ["生成与筛选系统", "实际生成图文训练数据", "待开发与试跑"],
    ], [2500, 4300, 2400])
    d.p("已有检索和文献元数据保存在 research 目录。当前未下载数据集、模型权重，也未训练分割器或特征识别器；所有候选能力须经过实际验证后更新状态。")
    if pi_selected:
        d.p("Pi与业务模块的职责", bold=True)
        d.table(["模块", "实现责任", "交付边界"], architecture_plan["module_rows"], [2000, 3300, 3900])
        d.p("已选定的是Pi的智能体运行能力。SDK或RPC、具体版本、PDF解析器、LLM、数据库和前端技术分别在对应阶段确定；不把Skill作为所有功能的强制封装方式。LangGraph等保留为架构参考，当前不再与Pi并列竞选主基座。")
        d.p("权限配置与业务存储均作为应用开发工作。仅向Pi开放任务所需工具、文件目录和服务；首次集成就验证越界访问被阻止，具体目录、网络与凭证范围随选定服务形成配置。")

    d.h("三 首批特征与能力分层")
    d.p("特征库同时记录医学意义与工程操作定义。来源支持某项特征存在，并不证明生成器可以控制它，也不证明评价器已能正确识别。每条特征均设置待实现状态。")
    d.table(["层级", "首批内容", "进入运行流程的条件"], [
        ["P0 基础流程与几何", "模态、尺寸、间距与仿射，病灶体积、最大轴位长径、空间框及可见性检查", "实现并核验度量；确认后端与影像掩膜的对应关系；独立医学复核首批结果"],
        ["P1 形态与精确定位", "毛刺、分叶、边缘、实性程度、球形程度评分、肺叶或结肠分段定位", "取得可靠标注，训练或选择检查器并在独立真实数据上验证；确认生成可控性"],
        ["P2 复杂关系与MRI", "局部侵犯、分期、转移评估，直肠 MRF、EMVI、淋巴结和多序列表现", "具备对应数据、生成后端、多结构证据及经过医学审核的判读规则"],
    ], [1800, 3600, 3800])
    d.p("肺部特征参考 MED01、MED02，结肠字段参考 MED03，直肠 MRI 字段参考 MED04、MED05。工程坐标、体积和轴位长径的算法由 ENG01 明确，不能冒充原论文公式或临床分期规则。全部条目与来源定位见首批医学影像特征清单。")
    d.p("优先沿用可溯源的原始标注。影像学恶性可能性与病理诊断分开，多医师评分分开，未知与未评估分开。MRI 的初始分期和再分期规则分开；MED05 对 DWI 用途的限制一并保存。")
    d.table(["首版度量", "操作约定"], [
        ["病灶体积", "有效病灶掩膜前景体素数 × 仿射三维线性部分行列式绝对值；先核对空间单位为毫米。"],
        ["最大轴位长径", "在明确的轴位重建平面测量各轮廓最长面内距离并取最大；不与三维最大径、平均直径或 RECIST 自动等同。"],
        ["空间定位", "掩膜、体素框、世界坐标框保留对应关系；声明轴序及区间约定；预处理后同步更新。"],
        ["可见性", "生成掩膜是候选条件；最终图像中的目标是否可见仍须独立检查，首批样本人工复核。"],
    ], [2300, 6900])

    d.h("四 用户需求审核与默认参数")
    if pi_selected:
        d.p("工作流采用独立节点：输入及结构化草稿 → 参数校验 → 逐项默认确认与最终确认 → 保存确认版本 → Pi动态建模 → 可执行性校验 → 生成与筛选。参数确认界面及其后端可以由普通程序实现。自然语言结构化可由独立前处理调用LLM，得到的仍是待审核草稿。")
        d.p("参数确认完成后可以进入Pi建模；此时不要求数学模型已经编译完成，也不等于已经允许启动图像生成。正式生成必须另外通过模型、后端能力与预算校验。草稿、示例、过期版本或未确认默认项不得提交到正式Pi执行节点；模型提出新缺项或改值时返回前置确认节点。")
    d.p("前端展示原始文字与结构化字段，允许新增、删除和修改指标。每项显示值、单位、来源、约束类型、优先级、支持状态和审核状态；必要时展开其目标、约束或筛选规则说明。")
    for text in [
        "提取：将用户原文映射为字段；没有明确提供的信息标为缺失，不自动补成已确定事实。",
        "补齐：系统逐项展示默认建议；用户可以确认、修改后确认，或在理解后表示知悉。未处理项保持待确认。",
        "检查：校验数值、单位、互斥类别比例、共现关系、依赖条件、数量上限及后端能力；反馈无法执行的指标。",
        "确认：只有用户的真实交互事件才能构成确认；结构化文件中的布尔值本身不代表授权。",
        "编译：将确认版本映射为可执行模型；若映射发现新缺失项或需要改变需求，返回审核。",
        "版本绑定：需求修改后原模型和启动资格失效；已运行任务保留原快照，新的需求产生新任务或受控的新版本。",
    ]:
        d.bullet(text)
    d.p("需求示例：生成20份肺部肿瘤CT三维图文样本，病灶最大轴位长径10到20毫米，文字描述可见征象和病灶位置。此句用于说明字段，不是用户已确认的实际生成指令。")
    d.table(["字段组", "展示内容", "说明"], [
        ["示例中的明确要求", "肺部肿瘤 CT、20 个三维样本、最大轴位长径10—20mm、征象与位置文本", "保留来源原句，仍由真实用户审核"],
        ["系统默认建议", "体积尺寸、间距、标注、语言、格式、并发、阳阴比例、上限及候选预算", "逐项弹出并处理"],
        ["能力与冲突", "当前生成/评价是否支持，有无缺失数据、单位或不相容条件", "未支持的硬约束阻止启动"],
        ["最终快照", "需求版本、默认项处理记录、编译版本与模型/数据版本", "用户最终确认后绑定"],
    ], [2000, 4400, 2800])
    d.p("以下是供审核的 CT 首版默认建议，尚未被用户逐项确认：")
    d.table(["项目", "建议值", "需说明的条件"], [
        [name, json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else str(value), note]
        for name, value, unit, note in DEFAULTS
    ], [1900, 3100, 4200])
    d.p("质量阈值、检查器能力和 MRI 后端不存在可靠默认值时，显示待定并阻止依赖它们的正式执行。可以先组织受控试跑以获取校准数据；试跑配置与正式批量任务分开。")

    d.h("五 动态优化建模")
    d.p("令 R 表示用户确认的需求，Gθ 表示固定版本的候选生成器。生成变量 u 可以包含后端明确支持的归一化病灶大小、其他条件，以及受控种子或噪声；图像与候选掩膜表示为 (x,m) = Gθ(u)。可调变量须来自后端能力表，不能由语言模型任意发明。")
    d.p("需求编译器输出 P(R) = {U(R), F(R), G(R), H(R), E(R)}，分别代表变量域、目标集合、不等式约束、等式约束和所需评价器。目标数量、约束数量、表达方式和参数可以随需求改变。首版从已定义和验证的函数库中选择、组合；新函数先经过审核和验证后注册。")
    d.table(["文字要求", "建模表达", "实施边界"], [
        ["最大轴位长径10—20mm，必须满足", "g1 = 10 − d(x,m,A) ≤ 0；g2 = d(x,m,A) − 20 ≤ 0", "d 为GEO02度量；归一化大小控制需校准；无有效空间信息则不可求值"],
        ["某特征占p，允许偏差ε", "|n_k(D)/|D| − p| ≤ ε", "以用户确认的计数单位计算；考虑整数可行性；共现特征不误作互斥类别"],
        ["某项尽量达到要求", "将已确认的偏差函数加入目标集合F(R)", "函数、方向、归一化和必要权重需可解释；不私自把硬约束改为软目标"],
        ["修改指标类型或删除指标", "更新F(R)、G(R)或H(R)，重新解析依赖和版本", "更改后旧编译结果失效"],
        ["样本总量与上限", "合格交付目标、交付上限及候选预算分别管理", "交付上限不是重试预算；预算耗尽时停止并报告缺口"],
    ], [2100, 3200, 3900])
    d.p("单样本约束由生成与测量环节处理，数据集分布由配额调度和入库筛选处理。比例要求可能因整数计数或互相冲突而不可行，编译前先检查；不能无限重试来掩盖不可行性。")
    d.p("若一次任务只有硬约束而没有优化目标，则编译为可行性问题，先用可行性搜索或生成筛选基线求解；有一个目标时按单目标问题处理，至少两个已定义目标时才比较多目标算法。需求确认示例属于仅声明大小硬约束的情况，不能擅自填入额外目标以便使用NSGA-II。")
    d.p("初版算法基线采用相同预算下的随机候选生成和筛选，再与约束多目标优化比较。NSGA-II是实现候选，并非预先确定优胜的方法。[OPT01] 仅把种子当连续变量交叉没有天然语义，种子采用明确的离散采样或后端支持的噪声表示；记录随机性、种子集合和重复评估策略。")
    d.p("质量与医学合理性的评价必须绑定具体检查器和验证结果。不存在已验证的医学质量函数时，不创建一个名称空泛的评分来参与优化；以检查和医学复核结果报告能力。多样性如需启用，应先确认表示、距离和数据集层面的计算办法。")

    d.h("六 图像与文本标注的对应策略")
    for text in [
        "生成影像和候选掩膜，保留模型版本、输入条件、种子、处理步骤和失败次数。",
        "核对影像与掩膜空间对应关系，并用独立图像检查或医学复核确认目标可见性；首批试跑对全部样本复核。",
        "从可验证的图像与掩膜提取已测量属性。属性记录区分测量值、来源标注、自动预测、人工确认、未知和未评估。",
        "先由模板生成可见征象和定位文字，大语言模型可在既定属性约束下调整表达；每项描述保留证据字段引用。",
        "检查尺寸、单位、部位、极性和分期等是否有依据。没有评估的结构不能输出阴性；来源中没有的病理或分期不能补写。",
        "通过样本级检查后再按数据集配额入库；不足时在预算内补齐。导出仍保留筛选原因、检查器版本和未完成的评估项。",
    ]:
        d.bullet(text)
    d.p("分割器可以检查生成掩膜与图像预测掩膜的一致性，但这一项不能单独证明医学真实性。拟使用独立真实数据训练或验证检查器。[SEG01] 当自动检查器与生成器共用来源或模型时，记录相关性并安排独立人工抽检。")

    d.h("七 数据和模型选型")
    if pi_selected:
        d.p("智能体基座已选定earendil-works/pi。既有仓库核验对应提交2c8d1fe；这是调研依据，不是已经安装验证的部署版本。Pi只承担模型交互与工具调用，Python算法、解析和GPU生成服务可以通过业务接口接入。[PI01—PI04]")
    d.table(["环节", "首批候选", "验证后才能承诺的能力"], [
        ["需求解析", "Qwen3-8B + 结构化输出和特征字典 [MOD03]", "医学字段提取、歧义识别与函数映射"],
        ["CT生成", "MAISI MONAI bundle；NIM作为另一个后端形态 [MOD01、MOD02]", "肺部肿瘤和结肠原发癌的实际生成质量、毫米大小范围、稳定性和显存"],
        ["优化器", "随机筛选基线 + pymoo/NSGA-II候选 [OPT01]", "相同预算下的有效率、约束满足率与成本"],
        ["图像检查", "确定性测量、独立分割/特征检查器、医学复核 [SEG01]", "各检查器准确性与使用范围"],
        ["目标训练接口", "先适配Qwen3-VL-8B-Instruct的数据读取 [MOD04]", "实际训练可用性及下游收益"],
    ], [1700, 3900, 3600])
    d.table(["分支", "候选数据", "取得和标签状态"], [
        ["肺部肿瘤CT", "MSD肺肿瘤分割任务；LIDC-IDRI用于结节轮廓和形态研究 [DATA01、DATA02]", "尚未下载；分别核对肿瘤标签与结节医师评分，不能混为同一种真值"],
        ["结肠癌CT", "MSD Task10 Colon [DATA01]", "尚未下载；可优先支持肿瘤掩膜和派生几何，缺少的临床字段保留缺失"],
        ["直肠癌MRI", "RC4论文与作者仓库 [DATA03]", "下载入口未核实；不能按已取得数据安排完整MRI生成实验"],
    ], [1800, 3900, 3500])
    d.p("MAISI文档中的0—1大小参数表示相对尺度，不直接对应毫米值；先做参数到实际测量结果的校准。[MOD01] MONAI bundle中某些条件只在未设置大小控制时生效，NIM另有接口规范，选定后端后逐条形成能力表。")
    d.p("参考图像主要用于核对模态、任务、特征及可利用的参考信息。首版不承诺从少量图像训练出完整医学生成模型，也不承诺自动匹配任意医院扫描风格。若需要风格或协议适配，增加专门的数据与实验。")
    d.p("三维生成先考虑80GB级服务器试跑。MOD02的512³官方测试配置为80GB级显存；MOD01对其bundle给出的显存数值另行记录。建议512×512×256配置仍需实测显存、耗时和视野，不能按体素数简单线性估算显存。算力不足时先验证局部体块方案，并同步缩小可支持的任务和结论范围。")

    d.h("八 数据划分与交付格式")
    d.p("真实数据先按患者或检查来源组划分，再进行裁剪、变换和生成增强。同一患者、多次相关扫描、同源切片及编辑派生样本保持来源关联。独立真实测试集不参与生成器适配、评价器训练或参数选择。")
    d.p("完全合成体积没有真实患者编号，使用合成体积ID及派生组ID，不能虚构患者。按体积、病灶和切片分别报告规模及分布；同一体积导出的切片不能作为互相独立的病例计数。")
    d.table(["文件", "内容", "必要关联"], [
        ["NIfTI影像与掩膜", "医学主文件、空间信息和掩膜", "volume_id、空间仿射、体素单位、掩膜标签表"],
        ["JSONL图文配对", "影像路径、属性证据、征象文本", "sample_id、volume_id、需求版本、实际测量与确认状态"],
        ["可选PNG切片", "按模型需要导出的二维图像", "窗宽窗位或归一化、切片索引、父体积、坐标变换"],
        ["CSV质量记录", "检查结果、筛选原因和运行统计", "检查器版本、人工复核、失败原因及结束原因"],
        ["manifest与配置快照", "包内文件、关联、版本和运行条件", "校验和、模型/数据/特征字典版本、确认事件"],
    ], [2000, 3400, 3800])
    d.p("图像—文本配对用于预训练数据交付；图像—指令—回答三元组属于另一种任务组织形式，单独适配导出。需要病灶框或分级时，明确标注规范、依据和训练方式，不把所有格式笼统混为一种预训练样本。")

    d.h("九 最小可行版本的实施顺序")
    milestone_rows = [
        ["M0 方案和范围", "导师审核两癌CT首版范围、MRI扩展、候选方法和首批特征", "确定的范围、可接受输出和未决项"],
        *([["当前优先 T1", "先开发论文视觉特征文本提取、证据定位、人工审核与导出", "可审核的原文证据集及按论文划分的抽取效果报告"]] if include_subtask else []),
        ["M1 需求审核链路", "自然语言解析、可编辑字段、逐项默认确认、冲突检查和版本快照", "前后端可演示交互及拒绝启动用例"],
        ["M2 最小真实数据链路", "小批量取得并核对MSD/LIDC数据；建立空间与来源约定", "病例清单、标注核对、划分与几何校验"],
        ["M3 生成器试跑", "锁定后端和权重，检查两类CT生成、掩膜、视野、显存和耗时", "两分支各约10个体积的实测记录与全部复核"],
        ["M4 动态建模和筛选", "实现可测特征函数库、模型编译、基线、优化候选及样本账本", "变更需求后的模型差异、同预算对照、数量与约束检查"],
        ["M5 小批量导出", "在可接受条件下扩大至两分支各约100个体积，验证配额和导出", "完整数据包、质量报告、失败和缺口报告"],
        ["M6 扩展", "验证形态特征和MRI，依据实测再确定上千至上万图文对规模", "新增能力的依据、数据、评价和回归检查"],
    ]
    if pi_selected:
        milestone_rows = [[s["id"] + " " + s["name"], s["work"], s["gate"]]
                          for s in architecture_plan["stages"]]
    d.table(["步骤", "具体工作", "完成证据"], milestone_rows, [1850, 4450, 2900])
    if pi_selected:
        d.p("总任务与T1均按成果验收推进，不按周或固定工期自动进入下一阶段。每阶段保留交付物、验收证据与通过记录；具体试跑数量、质量阈值与资源根据开发实测讨论确定。T1先行，医生口述和人工填写的需求路径可独立准备；正式生成须等待已确认配置与通过校验的模型。")
        d.p("存储按实际对象确定：保存用户配置及确认版本、已审核证据与交付产物；运行中任务的自动续跑、缓存和队列按成本及使用场景决定。首版可以选择明确中断后重新运行，或实现恢复；两种方式均须保持状态真实且不重复计入交付，不预设分布式工作流框架。")
    else:
        d.p("约10和约100是建议试跑规模，不是已完成数量。具体时间安排在取得可用算力并完成M3后制定；记录单位候选成本、合格率和人工复核成本，之后再承诺批量规模。M1、M2以及算法接口设计可在目标论文身份未明确时继续。")

    d.h("十 系统验收与效果验证")
    d.p("功能验收检查需求是否被正确理解和执行；生成质量验证检查产物是否有用。前者可以设定明确的拒绝和通过条件，后者先报告实测结果，再与导师确定可接受阈值。不能把流程通过率当作医学正确率。")
    d.table(["验证对象", "方法", "结果记录"], [
        ["需求提取", "准备覆盖两癌、默认项、混合指标、歧义与冲突的人工标注需求集", "字段值、单位、来源、约束类型的匹配情况及错误案例"],
        ["审核与版本", "运行A02—A10、A21等用例", "未确认阻止率、修改生效和版本关联"],
        ["几何与定位", "已知几何体、元数据异常和裁剪重采样案例", "测量误差、坐标与掩膜对齐；阈值按操作定义确定"],
        ["生成与筛选", "相同候选预算比较随机筛选和优化方案", "候选数、合格数、约束满足率、耗时、显存、失败与复核结果"],
        ["数据集分布", "按确认的计数单位计算配额与偏差", "实际计数、目标比例、容差、缺口和结束原因"],
        ["训练价值", "资源允许时，在独立真实测试集比较仅真实数据与加入合成数据", "按明确任务选指标；数据划分和训练预算一致"],
    ], [1800, 3900, 3500])
    d.p(f"配套验收清单列出{acceptance_count}项具体情景，均为待执行用例。本轮仅检查材料、文件结构及示例契约，不代表系统功能或模型性能已经验收。")
    if pi_selected:
        d.p("Pi接入新增验收覆盖前置确认、配置版本绑定、新缺项返回、权限限制、已选中断策略及Docker运行。参数确认、原文证据审核和数学模型可执行性检查分别验收，不相互代替。")

    d.h("十一 待导师审核的具体决策")
    for text in [
        *([(("T1已选定Pi基座，按阶段验收推进；继续讨论输入覆盖、审核方式、解析器与模型、接入方式及质量性能门槛。" if pi_selected else "T1按跨肿瘤文献能力开发，以阶段验收推进；范围、部署、批量规模、质量与性能门槛及关键组件先与用户讨论，再开展选型和实施。")
             if literature_plan_mode == "stage_gated" else
             "T1作为原总任务的上游子任务独立实施；优先核定文本型论文、原文证据、人工审核与四周计划范围。")] if include_subtask else []),
        "是否认可首版以肺部肿瘤和结肠癌CT、几何与定位描述为实际生成范围，同时预留直肠癌MRI。",
        "是否认可可解释需求审核、动态目标/约束编译，以及生成与数据集筛选的分层设计。",
        "是否认可MAISI作为试跑候选、随机筛选作为基线，并以实测决定优化器和其他生成方法。",
        "是否具备可用的三维生成算力和医学复核条件；据此确定试跑配置、规模与质量阈值。",
        "两篇讨论过的候选论文需补充题名、作者、年份、DOI或原文件，以便核对适配与复用。",
        "MRI数据取得途径、复杂征象标注与分期规则，作为后续扩展的明确进入条件。",
    ]:
        d.bullet(text)

    d.h("十二 资料来源与引用范围")
    if pi_selected:
        for src in architecture_plan["sources"]:
            d.link("[" + src["id"] + "] " + src["title"], src["url"])
        d.p("Pi来源已按固定提交核验README、SDK/RPC、Skill、权限与持久化说明；pi-durable被官方标为实验性。仓库源码调研不等于本项目的接入、医学质量或性能测试。")
    d.p("以下为定向检索形成的起始资料，未进行穷尽性系统综述。来源支持范围与局限一并列出；对部分仅获取摘要或摘录的资料，进入规则实现前继续核对全文。DOI身份元数据记录见research目录，完整来源记录见资料与选型核验.json。")
    for src in [s for s in SOURCES if s["id"] != "TOOL01"]:
        year = str(src["year"]) if src.get("year") else "官方在线资料"
        label = f"[{src['id']}] {src['title']}（{year}）"
        if src.get("doi"):
            label += " DOI: " + src["doi"]
        if src["url"]:
            d.link(label, src["url"])
        else:
            d.p(label, "Reference")
        d.p("支持范围：" + src["supports"] + "  使用边界：" + src["limits"], "Reference")
    src = next(s for s in SOURCES if s["id"] == "TOOL01")
    d.p("检索工具与方法来源", bold=True)
    d.link("[TOOL01] Kassis, T., Agarwal, V., He, Y., Patel, D., & Brueckner, A. M. (2026). "
           + src["title"] + ". arXiv:2609.00065. DOI: " + src["doi"], src["url"])
    d.p(src["supports"] + " " + src["limits"], "Reference")
    return d


def validate_pack(example, schema, docx_path):
    from jsonschema import Draft202012Validator, FormatChecker
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    validator.validate(example)
    rejection_cases = {}
    bad = copy.deepcopy(example)
    bad["workflow_status"] = "approved_for_pilot"
    rejection_cases["示例直接切换为批准态"] = bool(list(validator.iter_errors(bad)))
    bad = copy.deepcopy(example)
    bad["execution_authorized"] = True
    rejection_cases["草稿直接授权执行"] = bool(list(validator.iter_errors(bad)))
    bad = copy.deepcopy(example)
    bad["requirements"][0]["review"]["state"] = "confirmed"
    rejection_cases["缺少真实事件信息的确认态"] = bool(list(validator.iter_errors(bad)))
    bad = copy.deepcopy(example)
    bad["requirements"][2]["feature_id"] = "UNKNOWN_METRIC"
    rejection_cases["未注册的特征ID"] = bool(list(validator.iter_errors(bad)))
    assert all(rejection_cases.values()), rejection_cases
    source_ids = {s["id"] for s in SOURCES}
    assert len(source_ids) == len(SOURCES)
    assert len({f["feature_id"] for f in FEATURES}) == len(FEATURES)
    for f in FEATURES:
        assert set(f["source_ids"].split(";")) <= source_ids, f
    with (OUT / "首批医学影像特征清单.csv").open(encoding="utf-8-sig", newline="") as fp:
        assert len(list(csv.DictReader(fp))) == len(FEATURES)
    with (OUT / "验收清单.csv").open(encoding="utf-8-sig", newline="") as fp:
        assert len(list(csv.DictReader(fp))) == len(ACCEPTANCE_ROWS)
    with ZipFile(docx_path) as z:
        assert z.testzip() is None
        members = set(z.namelist())
        for name in members:
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        relroot = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        rels = {r.attrib["Id"]: r for r in relroot}
        document = ET.fromstring(z.read("word/document.xml"))
        for h in document.iter(q("w:hyperlink")):
            assert h.attrib[q("r:id")] in rels
        for rel in relroot:
            if rel.attrib.get("TargetMode") != "External":
                assert "word/" + rel.attrib["Target"] in members
        content = "\n".join(t.text or "" for t in document.iter(q("w:t")))
        assert "两篇候选论文" in content and "尚未进行模型试跑" in content
        assert all(f"[{s['id']}]" in content for s in SOURCES)
        assert len(document.findall(".//" + q("w:tbl"))) >= 10
    return {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "checks": {
            "docx_zip_and_xml": "pass",
            "docx_relationship_targets": "pass",
            "source_ids_and_feature_ids": "pass",
            "csv_row_counts": "pass",
            "json_schema_and_draft_example": "pass",
            "invalid_examples_rejected": rejection_cases,
        },
        "counts": {
            "feature_entries": len(FEATURES),
            "acceptance_scenarios": len(ACCEPTANCE_ROWS),
            "illustrative_requirement_items": len(example["requirements"]),
            "pending_default_items": sum(r["provenance"]["kind"] == "default_proposal"
                                         for r in example["requirements"]),
            "source_records": len(SOURCES),
        },
        "limits": [
            "未执行影像生成、训练或医学效果验证",
            "未在Word/WPS中进行分页和视觉预览",
            "JSON Schema只验证结构及部分状态约束；语义可行性、版本哈希和交互事件真实性须由后续后端实现",
            "两篇目标论文尚未唯一识别",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite", action="store_true",
                        help="Explicitly replace files generated by a previous run.")
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    outputs = [
        "毕业设计实施方案_导师审核稿.docx", "首批医学影像特征清单.csv",
        "首批医学影像特征清单.json", "需求确认示例.json", "需求结构.schema.json",
        "验收清单.csv", "资料与选型核验.json", "材料检查结果.json",
    ]
    existing = [name for name in outputs if (OUT / name).exists()]
    if existing and not args.overwrite:
        raise SystemExit("Refusing to overwrite existing review material: " + ", ".join(existing))

    with (OUT / "首批医学影像特征清单.csv").open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow([
            "特征ID", "类别", "名称", "操作定义", "值类型", "单位", "评估层级",
            "来源ID", "来源定位", "计划阶段", "生成支持情况", "评价计划", "实现状态",
        ])
        for f in FEATURES:
            writer.writerow([f[k] for k in FEATURE_KEYS] + [f["implementation_status"]])
    write_json(OUT / "首批医学影像特征清单.json", {
        "version": VERSION, "date": DATE, "status": "draft",
        "coverage": "首批条目，含工程元数据与几何量；不代表全部已知医学特征",
        "implementation_status": "planned_not_implemented",
        "stage_counts": dict(Counter(f["planned_stage"] for f in FEATURES)),
        "features": FEATURES,
    })
    with (OUT / "验收清单.csv").open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["编号", "类别", "情景", "预期行为", "验收证据", "计划阶段", "执行状态"])
        writer.writerows([*r, "未执行"] for r in ACCEPTANCE_ROWS)
    example, schema = make_example(), make_schema()
    write_json(OUT / "需求确认示例.json", example)
    write_json(OUT / "需求结构.schema.json", schema)
    write_json(OUT / "资料与选型核验.json", {
        "version": VERSION, "checked_date": DATE,
        "review_type": "targeted_discovery_not_systematic_review",
        "candidate_papers": [
            {"given_label": "TPARMI/可能的TPAMI", "status": "identity_unresolved",
             "title": None, "authors": None, "doi": None,
             "note": "期刊或拼写线索不足以唯一识别文章；不能指认为主题相近的文章。"},
            {"given_label": "TEVC", "status": "identity_unresolved",
             "title": None, "authors": None, "doi": None,
             "note": "期刊简称不足以唯一识别导师讨论的文章。"},
        ],
        "sources": SOURCES,
        "runtime_status": {
            "model_weights_downloaded": False,
            "datasets_downloaded": False,
            "image_generation_executed": False,
            "medical_evaluators_validated": False,
            "real_user_parameter_confirmation_recorded": False,
        },
    })
    doc = build_document()
    docx_path = OUT / "毕业设计实施方案_导师审核稿.docx"
    doc.save(docx_path)
    report = validate_pack(example, schema, docx_path)
    write_json(OUT / "材料检查结果.json", report)
    print(json.dumps({"output_directory": str(OUT), **report}, ensure_ascii=False, indent=2))
    for name in outputs:
        print(f"{(OUT / name).stat().st_size:>8} bytes  {name}")


if __name__ == "__main__":
    main()

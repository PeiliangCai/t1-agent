#!/usr/bin/env python3
"""Create a concise advisor review copy of the accepted T1 planning revision."""
from __future__ import annotations

import json
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import ROOT, DATE, Word, q, write_json


OUT = ROOT / "方案/子任务T1"
STEM = "T1智能体开发计划_导师审核简版"
TITLE = "基于Pi的肿瘤医学论文视觉特征文本提取智能体开发计划"

INTRO = (
    "老师您好，针对您提出的“先写一个智能体，提取医学论文中关于医学图像肿瘤视觉特征的表述文本信息”，"
    "我将其作为毕业设计中的第一个子任务（T1），制定以下开发计划，请您审核任务理解、功能范围与验收安排。"
)
GOAL = (
    "本子任务的目标是：读取用户提供的肿瘤相关医学论文，提取其中关于医学图像中肿瘤视觉特征的原文描述，"
    "保留出处与必要上下文，形成可人工核对、可导出的证据记录，为后续特征整理、需求审核和数学建模提供输入。"
    "本阶段交付的是文献证据及提取工具；图像生成与优化算法属于后续子任务。"
)
SCOPE = (
    "首个可交互版本接收用户上传的公开已发表论文PDF，按逐篇交互方式处理。系统面向持续新增的论文，"
    "不将论文题名、癌种或特征术语固定为白名单。首批验证拟从肺癌、肠癌相关CT/MRI文献入手，"
    "首版语言、扫描PDF及其他影像模态的支持范围在初始阶段明确。自动检索论文和通过链接获取论文不纳入首版。"
)
FUNCTIONS = [
    "读取论文，查找肿瘤位置、大小、形态、边缘、密度或信号、强化及邻近关系等视觉特征的相关表述。",
    "保存原文及论文身份、PDF页码或文本位置，保留模态、否定、不确定性、数值单位和适用条件；原文与可选译文、归纳说明分别展示。",
    "尽快展示首批带出处的候选结果，继续处理全文并反馈进度；读取失败、未处理部分及定位不可靠的记录明确标记。",
    "提供原文对照、候选增删改、审核和导出；区分候选结果与人工审核通过的证据，允许保留新术语和待分类特征。",
]
APPROACH = (
    "实现采用Pi作为智能体基座，由Pi组织模型交互和工具调用。参数确认独立实现：先展示抽取配置和默认建议，"
    "由用户逐项处理并确认，再将确认后的配置版本传入Pi执行节点。PDF解析、原文定位、结果校验、审核界面和导出"
    "使用适合的普通程序或工具接口；任务规则可按需封装为Skill。业务存储及权限由项目配置，运行中任务是否续跑按实际需要决定。"
)
FLOW = "上传PDF → 抽取参数确认 → 解析与原文定位 → 特征表述抽取及语境核验 → 渐进展示与人工审核 → 导出证据并衔接后续建模。"

STAGE_ROWS = [
    ["S0 范围与验收约定", "明确输入类型、特征范围、审核方式及质量和响应要求。", "形成支持范围与验收约定，确定需要评测的内容。"],
    ["S1 Pi接入与参数前置节点", "接入Pi，完成独立参数确认、工具调用和进度回传的最小原型。", "确认后的配置正确传入；未确认配置不执行；权限边界有效。"],
    ["S2 评测语料与人工标注", "准备不同来源、癌种和版式的论文，人工标注相关原文与上下文，划分开发和独立测试资料。", "形成可核对的完整标注与判分规则；确定具体质量门槛。"],
    ["S3 PDF解析与证据定位", "比较解析工具，建立页面、文本块及原文片段的对应关系。", "能够定位回原文，并明确报告漏页、解析失败和覆盖情况。"],
    ["S4 抽取与语境核验", "实现原文抽取、新特征处理及否定、条件、模态等核验；对照模型和抽取策略。", "在未参与开发的新论文上验证准确性、覆盖情况和语境保留。"],
    ["S5 交互审核与必要存储", "接通上传、参数确认、渐进结果、原文回看、修订和导出。", "完整交互流程可用；配置、审核版本与成果可追溯；中断状态明确。"],
    ["S6 质量与性能验收", "评估独立论文的抽取结果、首批候选响应、全文耗时、资源及故障处理。", "达到约定指标，报告失败案例、人工修订量和实际适用范围。"],
    ["S7 部署与成果交付", "整理Docker部署、操作说明、版本配置及后续建模所需的证据接口。", "其他使用者能重复完成上传、确认、抽取、审核和导出。"],
]

EVALUATION = (
    "质量重点检查：是否误抽或漏抽、引用原文与位置是否准确、否定及适用条件是否保留，以及对新论文的适用性。"
    "以人工标注的完整范围评估精确率和召回率，不能只核对模型已找到的片段。性能分别记录首批可审核候选和全文处理耗时，"
    "同时统计资源消耗与人工修订工作量。具体数值门槛结合需求和开发实测确定，不预先承诺未经验证的准确率或秒数。"
)
DELIVERY = (
    "预期交付包括：可运行的提取应用及源码、必要的工具与任务规则、带原文出处和审核状态的结构化证据、"
    "评测资料与质量性能报告，以及Docker部署和操作说明。开发按阶段成果验收推进，前一阶段完成并验收后进入下一阶段。"
)
REVIEW = (
    "请老师重点审核：上述任务理解是否符合本阶段目标，首版功能和起始验证范围是否合适，以及验收重点和医学复核条件。"
    "目前已选定Pi作为实现基座；具体解析器、模型、接入方式和质量性能门槛仍在对应阶段验证与讨论。当前已完成计划整理，"
    "应用开发和医学效果实测尚未开始。"
)


def main():
    existing = OUT / (STEM + ".docx")
    if existing.exists():
        raise SystemExit(
            "The advisor DOCX is user-maintained and authoritative. "
            "Edit that file directly; do not regenerate it from this historical template."
        )
    plan = json.loads((OUT / "开发计划.json").read_text(encoding="utf-8"))
    assert plan["version"] == "0.3"
    assert plan["architecture"]["selected_agent_base"] == "earendil-works/pi"
    assert [r[0].split()[0] for r in STAGE_ROWS] == [s["id"] for s in plan["progression"]["stages"]]
    d = Word(title=TITLE, subject="T1目标、功能、实施阶段与验收安排", header="毕业设计子任务T1 / 导师审核简版")
    d.p(TITLE, "Title")
    d.p(f"依据T1开发计划v{plan['version']}整理  日期：{DATE}", "Reference")
    d.p(INTRO)
    d.p(GOAL)
    d.p(SCOPE)
    d.p("拟实现的主要功能如下：")
    for f in FUNCTIONS:
        d.bullet(f)
    d.p(APPROACH)
    d.p(FLOW)
    d.p("开发按以下阶段推进，每阶段完成后核对成果与验收条件：")
    d.table(["阶段", "主要工作", "阶段成果与验收重点"], STAGE_ROWS, [1900, 3600, 3700])
    d.p(EVALUATION)
    d.p(DELIVERY)
    d.p(REVIEW)
    d.link("Pi项目来源", "https://github.com/earendil-works/pi")
    doc_path, txt_path = OUT / (STEM + ".docx"), OUT / (STEM + ".txt")
    d.save(doc_path)
    text = [TITLE, INTRO, GOAL, SCOPE, "拟实现的主要功能：\n" + "\n".join(f"{i}. {s}" for i, s in enumerate(FUNCTIONS, 1)), APPROACH, FLOW]
    text.append("开发阶段（每阶段完成并验收后进入下一阶段）：\n\n" + "\n\n".join(f"{r[0]}\n工作：{r[1]}\n成果与验收：{r[2]}" for r in STAGE_ROWS))
    text.extend([EVALUATION, DELIVERY, REVIEW])
    txt_path.write_text("\n\n".join(text) + "\n", encoding="utf-8")
    with ZipFile(doc_path) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        root = ET.fromstring(z.read("word/document.xml"))
        body = "\n".join(n.text or "" for n in root.iter(q("w:t")))
        assert all(r[0] in body for r in STAGE_ROWS)
        assert all(s in body for s in [GOAL, SCOPE, APPROACH, EVALUATION, DELIVERY, REVIEW])
    index_path = OUT / "当前版本.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    index.update(advisor_review_plan=doc_path.name, advisor_review_text=txt_path.name)
    write_json(index_path, index)
    print(json.dumps({"document": str(doc_path), "copyable_text": str(txt_path),
                      "source_plan_version": plan["version"], "stages": len(STAGE_ROWS),
                      "check": "DOCX ZIP/XML, source-stage alignment and content checks passed"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Prepare a supervisor-facing functional brief; implement neither option."""
from __future__ import annotations

import argparse
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import ROOT, DATE, Word, q


OUT = ROOT / "方案" / "子任务T1"
DOC = OUT / "发给导师_功能介绍与两种实现方式确认稿.docx"
TXT = OUT / "发给导师_功能介绍与两种实现方式确认稿.txt"

OPENING = (
    "老师您好，关于您提出的“写一个智能体，提取医学论文中关于医学图像肿瘤视觉特征的表述文本信息”，"
    "我目前将它理解为总课题中的文献特征来源子任务，想先向您确认功能范围和实现形式。"
)
GOAL = (
    "用户提供公开已发表的肿瘤相关医学论文PDF，系统读取论文，"
    "提取作者对影像中肿瘤视觉特征的原文描述，保留出处和必要上下文，"
    "供人工核对，并为后续特征整理与数学建模提供输入。"
)
FUNCTIONS = [
    "接收用户提供的论文PDF，能够处理持续新增的论文，论文题名、癌种和特征术语不写死。",
    "查找论文中描述肿瘤位置、大小、形态、边缘、密度或信号、强化及邻近关系等视觉特征的相关表述。",
    "提取并保留原文，附论文题目、可核对的页码或章节等出处；原文与可选译文、归纳说明分开保存。",
    "保留影像模态、否定、不确定性及适用条件等必要上下文，避免将有条件的描述变成无条件结论。",
    "将结果整理成便于核对的表格或文件，支持用户确认、修订和补充。无法可靠读取、定位或处理完整的部分明确标记。",
]
FORMS = [
    (
        "方案A 独立智能体应用",
        "开发独立的软件工具，提供PDF上传、模型与解析工具调用、原文提取、出处核对、"
        "结果审核和导出。可根据需要实现先展示候选、继续处理全文的进度反馈，"
        "并用Docker部署供其他人使用。交付物是可独立运行的应用及其评测结果。"
    ),
    (
        "方案B Skill形式",
        "在支持Skill且具备论文读取工具的现有模型平台中，封装一套专门的读论文、"
        "查找视觉特征表述、提取原文、核对出处和整理输出的工作流程。"
        "优先使用宿主平台已有能力；必要时配套PDF解析、原文定位或结果校验脚本。"
        "交付物是可复用的Skill包、必要的辅助资源及其评测结果。"
    ),
]
CLARIFICATION = (
    "两种方式的核心抽取目标相同，区别主要在使用和交付形式。"
    "Skill依托现有模型平台执行，也可以作为智能体能力的封装；"
    "后续如需独立应用，可以复用其中的规则和辅助组件。"
    "无论采用哪种形式，都需要用实际新论文验证原文准确性、覆盖情况和处理效率。"
)
QUESTION = (
    "请老师确认：上述功能理解是否符合您的意思？当前阶段是希望先实现并验证"
    "“模型读取论文、提取有出处的相关原文”这项能力，采用Skill形式即可；"
    "还是同时需要交付一个带独立界面、可部署给其他人使用的软件工具？"
)

COMPARISON = [
    ["核心任务", "提取相关原文并保留出处与上下文", "相同"],
    ["使用入口", "自己开发的上传与审核界面", "现有支持Skill的模型平台"],
    ["实现内容", "应用界面、任务运行、工具接入和部署", "任务规则、输出约定及按需辅助脚本"],
    ["运行依赖", "应用服务器、模型服务及解析环境", "宿主模型、其工具能力和所需解析环境"],
    ["进度与审核", "可按需求专门设计", "复用宿主交互；不足的能力需另补"],
    ["主要交付", "可运行应用、部署材料和评测报告", "Skill包、使用条件和评测报告"],
    ["质量与性能", "按同一抽取目标和实际论文验证", "同样需要验证，形式本身不保证结果"],
]


def build_text():
    parts = [OPENING, "拟实现的功能", GOAL]
    parts += [f"{i}、{text}" for i, text in enumerate(FUNCTIONS, 1)]
    parts += ["两种可选实现方式"]
    for title, text in FORMS:
        parts += [title, text]
    parts += [CLARIFICATION, QUESTION]
    return "\n\n".join(parts) + "\n"


def build_doc():
    d = Word(
        title="肿瘤医学论文视觉特征文本提取功能与实现方式确认稿",
        subject="供导师核对共同功能及独立应用和Skill两种交付形式",
        header="总课题上游子任务T1 / 功能与实现形式确认",
    )
    d.p("肿瘤医学论文视觉特征文本提取", "Title")
    d.p("功能介绍与两种实现方式确认稿", "Subtitle")
    d.p(f"日期 {DATE}    状态：供导师确认，尚未选定实现形式", "Reference")
    d.p(OPENING)
    d.p("拟实现的功能", bold=True)
    d.p(GOAL)
    for i, text in enumerate(FUNCTIONS, 1):
        d.p(f"{i}、{text}")
    d.p("两种可选实现方式", bold=True)
    for title, text in FORMS:
        d.p(title, bold=True)
        d.p(text)
    d.p(CLARIFICATION)
    d.p("需要确认的事项", bold=True)
    d.p(QUESTION)
    d.p("实现形式对照", bold=True)
    d.table(["事项", "独立智能体应用", "Skill形式"], COMPARISON, [1800, 3700, 3700])
    d.p("技术形式说明", bold=True)
    d.p(
        "Skill可以由任务指令及可选参考资料、脚本等组成，由宿主模型按任务调用。"
        "先采用指令型或增加辅助脚本，应根据宿主平台现有能力和真实论文测试结果确定。"
        "模型是否能完整读取PDF、返回可靠位置、运行辅助脚本和导出文件，须在选定宿主上核实。"
        "本稿提供实现选择，不代表已经创建、安装或验证了Skill。"
    )
    d.link("OpenAI官方说明：构建和使用Skill", "https://learn.chatgpt.com/docs/build-skills")
    d.link("OpenAI官方说明：Skill的指令与辅助资源", "https://developers.openai.com/plugins/concepts/skills")
    d.link("OpenAI官方说明：通过评测验证Skill", "https://developers.openai.com/blog/eval-skills")
    return d


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if not args.overwrite and (DOC.exists() or TXT.exists()):
        raise SystemExit("Brief already exists; inspect before overwriting.")
    TXT.write_text(build_text(), encoding="utf-8")
    build_doc().save(DOC)
    with ZipFile(DOC) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        root = ET.fromstring(z.read("word/document.xml"))
        text = "\n".join(t.text or "" for t in root.iter(q("w:t")))
        assert all(title in text for title, _ in FORMS)
        assert QUESTION in text
        assert all(function in text for function in FUNCTIONS)
    print("Prepared:", DOC)
    print("Copyable text:", TXT)
    print("Forwardable text characters:", len(build_text()))
    print("Checks: DOCX ZIP/XML and shared-function consistency passed.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Write the T1 development plan and its relationship to the original project.

This is a planning-material builder, not the literature extraction agent.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import DATE, ROOT, SOURCES, Word, build_document, q, write_json


BASE = ROOT / "方案"
OUT = BASE / "子任务T1"
PARENT_VERSION = "0.2"
CHILD_VERSION = "0.1"
CHILD_NAME = "医学论文肿瘤视觉特征文本提取智能体"
CHILD_DOC = OUT / "医学论文肿瘤视觉特征提取智能体_开发计划.docx"
PARENT_DOC = BASE / "毕业设计实施方案_导师审核稿_v0.2.docx"
HIERARCHY_FILE = BASE / "任务分解.json"


TASK_ROWS = [
    ("T1.01", "第1周", 1, 1, 1, "", "定义抽取边界和标注规则", "明确癌种、模态、视觉特征、上下文和排除项；确定示例与反例", "范围说明与人工标注指南", "导师或项目负责人核定任务含义", "待开发"),
    ("T1.02", "第1周", 2, 2, 1, "T1.01", "准备文献与身份记录", "先取得至少5篇可获取全文的启动文献；建立目标20篇候选清单并预先分组", "论文登记表、全文可用性和版本记录", "每篇可以核对题名、来源、版本与全文；仅摘要单独标记", "待开发"),
    ("T1.03", "第1周", 3, 4, 2, "T1.02", "人工试标与规则修订", "先在开发组约6篇论文上标注相关表述、反例和必要上下文", "开发样例和标注规则修订", "发现的歧义有明确处理规则；医学复核协作时间另计", "待开发"),
    ("T1.04", "第1周", 5, 5, 1, "T1.01;T1.03", "定义记录和任务状态", "确定结果字段、工具接口、运行记录、失败状态和审核状态", "数据契约与智能体状态图", "原文、衍生解释和审核结果能分别保存", "待开发"),
    ("T1.05", "第2周", 6, 7, 2, "T1.02;T1.04", "实现文献解析与定位", "读取文本型PDF和可访问HTML/JATS；保留页面块或元素路径、字符位置", "可定位的文献文本层", "多栏顺序、页码和定位可核对；扫描件识别后转待处理", "待开发"),
    ("T1.06", "第2周", 8, 8, 1, "T1.05", "实现分块与候选范围", "按章节、段落和上下文分块；记录覆盖范围，优先保留高召回候选", "分块、候选段落及覆盖记录", "不会仅按固定词表丢弃新特征；参考文献列表可识别", "待开发"),
    ("T1.07", "第2周", 9, 10, 2, "T1.06", "实现单智能体抽取", "接入可替换的大模型，调用定位、抽取和补读工具；设置有界重试", "可批量运行的抽取原型", "能够按文献状态选择下一步工具，并输出有出处的候选原文", "待开发"),
    ("T1.08", "第3周", 11, 12, 2, "T1.05;T1.07", "实现证据与上下文检查", "核对原文区间、页面或元素位置、否定及不确定表述；不一致则补读或转人工", "证据校验与异常处理", "原文无法定位时不得进入已核对结果；保留失败原因", "待开发"),
    ("T1.09", "第3周", 13, 13, 1, "T1.08", "实现标签建议和去重", "标记癌种/病灶、模态、视觉特征类别及证据类型；去重但保留多来源与冲突", "候选标签和证据关联", "缺失保持未知；新术语可保留；病例与模态不混淆", "待开发"),
    ("T1.10", "第3周", 14, 15, 2, "T1.09", "实现人工审核界面", "展示原文、上下文和定位，允许修订标签、选择原文范围、接受或拒绝", "可审核的界面原型", "衍生解释可编辑；修改证据时重新定位并产生版本记录", "待开发"),
    ("T1.11", "第4周", 16, 16, 1, "T1.09;T1.10", "实现导出与后续接口", "分开导出全部候选与已审核结果；提供JSONL和CSV", "证据文件与T2接口说明", "未审核内容不会作为已审核知识入库；来源与版本完整", "待开发"),
    ("T1.12", "第4周", 17, 17, 1, "T1.03;T1.11", "冻结评估集与标注", "预先划定的测试论文由人工独立完成约定范围的完整标注并冻结；开发工时不含医学审阅等待", "测试文献、金标准、匹配规则", "同论文不同版本不跨组；不能仅标模型已找到的片段来计算召回", "待开发"),
    ("T1.13", "第4周", 18, 19, 2, "T1.11;T1.12", "运行对照与效果评估", "在相同文献与预算上比较关键词基线、直接大模型抽取和工具型智能体", "精确率、召回率、出处与上下文指标及失败分析", "报告真实分母、失败论文和运行成本；不预设智能体一定胜出", "待开发"),
    ("T1.14", "第4周", 20, 20, 1, "T1.13", "修订和整理演示材料", "依据评估修复主要问题，整理安装运行、审核演示和结果", "可演示原型、使用说明、评估报告和导师审核材料", "明确支持范围、已知问题及后续开发项", "待开发"),
]


FIELD_ROWS = [
    ("record_id", "记录ID", "string", "必须", "标识一条证据记录", "版本变化保留父记录关联"),
    ("document_id", "文献ID", "string", "必须", "绑定具体全文文件或页面版本", "不能只用易重复的论文简称"),
    ("article_family_id", "论文族ID", "string", "必须", "关联预印本、期刊版及同篇不同文件", "用于去重与开发测试分组"),
    ("bibliographic_identity", "题录信息", "object", "必须", "题名、作者、载体、年份、DOI/PMID等", "缺少标识符时保留空值并记录人工身份核对，不虚构DOI"),
    ("source_version", "来源版本", "object", "必须", "文件校验和、获取来源、版本、获取时间", "修改文件后产生新文本版本"),
    ("document_access", "全文状态", "enum", "必须", "full_text/abstract_only/unavailable", "仅摘要的结果单列，不能作为全文抽取完成"),
    ("source_location", "证据位置", "object", "必须", "PDF物理页码与文本块/框，或HTML/JATS元素路径与章节", "物理页码从1开始；印刷页码另存；HTML不虚构页码"),
    ("text_version", "解析文本版本", "string", "必须", "绑定特定解析器与文本层", "定位基于此版本，不能跨版本沿用字符区间"),
    ("original_quote", "原文表述", "string", "必须", "从来源文本中选择的证据片段", "与中文翻译、摘要和改写分开保存"),
    ("quote_span", "字符区间", "object", "必须", "在指定块内的start和end", "按Unicode字符计数，使用[start,end)；跨块片段分段定位"),
    ("context", "相关上下文", "object", "必须", "必要的前后文、标题、表头、脚注或图注", "上下文不足时标记needs_context，不猜测条件"),
    ("disease_or_lesion", "疾病或病灶范围", "object", "必须", "癌种、病灶类型及其证据", "肺结节不自动等于肺癌；未明示保持未知"),
    ("modality", "影像模态", "object", "必须", "CT、MRI或原文其他范围及证据", "同段涉及不同模态时分别关联，不能只继承论文标题"),
    ("sequence_or_phase", "序列或扫描期相", "object_or_null", "可空", "例如MRI序列或CT增强期相的原始表述", "没有来源信息时不补写"),
    ("feature_name_raw", "特征原始名称", "string_or_null", "可空", "原文使用的名称", "不强制匹配已有35项清单"),
    ("feature_category", "特征类别建议", "enum", "必须", "位置、大小、形态、边缘、密度/信号、强化、内部结构、关系或待分类", "这是候选标签，不是医学确认结果"),
    ("evidence_type", "表述类型", "enum", "必须", "特征提及、定义、影像观察、判读条件或关联结论", "只列名的文本不能冒充完整特征定义"),
    ("assertion", "否定与确定性", "object", "必须", "肯定、否定、不确定、比较或条件性", "保留原文措辞；未否定不等于已经证实"),
    ("applicability", "适用条件", "object", "必须", "病例范围、检查情境、初始/再分期及其他限定", "不同适用条件的结论不能无条件合并"),
    ("numeric_expressions", "原始数值与单位", "array", "必须", "数值、单位、比较符和相关对象的原文区间", "无数值时为空数组；不直接转为生成参数或临床规则"),
    ("normalized_terms", "规范化名称建议", "array", "必须", "可选同义词映射和候选特征ID", "没有映射时保留新术语；不改变原文"),
    ("translation_zh", "中文译文", "string_or_null", "可空", "供阅读的衍生译文", "明确为翻译，不用于冒充来源原文"),
    ("evidence_validation", "原文定位检查", "object", "必须", "校验结果、校验方式和异常", "字符串可定位不等于语义与医学结论已经正确"),
    ("duplicate_and_conflict_links", "重复与冲突关联", "array", "必须", "与其他证据的关系", "保留各来源，冲突不静默覆盖"),
    ("extraction_trace", "运行记录", "object", "必须", "模型、提示、解析器版本、所读块和重试", "能够追溯一次候选证据的形成过程"),
    ("review_status", "人工审核状态", "enum", "必须", "pending/approved/rejected/needs_context", "自动核对通过不等于人工approved"),
    ("review_events", "审核记录", "array", "必须", "操作、审核人、时间、修改理由和版本", "尚未发生的审核不能伪造"),
    ("handoff_status", "下游交付状态", "enum", "必须", "candidate_only/approved_for_T2", "只有人工审核通过的证据进入T2已审核输入"),
]


ACCEPTANCE_ROWS = [
    ("T1-A01", "论文身份", "输入简称、同名或同篇不同版本", "核对题名、作者、年份、载体和标识符；不确定则标记待核实", "题录与版本记录"),
    ("T1-A02", "全文可用性", "只能获取摘要或全文无法访问", "明确标记abstract_only或unavailable，允许上传；不宣称全文处理完成", "获取状态与处理记录"),
    ("T1-A03", "解析质量", "双栏PDF或混入页眉页脚", "检查阅读顺序并保持证据块定位；明显混乱进入待处理", "原页与解析块对照"),
    ("T1-A04", "扫描文档", "PDF缺少可靠文字层", "标记需要OCR；首版不静默产生空结果或伪造文本", "识别结果与失败状态"),
    ("T1-A05", "原文可定位", "大模型返回的句子不在对应文本中", "补读或重新抽取；仍不匹配则拒绝为已核对证据", "字符范围及验证日志"),
    ("T1-A06", "翻译分离", "原文为英文、界面同时提供中文", "英文原文与中文译文分别存储，中文不替换证据", "导出记录与界面"),
    ("T1-A07", "否定与限制", "文本含否定、可能、条件或能力限制", "保留这些措辞及必要上下文，禁止改成无条件肯定结论", "人工金标准和错误分析"),
    ("T1-A08", "癌种与模态", "同篇涉及肺结节和肺癌、CT和MRI", "分别关联局部上下文；缺失时保持未知，不自动等同", "来源片段与候选标签"),
    ("T1-A09", "目标范围", "遇到治疗、生存、基因或纯算法性能段落", "不把缺少视觉特征内容的段落作为目标证据；保留排除原因", "正反例检查"),
    ("T1-A10", "表格与图注", "特征表述依赖表头、脚注或图注", "保留必要上下文和表/图标识；解析不足时转人工", "定位与上下文记录"),
    ("T1-A11", "新增特征", "发现既有清单未列出的视觉特征", "保留原文并标待分类，不因不在35项清单中删除", "新术语记录"),
    ("T1-A12", "多来源与冲突", "多篇表述重复或结论条件不同", "关联去重但保留原文、出处和条件；冲突进入审核", "关联记录"),
    ("T1-A13", "用户修改", "修改特征标签、原文选择或审核结论", "保留历史；原文选择变化重新校验，新增内容必须有来源", "审核版本记录"),
    ("T1-A14", "人工审核门禁", "自动检查通过但尚未人工审核", "仅可作为候选导出，不能标为已审核知识", "候选与审核导出比较"),
    ("T1-A15", "运行控制", "解析失败、超时或证据重试耗尽", "有界停止并显示原因，可按版本恢复，不重复造记录", "任务状态与运行账本"),
    ("T1-A16", "评估划分", "同一论文的PDF/HTML或预印本/期刊版", "按论文族保持在同一组；测试文献不用于提示调优", "开发测试清单"),
    ("T1-A17", "召回率计算", "只有模型找出的片段被人工检查", "只能报告这些结果的核对情况；没有完整金标准时不报告完整召回率", "金标准范围和TP/FP/FN"),
    ("T1-A18", "下游交付", "T2读取已审核文献证据", "能够还原原文、来源、上下文和审核版本；不附加未经验证的数学约束", "JSONL/CSV与接口核对"),
]


TECH_SOURCES = [
    {"id": "T1-DOC01", "title": "PyMuPDF Text extraction documentation",
     "url": "https://pymupdf.readthedocs.io/en/latest/recipes-text.html",
     "supports": "PDF文字、文本块及坐标提取的候选实现接口。",
     "limits": "解析能返回文本和位置不代表多栏阅读顺序、表格语义或医学内容自动正确。"},
    {"id": "T1-DOC02", "title": "PMC For Developers",
     "url": "https://pmc.ncbi.nlm.nih.gov/tools/developers/",
     "supports": "可用于程序访问PMC相关数据的官方服务说明。",
     "limits": "服务覆盖与允许取得全文的范围分别核对；不承诺任意DOI都能自动取得全文。"},
    {"id": "T1-DOC03", "title": "PMC OA Web Service API",
     "url": "https://pmc.ncbi.nlm.nih.gov/tools/oa-service/",
     "supports": "开放获取资料及文件信息的官方查询渠道候选。",
     "limits": "实施时按官方当前接口和使用范围接入，取得失败转人工上传。"},
]


def hierarchy():
    return {
        "version": PARENT_VERSION, "updated": DATE,
        "parent_task": {
            "id": "T0", "name": "医学读片大模型图文训练数据生成工具",
            "objective": "基于医学特征和用户需求，动态建模、生成并筛选可交付的图文训练数据",
            "scope_status": "原总任务保留",
        },
        "current_priority": "T1",
        "subtasks": [
            {"id": "T1", "parent_id": "T0", "name": CHILD_NAME,
             "role": "从权威医学文献取得有出处的肿瘤视觉特征表述",
             "dependencies": [], "development_status": "not_started",
             "planning_status": "completed_for_review",
             "outputs_to": ["T2"], "plan_file": "子任务T1/医学论文肿瘤视觉特征提取智能体_开发计划.docx",
             "excluded_dependencies": ["图像生成算法论文", "医学影像数据集", "MAISI", "三维生成GPU"]},
            {"id": "T2", "parent_id": "T0", "name": "特征整理及需求审核与动态数学建模",
             "dependencies": ["T1"], "other_inputs": ["医生口述", "用户任务与数据需求"],
             "dependency_scope": "使用文献证据时依赖T1；医生口述输入路径可独立推进",
             "development_status": "not_started", "outputs_to": ["T3", "T4"]},
            {"id": "T3", "parent_id": "T0", "name": "约束驱动的医学影像生成",
             "dependencies": ["T2"], "development_status": "not_started", "outputs_to": ["T4"]},
            {"id": "T4", "parent_id": "T0", "name": "图文数据检查筛选与交付",
             "dependencies": ["T2", "T3"], "development_status": "not_started", "outputs_to": ["T5"]},
            {"id": "T5", "parent_id": "T0", "name": "系统集成与整体效果验证",
             "dependencies": ["T1", "T2", "T3", "T4"], "development_status": "not_started",
             "note": "可分阶段接入各模块，最终完成原总任务"},
        ],
        "handoff_T1_to_T2": {
            "payload": "已人工审核的原文证据及来源、适用条件、候选标签和审核版本",
            "not_inferred": ["原文未给出的医学特征", "统一临床结论", "已验证生成约束", "最优化目标"],
        },
        "status_note": "本文件记录任务分解与开发计划，不表示智能体已经实现或实际提取已完成",
    }


def plan():
    return {
        "id": "T1", "parent_id": "T0", "version": CHILD_VERSION, "date": DATE,
        "name": CHILD_NAME, "status": "development_plan",
        "planning_complete": True, "development_started": False,
        "goal": "从医学论文中提取肿瘤视觉特征的原文表述并保留可核对的出处、上下文与人工审核",
        "initial_scope": {
            "disease_groups": ["肺癌相关肿瘤/结节语境", "结肠癌", "直肠癌"],
            "imaging_scope": ["肺部CT", "结肠癌CT", "直肠癌MRI"],
            "primary_inputs": ["用户上传文本型PDF", "用户提供可访问HTML/JATS全文链接"],
            "language": "优先验证英文全文；中文及OCR能力分别列为扩展验收项",
            "excludes": ["医学影像像素识别", "图像生成", "动态数学建模", "自动认定所有论文权威",
                         "根据大模型记忆补写医学特征", "将翻译或摘要当成原文"],
        },
        "schedule": {
            "assumption": "1名开发者约20个工作日；医学标注复核协作和访问受限等待另计",
            "estimated_developer_days": 20,
            "duration_label": "建议四周，按里程碑调整",
            "weeks": [
                {"week": 1, "workdays": "D1-D5", "deliverable": "范围、启动文献、标注规则和记录契约"},
                {"week": 2, "workdays": "D6-D10", "deliverable": "解析、定位及工具型智能体抽取原型"},
                {"week": 3, "workdays": "D11-D15", "deliverable": "证据与上下文检查、标签和人工审核"},
                {"week": 4, "workdays": "D16-D20", "deliverable": "导出、测试集评估、演示和开发说明"},
            ],
            "tasks": [dict(zip(
                ["id", "week", "start_day", "end_day", "estimated_developer_days", "dependency_ids",
                 "name", "work", "deliverable", "exit_criteria", "status"], row))
                for row in TASK_ROWS],
        },
        "evaluation": {
            "status": "planned_not_run",
            "target_corpus_documents": 20,
            "initial_available_fulltexts_target": 5,
            "suggested_split": {"development": 12, "held_out_test": 8},
            "split_unit": "article_family",
            "gold_standard": "在预先明确的完整范围中人工标注所有符合任务的片段、上下文和必要反例",
            "suggested_targets_pending_review": {
                "relevance_precision": 0.90,
                "relevance_recall": 0.80,
                "approved_export_locatable_fraction": 1.0,
                "negation_and_condition_retention": 0.95,
            },
            "note": "目标值是工程验收建议，不是已有实验成绩；分母为0时报告不适用，不编造精确率或召回率",
        },
        "technical_candidates": {
            "pdf_parser": "PyMuPDF及原页定位；复杂版面单列异常",
            "structured_fulltext": "HTML/JATS原生结构，保留章节和元素路径",
            "language_model": "可替换推理接口；Qwen3-8B为本地候选，先验证抽取与成本",
            "orchestration": "单智能体加工具调用和状态机，记录失败、补读、重试和人工转交",
            "storage": "文件文献库加SQLite记录的候选方案",
            "frontend": "最小文献证据审核界面，后续接入总系统",
        },
        "implementation_note": "以上为开发选型建议，尚未安装、运行或验证这些候选组件",
    }


def build_child_document():
    d = Word(
        title="子任务T1医学论文肿瘤视觉特征文本提取智能体开发计划",
        subject="原毕业设计的上游文献证据子任务、开发范围、四周计划及验收",
        header="医学读片图文数据生成总课题  /  子任务T1开发计划",
    )
    d.p("医学论文肿瘤视觉特征文本提取智能体", "Title")
    d.p("原毕业设计子任务 T1 开发计划", "Subtitle")
    d.p(f"版本 {CHILD_VERSION}    日期 {DATE}    状态：开发计划，尚未开始实现", "Reference")
    d.p("本子任务落实总课题中“特征要求来自权威医学文献”的环节，提取论文里已有的肿瘤视觉特征表述，保留原文、出处和适用条件，经人工审核后交给后续特征整理与动态建模模块。")

    d.h("一 与原总任务的关系")
    d.p("父任务T0仍为医学读片大模型图文训练数据生成工具。T1是其中的上游子任务，也是当前优先开发内容；完成T1后继续推进原课题的其他模块。")
    d.table(["任务", "职责", "本次关系"], [
        ["T1 当前子任务", "医学论文视觉特征原文提取、证据定位、审核和导出", "本计划直接安排"],
        ["T2", "文献及医生口述特征整理、用户需求审核和动态数学建模", "接收T1审核通过的文献证据"],
        ["T3", "根据目标和约束适配医学影像生成算法", "后续任务"],
        ["T4", "生成图文数据的检查、筛选与交付", "后续任务"],
        ["T5", "系统集成和整体效果验证", "逐步整合T1—T4"],
    ], [2000, 4700, 2500])
    d.p("流程关系：医学论文 → T1可追溯原文证据 → T2特征和需求模型 → T3生成 → T4筛选交付。医生口述仍可直接进入T2。T1中的结构化字段服务于保存证据，不代表已经完成T2的医学规范化或数学建模。")
    d.p("T1可覆盖CT与MRI文献，不需要先取得MRI影像数据或开发MRI生成器；两篇尚未唯一定位的生成算法论文也不阻塞T1。")

    d.h("二 目标和首版范围")
    d.p("目标是把指定医学论文中与肿瘤影像视觉特征有关的表述找出来，并让审核者能回到原文核对。提取原文是主交付，候选标签、翻译和归类作为可编辑的辅助信息。")
    d.table(["范围", "首版安排"], [
        ["疾病与模态", "肺部CT、结肠癌CT、直肠癌MRI相关论文；保留结节与确诊癌症的区别"],
        ["文献输入", "用户上传文本型PDF或提供可访问HTML/JATS全文链接；DOI/PMID用于身份核对与允许渠道的全文查询"],
        ["语言", "优先验证英文论文，原文保持原语言；中文翻译另存。中文全文和OCR分别规划与验收"],
        ["特征内容", "位置、大小、形态、边缘、密度或信号、强化、内部结构及明确的邻近关系等原文"],
        ["表述类型", "区分特征提及、定义、影像观察、判读条件和关联结论；必要时保留负面和限制性表述"],
        ["首版扩展边界", "支持正文和可靠解析的图注、简单表格；复杂跨页表格、扫描件和图内文字转待处理，后续增加能力"],
    ], [2000, 7200])
    d.p("不将治疗方案、生存结局、基因指标或纯算法性能自动作为视觉特征。相关段落若同时包含明确的影像视觉描述，可单独提取该部分并保留上下文。影像学分级、分期或诊断规则须作为带条件的来源表述保存，不直接变为生成约束。")
    d.p("已有35项清单仅作为候选标签和开发提示，其中的工程元数据不自动成为医学视觉特征。首版必须保留清单之外的新术语，避免把旧清单当成封闭答案。")

    d.h("三 文献来源与权威性处理")
    d.p("先处理选定论文，不以自动搜遍全部医学文献作为首版完成条件。优先启动资料是专业学会共识、术语表和同行评议研究；来源类型、发表年份、版本和适用范围分别记录，不能由模型给出一个“权威”标签后直接采信。")
    for text in [
        "对照出版者、PubMed/PMC或专业学会记录，核对完整题名、作者、载体、年份和DOI/PMID；无法唯一定位时等待补充材料。",
        "登记全文是否可获得、文件版本及校验和。能查到摘要不代表已取得全文；自动获取失败可由用户上传。",
        "预印本、期刊版和修订版本保留关联。同一论文的不同版本不能作为独立样本分到开发和测试两侧。",
        "对可查到的更正、撤稿或更新状态予以标记；没有查到相关信息时不声称已排除所有问题。",
        "医学资料的表述仍需保留原始适用条件；资料来源核对和医学结论审核分别进行。",
    ]:
        d.bullet(text)
    d.p("启动文献可优先使用此前已识别的LIDC-IDRI原始研究、Fleischner术语表、结肠癌CT报告共识、SAR直肠癌术语共识及ESGAR直肠MRI共识。它们是待取得并解析的启动候选，不代表本轮已经形成完整抽取语料。")

    d.h("四 智能体工作流程")
    d.p("采用一个智能体调用受约束工具，并以状态机记录处理进度。智能体根据文献类型、解析质量和证据核对结果决定读取哪些上下文、是否重试以及何时转人工；由工具完成确定性的定位和字符串校验。")
    d.table(["步骤", "工作", "失败或不确定时"], [
        ["1 导入与核对", "登记文献身份、文件和全文状态", "同名或身份不清转待核实；获取失败允许上传"],
        ["2 解析与定位", "建立文字块与页面坐标，或读取HTML/JATS结构", "文字缺失或阅读顺序混乱标记；扫描件转待OCR"],
        ["3 分块与候选", "结合章节和上下文读取；词表仅作辅助", "保留处理覆盖记录，避免候选过滤使召回不可解释"],
        ["4 原文抽取", "返回文本区间及候选癌种、模态和特征类别", "不根据模型记忆补写内容"],
        ["5 证据核对", "定位原句，检查条件、否定、不确定和上下文依赖", "重新读取邻近内容或重试；达到预算后转人工"],
        ["6 关联与审核", "关联重复证据、保留冲突，供用户审核", "未知字段保持未知；原文修改重新核对"],
        ["7 导出交付", "分别导出全部候选和人工审核通过的证据", "未审核记录不标为已审核知识"],
    ], [1800, 4100, 3300])
    d.p("建议工具接口包括：文献身份核对、全文读取、解析、读取指定文本块、查找原文区间、上下文补读、记录保存和导出。首版不要求引入多个智能体，也不让模型自行执行任意代码。")
    d.p("任务状态至少包含：待确认配置、待获取全文、解析中、抽取中、校验中、待人工审核、已完成、部分完成和失败。暂停等待全文或人工审核时保存进度；配置中的最大重试数与资源预算先展示给用户确认。")
    d.p("影响抽取任务的默认配置，例如文献范围、语言、模型、批量规模、重试预算和导出格式，逐项提示并等待用户确认、修改或知悉。原文本身没有说明的疾病、模态或条件保留未知，不用默认医学事实补齐。")
    d.p("文献原文是处理数据。任务行为由已定义工具和流程控制；不让论文中的命令性文字改变输出范围或工具权限。")

    d.h("五 输出内容和原文定位")
    d.p("一条结果以一项可核对的表述为中心，附带足够上下文。不同特征共用一个句子时可以关联同一证据，不必为了凑记录数重复复制。")
    d.table(["字段组", "必须保存的内容"], [
        ["文献身份", "文献ID、论文族、题名、作者、发表信息、标识符和具体文件/网页版本"],
        ["原文证据", "原文、上下文、解析文本版本、来源位置和字符区间"],
        ["候选描述", "疾病或病灶范围、模态、序列/期相、特征名称、类别、表述类型"],
        ["限定信息", "否定、不确定、比较、适用条件以及数值与单位的原始表述"],
        ["质量与审核", "自动定位检查、重试记录、人工状态、修订历史和下游交付状态"],
    ], [2000, 7200])
    d.p("PDF使用从1开始的物理页码，并记录文本块或框；印刷页码另存。HTML/JATS记录章节、元素ID或路径，不虚构页码。字符位置绑定指定文本版本，采用Unicode字符的半开区间[start,end)。")
    d.p("解析时的换行、断词或连字符规范化需要保留映射。原文能够匹配解析文本，只证明定位一致；还需通过原页抽检确认解析忠实，并通过人工评估检查特征和上下文是否正确。")
    d.p("完整字段规范见配套抽取结果字段规范.csv。英文原文、中文译文、归纳解释及规范化名称分字段保存，后两者不能覆盖来源原文。")

    d.h("六 人工审核和下游接口")
    d.p("审核页面同时显示论文身份、原文位置、上下文和候选标签。用户可以接受、拒绝、要求补读，或修改标签、分类和译文；选择新的原文范围后重新定位校验并保留版本。")
    d.p("审核状态采用pending、approved、rejected和needs_context。自动定位通过不会自行变成人工approved。批量确认也应明确展示所选范围并记录真实操作。")
    d.p("导出JSONL作为T2的机器输入，CSV用于浏览和审核。导出区分候选结果与已审核结果；T2接收已审核原文证据、来源和条件，并在自己的审核流程中完成特征规范化与数学建模。")
    d.p("本子任务的审核对象是“提取是否忠实、关联是否正确”，总系统后续需求审核的对象是“用户希望生成什么、采用什么目标和约束”。两套状态和版本分别记录。")

    d.h("七 技术选型与运行条件")
    d.table(["环节", "候选方案", "选择理由与待验证点"], [
        ["PDF解析", "PyMuPDF文字、文本块和位置提取 [T1-DOC01]", "便于原页定位；需验证多栏、断词、表格和特殊字体"],
        ["结构化全文", "优先保留HTML/JATS的章节和元素定位 [T1-DOC02、T1-DOC03]", "按官方当前接口核对可取得范围；不保证任意论文可自动下载"],
        ["大模型", "可替换推理接口；本地候选Qwen3-8B [MOD03]", "先检验原文抽取和结构化输出，不预设医学能力与显存表现"],
        ["编排与存储", "单智能体工具调用、状态机、文件库及SQLite候选", "首版保持可追踪与可恢复，不以复杂框架作为目标"],
        ["审核界面", "最小原文证据审核页面", "支持来源回看、修订与导出，后续整合到总系统"],
    ], [1700, 3500, 4000])
    d.p("PDF解析和确定性校验可先在CPU环境开发。大模型推理可用可访问的模型服务或本地模型，实际选择在实现阶段依据可用资源、接口与成本确定；本子任务不继承MAISI三维生成的80GB级显存要求。")
    d.p("本轮仅制定计划，没有调用付费模型、下载权重或运行抽取。实现前锁定组件版本，记录模型、提示、解析器、参数和预算。")

    d.h("八 四周开发安排")
    d.p("排期按1名开发者约20个工作日估算，以开发开始日为D1。医学标注复核协作和全文访问受限的等待另计；若暂时缺少条件，先完成可独立推进的模块并报告依赖。扫描件OCR和复杂跨页表格作为后续扩展，不计入该四周核心范围。")
    d.table(["周次", "主要工作", "周末可检查的成果"], [
        ["第1周 D1—D5", "范围和金标准规则、启动文献、人工试标、数据与任务契约", "确认提取对象和反例；有可读取全文及可核对样例"],
        ["第2周 D6—D10", "文献解析、定位、分块及智能体工具抽取", "能对指定论文输出带来源的候选原文"],
        ["第3周 D11—D15", "原文与上下文校验、标签去重和人工审核界面", "能发现无法定位的输出并让用户审核修订"],
        ["第4周 D16—D20", "导出、冻结测试集、对照评估、修复与演示材料", "完整证据导出、真实效果报告和可演示原型"],
    ], [1800, 4200, 3200])
    d.p("开发任务清单.csv列出14项工作、先后依赖、预计工日和完成证据。任务清单中的“待开发”不会因本计划生成而变为已完成。")

    d.h("九 评估与验收")
    d.p("建议以20篇可获得全文的文献为试验目标，按论文族分为12篇开发、8篇保留测试；初期先取得至少5篇启动文献。此数量为工作量建议，不能把未取得或解析失败的论文当成已评估。")
    d.p("测试前明确全文或固定完整章节的评估范围，由人工标注其中全部符合定义的表述和必要上下文。若只评估固定章节，应报告章节范围；若只核对模型已找到的结果，不能据此报告完整召回率。医学准确性复核需适当专业人员参与。")
    d.table(["项目", "定义或方法", "建议目标"], [
        ["相关性精确率", "正确抽取数/(正确抽取数+误抽取数)", "≥90%，待导师审核"],
        ["相关性召回率", "正确抽取数/(正确抽取数+漏抽取数)，以完整标注范围为分母", "≥80%，待导师审核"],
        ["原文可定位性", "已审核导出记录均能按绑定版本回到原文；原页忠实性另抽检", "已审核导出100%可定位；不等于100%医学正确"],
        ["条件保留", "在明确含否定、不确定或条件的标注样本上核对", "保留率建议≥95%，单列样本数和重要错误"],
        ["运行效果", "按癌种、模态、文献、输入类型分别统计", "报告耗时、调用量、失败数与人工修订量"],
    ], [1800, 4400, 3000])
    d.p("这些是待审核的工程目标，不是实验成绩。记录匹配采用同一文献版本内的一对一匹配，综合相关表述和必要上下文；边界不同与语义错误分别分析，重复结果不重复计作正确。分母为0时报告不适用，同时给出TP、FP、FN等原始计数。")
    d.p("对照包括关键词检索、直接大模型抽取和带工具定位/核对的智能体。使用相同文献范围与预先说明的资源预算，记录人工工作量，不预设智能体一定优于基线。")
    d.p(f"配套验收清单提供{len(ACCEPTANCE_ROWS)}个情景，覆盖同名文献、摘要冒充全文、原文定位、否定条件、新特征、审核和下游交付。")

    d.h("十 风险与分阶段处理")
    d.table(["实际问题", "首版处理", "后续扩展"], [
        ["全文获取受限", "允许上传并记录只获取摘要或失败状态", "扩展正式数据服务和文献发现"],
        ["PDF版面或OCR错误", "保留原页并检测低质量解析；复杂情况转人工", "增加OCR及复杂表格能力并单独评价"],
        ["模型漏抽或补写", "保留处理覆盖、原文定位、补读和有限重试，人工审核", "依据错误分析调整候选和上下文策略"],
        ["结论脱离语境", "保存疾病、模态、条件、否定和版本；缺失保持未知", "增加专门的医学术语与关系审核"],
        ["同义与冲突", "只建议映射，保留多来源及不同条件", "在T2中经审核建立统一特征库"],
        ["缺少医学复核条件", "先报告原文忠实性和普通信息抽取结果", "获得适当复核后再报告医学相关性结论"],
    ], [1900, 4200, 3100])
    d.p("完成本子任务的最低交付是：可运行抽取原型、可回看的原文证据、人工审核与导出、开发测试记录和效果报告。自动全网检索、完整OCR、全部癌种和后续生成算法均不作为首版完成前提。")

    d.h("十一 交付物与近期启动项")
    for text in [
        "原总任务的任务分解及T1与T2的输入输出关系，已写入任务分解.json和总方案v0.2。",
        "本子任务开发计划、14项开发工作、抽取字段规范和18项验收情景。",
        "实际开发阶段交付智能体代码、运行说明、文献登记及版本记录、候选与已审核证据文件。",
        "实际评估阶段交付人工金标准、冻结测试清单、对照结果和错误分析；不以本计划替代这些成果。",
    ]:
        d.bullet(text)
    d.p("启动顺序为T1.01范围与标注规则，随后T1.02取得启动全文和核对身份，再实施解析与证据定位。导师审核重点是提取边界、首批文献、人工复核安排，以及是否接受本计划的范围和建议验收目标。")

    d.h("十二 来源与工具说明")
    d.p("医学启动资料沿用此前核对的文献身份，部分仍需取得完整可解析全文；技术建议已定向核对官方说明。文献提取计划不构成对各医学结论的独立验证。")
    source_ids = {"MED01", "MED02", "MED03", "MED04", "MED05", "MOD03"}
    for src in [s for s in SOURCES if s["id"] in source_ids]:
        label = f"[{src['id']}] {src['title']}"
        if src.get("doi"):
            label += " DOI: " + src["doi"]
        d.link(label, src["url"])
    for src in TECH_SOURCES:
        d.link(f"[{src['id']}] {src['title']}", src["url"])
    tool = next(s for s in SOURCES if s["id"] == "TOOL01")
    d.p("检索工具流程来源单列，不作为医学依据：", "Reference")
    d.link("[TOOL01] Kassis, T., Agarwal, V., He, Y., Patel, D., & Brueckner, A. M. (2026). "
           + tool["title"] + ". DOI: " + tool["doi"], tool["url"])
    return d


def save_csv(path, header, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(header)
        writer.writerows(rows)


def inspect_doc(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        members = set(z.namelist())
        for name in members:
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        doc = ET.fromstring(z.read("word/document.xml"))
        relroot = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        rels = {r.attrib["Id"]: r for r in relroot}
        for link in doc.iter(q("w:hyperlink")):
            assert link.attrib[q("r:id")] in rels
        for rel in relroot:
            if rel.attrib.get("TargetMode") != "External":
                assert "word/" + rel.attrib["Target"] in members
        text = "\n".join(t.text or "" for t in doc.iter(q("w:t")))
        return {"text": text, "tables": len(doc.findall(".//" + q("w:tbl")))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite", action="store_true",
                        help="Replace only this builder's planning outputs.")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    outputs = [
        HIERARCHY_FILE, PARENT_DOC, CHILD_DOC,
        OUT / "开发任务清单.csv", OUT / "抽取结果字段规范.csv",
        OUT / "验收清单.csv", OUT / "开发计划.json", OUT / "资料来源.json",
        OUT / "材料检查结果.json",
    ]
    if not args.overwrite and any(p.exists() for p in outputs):
        raise SystemExit("Refusing to overwrite existing T1 outputs without --overwrite")
    original = BASE / "毕业设计实施方案_导师审核稿.docx"
    original_hash = hashlib.sha256(original.read_bytes()).hexdigest() if original.exists() else None

    h, p = hierarchy(), plan()
    write_json(HIERARCHY_FILE, h)
    write_json(OUT / "开发计划.json", p)
    save_csv(OUT / "开发任务清单.csv",
             ["编号", "周次", "起始工作日", "结束工作日", "预计开发工日", "依赖", "工作项",
              "具体工作", "交付物", "完成条件", "状态"], TASK_ROWS)
    save_csv(OUT / "抽取结果字段规范.csv",
             ["字段", "名称", "类型", "是否必需", "用途", "核对要求"], FIELD_ROWS)
    save_csv(OUT / "验收清单.csv",
             ["编号", "类别", "情景", "预期行为", "证据", "状态"],
             [(*row, "未执行") for row in ACCEPTANCE_ROWS])
    write_json(OUT / "资料来源.json", {
        "checked_date": DATE,
        "scope": "开发计划的启动医学资料和技术接口，非已完成抽取语料",
        "sources": [s for s in SOURCES if s["id"] in {"MED01", "MED02", "MED03", "MED04", "MED05", "MOD03", "TOOL01"}] + TECH_SOURCES,
    })
    build_child_document().save(CHILD_DOC)
    build_document(document_version=PARENT_VERSION, include_subtask=True).save(PARENT_DOC)

    ids = {t[0] for t in TASK_ROWS}
    assert len(ids) == len(TASK_ROWS)
    assert sum(t[4] for t in TASK_ROWS) == 20
    assert sorted(day for t in TASK_ROWS for day in range(t[2], t[3] + 1)) == list(range(1, 21))
    for t in TASK_ROWS:
        for dep in t[5].split(";") if t[5] else []:
            assert dep in ids
            dep_task = next(row for row in TASK_ROWS if row[0] == dep)
            assert dep_task[3] < t[2], (dep, t[0])
    assert len({f[0] for f in FIELD_ROWS}) == len(FIELD_ROWS)
    assert len({r[0] for r in ACCEPTANCE_ROWS}) == len(ACCEPTANCE_ROWS)
    child, parent = inspect_doc(CHILD_DOC), inspect_doc(PARENT_DOC)
    for phrase in ["与原总任务的关系", "四周开发安排", "原文", "20个工作日", "尚未开始实现"]:
        assert phrase in child["text"], phrase
    assert "当前优先子任务为T1" in parent["text"]
    assert "T1中的结构化字段" not in parent["text"] or "T2" in parent["text"]
    assert all(t["parent_id"] == "T0" for t in h["subtasks"])
    assert h["current_priority"] == p["id"] == "T1"
    assert not p["development_started"]
    if original_hash:
        assert hashlib.sha256(original.read_bytes()).hexdigest() == original_hash
    for file, expected in [
        (OUT / "开发任务清单.csv", len(TASK_ROWS)),
        (OUT / "抽取结果字段规范.csv", len(FIELD_ROWS)),
        (OUT / "验收清单.csv", len(ACCEPTANCE_ROWS)),
    ]:
        with file.open(encoding="utf-8-sig", newline="") as fp:
            assert len(list(csv.DictReader(fp))) == expected
    report = {
        "status": "planning_material_checked",
        "checks": {
            "parent_child_relationship": "pass",
            "schedule_dependencies_and_20_workdays": "pass",
            "docx_xml_and_relationships": "pass",
            "csv_and_json_consistency": "pass",
            "original_parent_document_preserved": original_hash is not None,
        },
        "counts": {"development_tasks": len(TASK_ROWS), "developer_days": 20,
                   "result_fields": len(FIELD_ROWS), "acceptance_scenarios": len(ACCEPTANCE_ROWS)},
        "not_done": ["智能体开发", "真实论文批量抽取", "模型运行与效果评估", "Word/WPS分页预览"],
    }
    write_json(OUT / "材料检查结果.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    for path in outputs:
        print(str(path.relative_to(ROOT)))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate the stage-gated T1 discussion plan and an audited OSS shortlist.

Only planning materials are changed. No candidate package, model, agent or paid
service is installed or executed. Component choices and unagreed SLOs stay open.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import ROOT, DATE, SOURCES, Word, build_document, q, write_json
from build_t1_plan import FIELD_ROWS

BASE = ROOT / "方案"
OUT = BASE / "子任务T1"
VERSION = "0.2"
PARENT_VERSION = "0.3"
PARENT_DOC = BASE / "毕业设计实施方案_导师审核稿_v0.3.docx"
CHILD_DOC = OUT / "医学论文肿瘤视觉特征提取智能体_开发计划.docx"


REPO_CARDS = [
    ("google/langextract", "证据抽取", "原文位置关联、结构化抽取、长文本分块与结果可视化",
     "重点对照候选", "需要上游PDF解析；未对齐输出及医学语境仍需独立校验；领域准确率取决于模型和任务",
     "代码Apache-2.0；使用的模型与服务另核对"),
    ("docling-project/docling", "文档解析", "版面、阅读顺序、OCR、表格和统一文档表示",
     "解析对照候选", "实际医学PDF的漏字、阅读顺序、表格上下文、位置精度和部署成本须实测",
     "代码MIT；各模型许可分别核对"),
    ("opendatalab/MinerU", "文档解析", "复杂PDF、OCR、表格、页面与文本块定位及文档任务接口",
     "解析对照候选", "版本与硬件差异大；须核查实际页数覆盖、结果格式和服务能力，不能默认全篇已读",
     "MinerU Open Source License，基于Apache-2.0并有附加条款；模型另核对"),
    ("grobidOrg/grobid", "学术文档结构", "科学论文题录、正文分节、参考文献结构和部分PDF坐标",
     "学术PDF对照候选", "不是医学视觉特征抽取器；扫描输入及各结构的坐标覆盖需单列评估",
     "代码Apache-2.0"),
    ("datalab-to/marker", "文档解析", "PDF转换、OCR及表格结构，可保留结构化输出",
     "补充解析对照候选", "代码和模型许可分开；自带API的使用范围与负载能力不能直接等同于生产服务",
     "代码Apache-2.0；模型为修改版OpenRAIL-M条款"),
    ("langchain-ai/langgraph", "智能体编排", "持久状态、人工介入、暂停恢复和长期运行流程",
     "编排对照候选", "恢复与幂等需结合任务设计；框架不能保证医学准确率",
     "代码MIT"),
    ("pydantic/pydantic-ai", "智能体与结构校验", "类型化输出、工具参数校验、模型适配和持久执行集成",
     "编排或结构层备选", "结构正确不代表医学语义正确；是否采用及与其他框架的职责需要对照后决定",
     "代码MIT"),
    ("Future-House/paper-qa", "科学文献证据组织", "科学文献检索、证据聚合和带引用回答",
     "架构参考", "文献问答与全面特征抽取的目标不同；不能把少量相关段落检索当作全篇覆盖",
     "代码Apache-2.0"),
    ("infiniflow/ragflow", "文档平台与引用", "文档摄取、解析、检索及引用回看的人机交互",
     "产品与架构参考", "整个平台可能增加部署成本；不会因此自动满足医学抽取精确率或召回率",
     "代码Apache-2.0；所用模型和服务另核对"),
    ("opendatalab/OmniDocBench", "解析评测", "文档解析的数据标注维度和评估方法",
     "评测方法参考", "通用解析评测不能代替肿瘤视觉特征抽取和医学语境评测",
     "代码Apache-2.0；数据集条款另核对"),
]


DEPLOYMENT_SOURCES = [
    {"id": "CLOUD01", "title": "Alibaba Cloud ECS application deployment with Docker",
     "url": "https://help.aliyun.com/en/ecs/user-guide/deploy-applications",
     "supports": "ECS可采用Docker构建与部署；Linux云主机可作为可移植服务的候选宿主。",
     "limits": "未核对用户地域下具体规格报价或进行网络/性能测试，不能据此断言全场景最优。"},
    {"id": "CLOUD02", "title": "Tencent Cloud CVM Docker setup",
     "url": "https://intl.cloud.tencent.com/zh/document/product/213/37516",
     "supports": "Linux CVM搭建Docker的官方说明，可作为与ECS比较的通用云主机候选。",
     "limits": "具体发行版和安装方式在实施时核对，不照搬旧版本系统示例。"},
    {"id": "CLOUD03", "title": "AutoDL container environment",
     "url": "https://www.autodl.com/docs/env/",
     "supports": "普通容器实例内部不支持Docker；官方说明使用Docker可另租裸金属服务器。",
     "limits": "普通容器、裸金属和私有云不是同一产品，不能将一种限制套到全部产品。"},
    {"id": "DEPLOY01", "title": "Docker Compose overview",
     "url": "https://docs.docker.com/compose/",
     "supports": "使用配置管理多服务、网络和数据卷，可作为可重复部署的交付方式。",
     "limits": "仍需约定宿主机、模型资源和API配置；当前没有已经可运行的Compose应用。"},
    {"id": "DEPLOY02", "title": "Docker Compose GPU support",
     "url": "https://docs.docker.com/compose/how-tos/gpu-support/",
     "supports": "满足宿主GPU和Docker运行条件后，Compose可向服务分配GPU设备。",
     "limits": "不能靠容器镜像自动消除宿主驱动与GPU运行环境的前置条件。"},
    {"id": "DEPLOY03", "title": "Docker Compose startup order and health checks",
     "url": "https://docs.docker.com/compose/how-tos/startup-order/",
     "supports": "以服务健康检查和依赖关系控制启动次序。",
     "limits": "容器启动不等于依赖服务已就绪；需通过实际部署和恢复测试。"},
    {"id": "CLOUD04", "title": "Alibaba Cloud ECS GPU instance families",
     "url": "https://help.aliyun.com/zh/ecs/user-guide/gpu-accelerated-compute-optimized-and-vgpu-accelerated-instance-families-1",
     "supports": "gn8is包含L20单卡48GB等规格，可作为解析性能对照的资源候选。",
     "limits": "具体地域可售情况、卡型适配和实际端到端性能需核对；未租用或实测。"},
]


STAGES = [
    {
        "id": "S0", "name": "场景与验收契约", "dependencies": [],
        "work": "逐篇交互和公开PDF输入已确认；继续确认PDF类型、语言与影像范围、云资源/费用、审核方式和具体响应目标。",
        "deliverables": "范围与能力矩阵；需求决策记录；验收契约初稿。",
        "gate": "公开PDF上传、逐篇快速交互、付费云端LLM及Docker交付方向已确认；剩余架构和验收关键事项完成讨论。",
        "fail_action": "保留待讨论项，不将候选模型、数据库、框架或数值门槛当作已决定。",
        "status": "awaiting_discussion",
    },
    {
        "id": "S1", "name": "评测语料与人工金标准", "dependencies": ["S0"],
        "work": "按癌种、论文体裁、出版来源、语言、版式和文本层类型分层准备语料，制定标注和匹配规则。",
        "deliverables": "版本化文献清单、人工金标准、开发/回归/封存测试划分和质量门槛。",
        "gate": "覆盖约定的主要输入类型和未见文献；评估范围内人工完整标注；审核方法、样本量和阈值获确认。",
        "fail_action": "补足薄弱分层或修订标注指南；不得用模型已找到的片段冒充完整召回金标准。",
        "status": "not_started",
    },
    {
        "id": "S2", "name": "文档解析对照与证据定位", "dependencies": ["S1"],
        "work": "在同一PDF测试集和硬件上比较候选解析器，形成文本、版面、表格、图注和原页定位的统一表示。",
        "deliverables": "可复现解析对照、文本到原页映射、页数覆盖账本、资源和失败记录。",
        "gate": "达到约定的解析忠实性、内容覆盖、定位和资源门槛；据实测与用户共同选择组件。",
        "fail_action": "调整候选或解析策略；未达到要求的输入类型明确标记不支持或需复核，范围变更与用户讨论。",
        "status": "not_started",
    },
    {
        "id": "S3", "name": "跨文献抽取与语境校验", "dependencies": ["S2"],
        "work": "比较可替换模型和抽取方案，核对原文、跨段上下文、否定、条件、单位及新术语；记录全篇处理覆盖。",
        "deliverables": "抽取原型、候选证据、模型与提示版本、语境错误分析及运行成本。",
        "gate": "在独立新论文和约定分层上达到质量底线；有出处但语义错误的结果仍计错；组件经讨论后定案。",
        "fail_action": "修正解析/分块/抽取环节或增加证据；不能通过任意降低阈值、只抽简单论文来过关。",
        "status": "not_started",
    },
    {
        "id": "S4", "name": "可恢复任务与人工审核", "dependencies": ["S3"],
        "work": "实现逐篇上传和快速交互反馈、明确进度、可选渐进候选、有限重试、缓存幂等、恢复、审核和导出。",
        "deliverables": "可交互系统、审核事件和导出契约、故障与恢复演练记录。",
        "gate": "在约定审核模式下不混淆候选与批准结果；中断恢复不丢失证据，不重复计入交付。",
        "fail_action": "修复任务状态、幂等或审核链路；不把人工等待隐藏在自动处理性能数字中。",
        "status": "not_started",
    },
    {
        "id": "S5", "name": "端到端质量与性能验收", "dependencies": ["S4"],
        "work": "在目标负载与硬件下评估未见癌种/来源/版式、并发、长文档、失败恢复、成本和质量回归。",
        "deliverables": "封存测试报告、分层质量指标、P50/P95延迟、吞吐量、资源峰值及已知限制。",
        "gate": "满足已约定质量与性能契约；结果包含失败文献、原始计数、人工工作量和可复现配置。",
        "fail_action": "按错误回到相关阶段修复并回归；测试集被用于调优后需透明记录并重新保留独立验收数据。",
        "status": "not_started",
    },
    {
        "id": "S6", "name": "目标环境交付与T2衔接", "dependencies": ["S5"],
        "work": "验证约定环境的安装运行、数据备份与迁移、日志和升级回归；按证据契约交付T2。",
        "deliverables": "可运行交付包、操作说明、能力矩阵、验收记录和下游接口样例。",
        "gate": "用户能在目标环境重复完成上传、抽取、审核、导出和恢复；保留发布配置和评测证据。",
        "fail_action": "修正目标环境问题，不将演示视频或单篇成功案例作为整体可用性的替代。",
        "status": "not_started",
    },
]


TASKS = [
    ("T1-R01", "S0", "", "冻结已确认范围与待讨论边界", "不固定癌种、题名或术语；首版只接收用户上传PDF", "范围与决策清单"),
    ("T1-R02", "S0", "T1-R01", "确认资源和验收模式", "与用户讨论模型部署、费用/出网、批量和交互、审核模式", "可执行的评测和部署约束"),
    ("T1-R03", "S1", "T1-R02", "分层建设评测语料", "按场景覆盖组织开发、回归和独立验收文献，不写死论文数量", "文献、版本和划分清单"),
    ("T1-R04", "S1", "T1-R03", "人工完整标注与判分规则", "定义相关表述、必要上下文、反例和一对一匹配；处理医学分歧", "金标准和标注指南"),
    ("T1-R05", "S1", "T1-R04", "冻结质量与性能门槛", "结合使用需求和开发组基线确认各项阈值，保留封存测试", "用户确认的验收契约"),
    ("T1-R06", "S2", "T1-R05", "锁定候选解析版本", "核对代码、模型、后端和版本兼容，按约定资源准备对照", "可复现候选配置"),
    ("T1-R07", "S2", "T1-R06", "建立统一证据文档表示", "保留原始文件、文字块、坐标、表格上下文和文本规范化映射", "文档和证据位置契约"),
    ("T1-R08", "S2", "T1-R07", "比较解析质量与性能", "在同一医学语料上量化漏字、顺序、覆盖、定位、耗时和资源", "解析选型实测及决策"),
    ("T1-R09", "S3", "T1-R08", "比较模型与证据抽取", "比较LangExtract等机制与直接抽取基线，模型与框架不预先绑定", "同条件抽取质量/成本对照"),
    ("T1-R10", "S3", "T1-R09", "验证原文和跨段语境", "检查位置、模态、癌种、否定、条件、指代和数值单位", "证据与语境校验"),
    ("T1-R11", "S3", "T1-R10", "处理新特征和多来源", "允许未知类别和新增术语；关联重复、差异和冲突，不静默覆盖", "跨癌种证据关联"),
    ("T1-R12", "S3", "T1-R11", "验证全篇覆盖与泛化", "记录全部应处理页面/块；分层检查新来源和新癌种漏抽", "抽取阶段验收材料"),
    ("T1-R13", "S4", "T1-R12", "实现上传及任务状态", "PDF校验、范围确认、队列、进度、取消、状态和失败原因", "可交互任务入口"),
    ("T1-R14", "S4", "T1-R13", "实现恢复与幂等", "按文件、版本和处理配置标识结果，限制重试并避免重复记账", "中断与重试演练"),
    ("T1-R15", "S4", "T1-R14", "实现审核和修订", "原页回看、字段修改、证据重选和真实审核事件；审核模式待确认", "可追溯审核界面"),
    ("T1-R16", "S4", "T1-R15", "实现证据导出", "候选与批准数据分开，保留原文、映射、上下文和版本", "JSONL/CSV与检查报告"),
    ("T1-R17", "S5", "T1-R16", "运行封存质量评估", "报告每个约定分层、失败输入、关键错误及整体指标", "独立质量报告"),
    ("T1-R18", "S5", "T1-R17", "运行目标负载性能评估", "测量分环节和端到端延迟、吞吐、峰值资源、调用成本及退化", "目标条件下的性能报告"),
    ("T1-R19", "S5", "T1-R18", "修复与回归", "升级组件、提示或模型均执行固定回归，必要时增加独立验收数据", "质量与运行回归证据"),
    ("T1-R20", "S6", "T1-R19", "验证交付环境", "锁定运行方式、依赖和模型配置，验证备份、恢复和日志", "可重复运行的交付包"),
    ("T1-R21", "S6", "T1-R20", "核对T2接口", "交付原文证据和审核状态，不提前注入未经验证的生成约束", "接口契约与样例"),
    ("T1-R22", "S6", "T1-R21", "完成实际操作验收", "按真实使用流程完成上传、抽取、审核、导出和故障恢复", "用户可核对的验收记录"),
]


DECISIONS = [
    ("D01", "论文输入", "confirmed", "首个可交互版本由用户上传PDF；不加入自动检索或链接获取",
     "用户本轮明确答复", "无待选项", "S0", "输入能力与数据获取职责"),
    ("D02", "模型部署与资源", "partly_confirmed", "计划租用可调整云服务器，允许付费云端LLM；具体供应商、资源和调用配置未冻结",
     "用户明确允许租云服务器、动态调配与付费API", "按预算、地域、文档负载和实测决定CPU/GPU与模型", "S0/S2/S3", "模型和解析候选、成本与性能"),
    ("D03", "实际使用与性能", "partly_confirmed", "首版逐篇交互、需要较快响应；典型页数、等待目标和并发尚未明确",
     "用户明确选择逐篇交互处理", "分别约定反馈、首条候选、全文完成的目标", "S0/S1", "交互方式、P95与资源容量"),
    ("D04", "语言和图像领域边界", "to_discuss", "是否仅沿用总课题CT/MRI起点；是否纳入其他模态及中英文；PDF类型覆盖",
     "", "明确支持矩阵；癌种和论文题名始终不写死", "S0", "评测分层、OCR和候选模型"),
    ("D05", "人工审核模式", "to_discuss", "是否全量审核、风险分层审核，及可获得的医学复核条件",
     "", "全量；首轮全量后分层；其他经验证策略", "S0/S1", "误差风险、人工成本与交付流程"),
    ("D06", "质量门槛与错误优先级", "to_discuss", "可接受漏抽/误抽、上下文关键错误与分层最低要求",
     "", "先明确用途和关键错误，再结合开发组基线冻结门槛", "S1", "质量目标、测试样本量与是否可交付"),
    ("D07", "关键技术组合", "after_benchmark", "解析器、抽取框架、模型、编排和回退方案",
     "", "候选对照后共同确定；当前未选定组合", "S2/S3", "准确率、可维护性、资源和使用条件"),
    ("D08", "部署与存储形态", "partly_confirmed", "优先Docker/Compose以便其他人部署；数据库、服务拆分、持久卷和GPU配置待选择",
     "用户明确希望Docker方便他人部署", "在明确宿主机前置条件下验证可重复启动、健康检查和恢复", "S0/S4/S6", "运行维护、协作及证据可追溯"),
    ("D09", "资料与第三方数据流", "partly_confirmed", "首版仅公开已发表论文，并允许付费云端LLM；发送粒度、服务区域和日志保留待讨论",
     "用户选择首版仅公开已发表论文", "明确PDF存储、发送的文本/文件范围及第三方服务，不默认为内部资料也可上传", "S0", "模型与解析服务、存储与日志"),
    ("D10", "云厂商、地域与预算", "partly_confirmed", "用户主要在国内，服务器和LLM预算暂不约束，API费用另算；优先响应和稳定性",
     "用户明确国内使用、预算足够", "首选部署候选为阿里云ECS/GPU ECS，腾讯CVM为对照；规格与地域实测后确定", "S0/S2", "网络时延、部署方式、资源与GPU选择"),
    ("D11", "渐进展示与完成条件", "confirmed", "先展示首批候选，再继续处理全文并标明进度；具体时延目标另行讨论",
     "用户明确选择渐进展示首批候选并继续全文", "已选择渐进展示；部分候选和全文完成状态分开", "S0/S4", "交互时延、上下文再核对与导出状态"),
]


METRICS = [
    ("Q01", "解析内容覆盖", "约定页面/块中被可靠处理的内容；漏页、阅读顺序和关键表格分别统计", "人工对照原页与块清单", None, "S2"),
    ("Q02", "特征抽取精确率", "TP/(TP+FP)，一对一判定相关表述及必要上下文；重复记录不重复计为TP", "完整金标准和错误案例", None, "S3/S5"),
    ("Q03", "特征抽取召回率", "TP/(TP+FN)，分母来自完整标注范围；失败文献不从总体指标中悄然删除", "完整金标准与处理覆盖", None, "S3/S5"),
    ("Q04", "原文与位置忠实性", "位置、文本版本和原文对应；字符匹配与原页OCR忠实性分别评价", "自动校验加原页人工核对", None, "S2/S3/S5"),
    ("Q05", "医学语境保留", "否定、不确定、条件、模态、癌种和数值单位，按关键错误类型分别统计", "医学相关人工标注及分歧处理", None, "S3/S5"),
    ("Q06", "跨分层泛化", "未参与开发的癌种、出版来源、论文体裁和版式上的质量及最低分层表现", "论文族划分与封存测试", None, "S5"),
    ("Q07", "人工修订量", "每篇/每条记录的审核时间和需要修订的比例，不能混入自动运行时间", "实际审核事件与计时", None, "S4/S5"),
    ("P01", "逐篇交互延迟", "上传后反馈、首条可审核候选、全文自动完成分别统计P50/P95，并拆分排队、解析、模型与核对耗时", "约定硬件、页数/版式、模型及冷/热启动条件；人工等待单列", None, "S4/S5"),
    ("P02", "吞吐与并发", "在约定质量底线下的论文/小时、页/分钟、队列稳定性和成功率", "固定负载与原始运行日志", None, "S5"),
    ("P03", "资源与成本", "CPU/RAM/显存峰值、磁盘与缓存、模型输入输出量及每篇实际成本", "资源采样与调用/缓存账本", None, "S2/S3/S5"),
    ("R01", "故障恢复", "超时、限流、崩溃、取消与重启后的状态一致性、重复交付和证据完整性", "故障演练与幂等检查", None, "S4/S5"),
    ("R02", "可复现与升级回归", "固定版本可重复执行；组件、模型或提示变更后保留对照和回归结果", "发布配置、回归语料和检查记录", None, "S6"),
]


def load_candidates():
    data = json.loads((ROOT / "research/t1_open_source_candidates.json").read_text(encoding="utf-8"))
    evidence = json.loads((ROOT / "research/t1_open_source_readme_evidence.json").read_text(encoding="utf-8"))
    repo_map = {r["full_name"]: r for r in data["repositories"] if r.get("http_status") == 200}
    ev_map = {r["repo"]: r for r in evidence["records"]}
    results = []
    for name, layer, borrow, role, limits, license_note in REPO_CARDS:
        r, e = repo_map[name], ev_map.get(name, {})
        results.append({
            "repository": name, "url": r["html_url"], "stars_at_check": r["stargazers_count"],
            "checked_at": r["checked_at"], "pushed_at": r["pushed_at"], "archived": r["archived"],
            "layer": layer, "borrow": borrow, "candidate_role": role, "limitations": limits,
            "license_note": license_note, "readme_url": e.get("readme_url"),
            "readme_sha": e.get("readme_sha"), "latest_release_seen": e.get("latest_release"),
            "implementation_benchmarked": False, "selected_for_implementation": False,
        })
    return results


def quality_contract():
    return {
        "status": "discussion_draft_not_accepted",
        "frozen": False,
        "threshold_policy": "原有精确率/召回率建议不再作为已确定门槛；本次不擅自填写新数字。",
        "metrics": [dict(zip(["id", "name", "definition", "measurement", "agreed_threshold", "stage"], r))
                    for r in METRICS],
        "fixed_evidence_invariants": [
            "候选、自动定位已核对与人工批准状态分别记录，不能互相冒充。",
            "已审核证据必须有真实来源和可还原定位；结构性检查通过不等于医学语义正确。",
            "解析或抽取失败、漏页及只处理部分内容不能宣称全文完成。",
            "原文、译文和归纳解释分别保存；未知与未评估不自动补成否定。",
        ],
        "benchmark_conditions": {
            "hardware": None, "model": None, "parser_versions": [],
            "typical_document_profiles": [], "batch_size": None, "concurrency": None,
            "latency_objective": None, "cost_budget": None,
        },
        "confirmed_usage": {
            "input": "user_uploaded_public_published_pdf",
            "mode": "interactive_one_document",
            "audience": "primarily_mainland_china",
            "priority": "quality_and_fast_response",
            "paid_cloud_llm_api_allowed": True,
            "budget_is_current_selection_constraint": False,
            "preferred_packaging": "Docker_or_Docker_Compose",
            "progressive_candidates_with_full_document_progress": True,
        },
        "approval_record": None,
    }


def revised_plan(candidates):
    return {
        "task_id": "T1", "parent_id": "T0", "version": VERSION, "date": DATE,
        "status": "revised_discussion_plan",
        "user_confirmed_changes": [
            "适用于持续新增的肿瘤相关医学论文，不固定为某几篇文献或癌种模板。",
            "按阶段成果验收推进，前一阶段未通过不得当作已完成进入下一阶段。",
            "质量与性能面向真实使用，关键实现细节需要和用户讨论。",
            "首个可交互版本由用户上传PDF，不加入自动检索论文或链接获取。",
            "首版只处理公开已发表论文，按逐篇交互方式使用，需要较快响应。",
            "允许付费云端LLM，计划租用可调整云服务器，优先Docker部署。",
            "使用者主要在国内，服务器和LLM预算暂不约束，API费用另算。",
            "采用渐进展示：尽快显示首批候选，再继续全文处理并标明进度。",
        ],
        "scope": {
            "input": "user_uploaded_pdf",
            "publication_scope": "publicly_published_papers_only",
            "usage_mode": "interactive_one_document",
            "presentation": "progressive_candidates_then_full_completion",
            "automatic_paper_discovery": False, "fetch_link_as_input": False,
            "fixed_paper_allowlist": None, "fixed_cancer_allowlist": None,
            "domain": "肿瘤相关医学论文中的肿瘤医学图像视觉特征表述",
            "existing_project_context": "总课题以放射学CT/MRI为起点；本子任务其他模态、语言和PDF类型由D04讨论。",
            "benchmark_examples_are_not_scope_limits": True,
            "new_term_behavior": "保留新术语和待分类记录，不被已有35项清单拒绝。",
            "outcome_without_visual_evidence": "处理覆盖完整后可报告未找到符合任务的表述；处理不完整则标明部分完成。",
        },
        "progression": {
            "type": "stage_acceptance",
            "rule": "每阶段有交付物、证据和验收记录；未通过则修正，不能按时间或演示效果自动推进。",
            "current_stage": "S0", "stages": STAGES,
            "acceptance_records": [], "all_implementation_stages_completed": False,
        },
        "tasks": [
            dict(zip(["id", "stage", "dependencies", "name", "work", "deliverable"], t))
            | {"status": "planned_not_started"} for t in TASKS
        ],
        "architecture": {
            "status": "candidate_boundaries_only_not_selected",
            "boundaries": [
                "PDF上传与文献身份/版本记录",
                "解析适配与原页/文本块统一证据表示",
                "全文覆盖调度、原文抽取与语境核对",
                "持久任务、人工审核和证据导出",
                "可复现评测、运行观测和T2接口",
            ],
            "note": "这些是职责边界；不等于已选定框架、解析器、模型、数据库或部署方式。",
        },
        "deployment_direction": {
            "user_confirmed": {
                "rent_adjustable_cloud_servers": True, "paid_llm_api_allowed": True,
                "prefer_docker_for_redeployment": True, "audience": "primarily_mainland_china",
                "budget_not_current_constraint": True,
            },
            "recommended_first_vendor_candidate": "Alibaba Cloud ECS / GPU ECS",
            "comparison_vendor": "Tencent Cloud CVM / GPU CVM",
            "ordinary_autodl_container_as_full_compose_host": "not_recommended",
            "gpu_test_candidate": "L20 48GB class if supported and available in chosen region; not a final specification",
            "instance_region_model_and_service_split": "to_discuss_after_measured_comparison",
            "sources": DEPLOYMENT_SOURCES,
            "not_done": ["租用服务器", "安装组件", "调用LLM抽取", "测量响应性能"],
        },
        "open_source_candidates": candidates,
        "decisions": [
            dict(zip(["id", "topic", "status", "detail", "confirmed_basis", "options", "decision_stage", "impact"], d))
            for d in DECISIONS
        ],
        "quality_contract_file": "质量与性能验收契约.json",
        "implementation_started": False,
        "benchmarks_run": False,
        "development_time_budget": None,
        "fixed_benchmark_document_count": None,
        "supersedes": "历史版本/v0.1",
    }


def build_doc(candidates):
    d = Word(
        title="子任务T1肿瘤医学论文视觉特征文本提取智能体阶段开发计划修订讨论稿",
        subject="通用肿瘤文献抽取、阶段验收、开源项目调研、质量性能与待讨论决策",
        header="医学读片图文数据生成总课题 / 子任务T1阶段开发计划",
    )
    d.p("肿瘤医学论文视觉特征文本提取智能体", "Title")
    d.p("子任务 T1 阶段开发计划  修订讨论稿", "Subtitle")
    d.p(f"版本 {VERSION}    日期 {DATE}    状态：待讨论关键实现决策，尚未开发或实测", "Reference")
    d.p("本子任务面向用户持续上传的肿瘤相关医学论文，抽取医学图像中肿瘤视觉特征的原文表述，保留可还原的出处、上下文和审核状态，向总课题T2交付文献证据。")
    d.p("本轮已确认：论文与癌种不写死；按阶段成果验收推进；首版由用户上传公开已发表PDF并逐篇交互，先展示首批候选、继续处理全文并标明进度；计划租云服务器，允许付费LLM API，优先Docker交付。使用者主要在国内，预算暂不约束，具体实现继续共同讨论。")

    d.h("一 子任务定位与范围修订")
    d.table(["项目", "当前约定"], [
        ["父任务", "T0医学读片大模型图文训练数据生成工具；T1仍为其上游文献证据子任务"],
        ["后续衔接", "T1原文证据 → T2特征整理及动态建模 → T3影像生成 → T4筛选交付；T5负责整合集成"],
        ["首版输入", "用户上传公开已发表PDF，不加入自动检索论文、网页全文链接导入或自动下载"],
        ["使用方式", "逐篇交互和较快响应；分别约定上传反馈、首条可审核候选及全文完成时延"],
        ["部署方向", "国内用户为主；租用可调整云服务器；允许付费LLM API；优先Docker；预算暂不约束"],
        ["可扩展范围", "不固定论文题名、癌种或作者；通过能力矩阵与实际评测说明适用范围"],
        ["已有文献和清单", "此前列举的论文与35项清单仅作启动资料和候选标签，不构成输入白名单或穷尽答案"],
        ["尚需讨论", "语言、PDF类型、影像模态范围、部署、审核模式以及质量与性能门槛"],
    ], [2000, 7200])
    d.p("适用于各种论文指处理持续新增文献的能力；自动发现新论文是另一项功能，不纳入本首版。PDF中解析出的题录可供身份核对，是否调用外部元数据服务另受出网和部署约束，不据此扩展为文献搜索。")
    d.p("总课题已以放射学CT/MRI为起点；是否在本子任务首版同时支持超声、PET、内镜或病理图像相关文本，以及中英文、扫描和混合PDF，列入D04共同确认。不能未经讨论排除复杂输入，也不能在未经验证时承诺所有格式都支持。")
    d.p("肺部、结肠和直肠文献可继续用于启动和回归，同时应增加未参与开发的癌种、出版来源、论文类型和版式。系统发现新术语时保留原文并待分类，不靠固定词表封闭输入。")

    d.h("二 阶段推进与验收规则")
    d.p("阶段状态采用：未开始 → 开发中 → 提交验收 → 验收通过；未通过则进入修正。下一阶段启动依赖上一阶段的验收证据和明确记录，不依赖经过多少时间或完成一次演示。")
    d.p("本稿定义阶段和候选方法，不记录尚未发生的验收。当前处于S0讨论阶段；研究资料查验不等于S2或S3已经通过。")
    for stage in STAGES:
        d.p(stage["id"] + " " + stage["name"], bold=True)
        d.table(["事项", "内容"], [
            ["前置条件", "无前置开发阶段，需讨论关键边界" if not stage["dependencies"] else "；".join(stage["dependencies"]) + "已验收"],
            ["具体工作", stage["work"]], ["交付物", stage["deliverables"]],
            ["通过条件", stage["gate"]], ["未通过处理", stage["fail_action"]],
        ], [1800, 7400])
    d.p("阶段内可比较多种候选和修复问题。若后续发现上游解析、模型或需求变更影响已通过内容，应回到相关阶段补充验证，不能用旧成绩覆盖新版本。详细工作项见开发任务清单.csv。")

    d.h("三 开源项目调研与借鉴范围")
    d.p("以下仓库已核对GitHub官方身份、Star、维护状态以及README中的相关能力；Star为2026-11-01查询快照。当前未安装或运行候选，也没有据仓库宣传得出本医学任务的性能结论。")
    for c in candidates:
        d.link(c["repository"] + " 约" + f"{c['stars_at_check']/1000:.1f}" + "k Star", c["url"])
        d.p("所在层：" + c["layer"] + "；角色：" + c["candidate_role"] + "。", "Reference")
        d.p("可借鉴：" + c["borrow"] + "。")
        d.p("本任务中的边界：" + c["limitations"] + "。", "Reference")
        d.p("使用条件记录：" + c["license_note"] + "。", "Reference")
    d.p("Star仅用于初筛，最终依据同一医学文献集上的忠实性、召回、语境保留、速度、资源、恢复和维护成本。解析器、抽取器、编排框架及评测工具职责不同，不要求把所有候选拼装到一个系统中。")
    d.p("具体注意项：LangExtract的原文对齐不能代替医学语义验证，未对齐记录仍需业务处理；MinerU不同命令和模式的页面覆盖可能不同；Marker代码与模型条款分别记录；GROBID部分结构才提供坐标。对照时保留代码、模型、配置、模式和完整处理范围，不能仅比较默认命令输出。")
    d.p("维护状态和README说明基于查询快照，发布标签与主分支文档可能不完全对应。正式对照需锁定实际版本和模型，并以运行结果说明兼容性；不自动将“latest”或名称含候选发布标记的版本视为最终部署选择。")

    d.h("四 候选架构的职责边界")
    d.p("候选流程为：PDF上传 → 文献与文件版本记录 → 解析和统一证据文档 → 覆盖调度与原文抽取 → 原文/语境校验 → 约定的人工审核 → 带证据和版本的导出 → T2。")
    d.table(["职责", "可比较的实现方向", "暂不锁定的内容"], [
        ["解析与原页映射", "Docling、MinerU、GROBID、Marker等在同一医学PDF集上的比较", "主解析器、备用路径、OCR和硬件"],
        ["抽取与证据核对", "LangExtract机制与直接受约束抽取基线；固定原文与语境契约", "模型、提示策略、分块和复核组合"],
        ["长期任务和审核", "LangGraph、PydanticAI或轻量状态机的持久化和人工介入方案", "编排框架、任务队列和数据库"],
        ["产品界面与集成", "参考文档平台的上传、进度、原页回看与导出交互", "界面技术、单机或多人部署"],
    ], [1800, 3900, 3500])
    d.p("保留原始PDF、解析文本版本及字符到原页的映射。文本规范化或OCR修复不能覆盖原始证据；可疑匹配用于提出候选或人工复核，不自动作为逐字原文通过。原文、中文译文和模型归纳分别存储。")
    d.p("全文覆盖必须显式记账。关键词检索或RAG可帮助排序和补读，但只读取Top-K片段不能证明全篇特征已抽取；未处理页面和失败文本块应形成部分完成或失败状态。没有视觉特征的论文也可以是有效输入，完整处理后如实报告未找到相关表述。")
    d.p("根据解析质量、未覆盖内容、上下文依赖和证据检查结果，智能体可调用补读、重抽、核对或人工转交工具。工具调用范围、有界重试、缓存和幂等按验收契约实现，不能通过无限循环或静默切换低质量模型掩盖问题。")

    d.p("逐篇交互已确认采用渐进展示。实现候选策略还可以包括解析服务保温、复用已核对缓存、先处理可靠文字层并继续处理难页；这些策略需对照质量与完整性，尚未锁定具体组合。")
    d.p("部分结果始终明确标为候选或部分完成；全文补读如改变语境判断，应重新核对相关证据并保留修订。首批候选出现不能等同于完整抽取完成，完整导出仍受覆盖、质量与约定审核规则约束。")

    d.h("五 面向真实使用的质量验证")
    d.p("质量包括解析忠实性、目标相关性、覆盖与召回、原文出处、否定和适用条件、跨癌种泛化，以及审核后的实际修订量。原有草稿中的精确率/召回率建议不再作为已确定标准；新的门槛须与用户讨论后冻结。")
    d.p("评测语料按癌种、论文体裁、来源、语言、版式和文本层类型分层，至少区分开发数据、固定回归数据和独立验收数据。相同论文的文件、HTML/PDF版本或预印本/期刊版按论文族关联，不跨开发和测试制造独立样本假象。")
    d.p("人工金标准在预先明确的完整范围中标注全部相关原文和必要上下文，记录医学分歧及裁决。仅核对模型已经找到的结果不能计算完整召回。测试范围之外和解析失败的内容必须在覆盖报告中说明。")
    d.p("跨癌种、来源和版式分别报告，不能只看整体均值。新癌种的处理失败、没有证据时的正确拒答、引用他人研究时的归属、治疗/生存/基因等非目标段落，均进入正反例评估。")
    d.p("已审核导出记录必须满足真实来源和可还原定位的结构性底线；自动字符定位通过不能推导为医学语义正确。对于错误原文、否定翻转、条件丢失和错误癌种/模态，应分别报告关键错误，不能只用平均分掩盖。")

    d.h("六 性能和运行可靠性验证")
    d.p("具体性能门槛依赖实际使用方式与可用硬件，当前保持待讨论。报告必须附模型、解析模式、输入类型和页数、并发、缓存、冷/热启动及资源配置，避免把不同条件下的宣传数字直接比较。")
    d.table(["维度", "需要记录的内容"], [
        ["交互延迟", "上传后反馈、首条可审核候选和全文完成分别统计P50/P95；分环节记录排队、解析/OCR、模型及核对；人工等待单列"],
        ["吞吐与负载", "符合质量底线时的论文/小时、页/分钟、并发成功率、积压和服务稳定性"],
        ["资源与成本", "CPU/RAM/显存峰值、磁盘/缓存、模型调用量、输入输出量及每篇实际成本"],
        ["失败恢复", "超时、限流、解析异常、取消、进程重启和重复上传后的状态与结果一致性"],
        ["升级回归", "模型、提示、组件或OCR模式变更后，质量和性能是否退化；保留可复现配置与回退方案"],
    ], [1800, 7400])
    d.p("P50/P95等统计需报告样本量和文档复杂度。并发优化、缓存、分层解析或回退方案必须在不降低已约定质量底线的前提下评估；缓存命中与首次处理分别报告。")

    d.p("国内云服务器与Docker部署建议", bold=True)
    d.p("根据国内使用、预算暂不约束、允许云端LLM和Docker可移植交付的已知条件，工程首选候选为阿里云ECS/GPU ECS，腾讯云CVM作为对照。它们具备完整Linux Docker宿主路径；这是一项部署方向建议，不是已证明阿里云在所有场景速度最优。[CLOUD01、CLOUD02]")
    d.p("AutoDL普通容器实例内部不支持Docker，不作为首版完整Compose应用的默认宿主；其裸金属是不同产品，可另行评估。这个限制不妨碍将其用作独立解析试验环境，但不能据此承诺原Compose项目直接运行。[CLOUD03]")
    d.p("若最终解析路径需要GPU，可把单卡L20 48GB级别列为一组性能对照候选，依据具体地域供给、解析模型和实测响应再定规格。若主要瓶颈在云端LLM或网络，增加GPU不能直接解决，必须拆分计时。[CLOUD04]")
    d.p("Docker交付需包括锁定版本的镜像和Compose配置、配置示例、模型/解析服务初始化、健康检查、持久化卷、迁移及恢复说明。CPU/API路径与GPU路径可作为候选配置，具体服务拆分待组件对照后确定。")
    d.p("“一键部署”的验收含义是在明确宿主机、Docker和API配置等前置条件后，可用同一配置启动系统并通过真实操作测试；GPU宿主驱动和容器运行条件另行校验，不能声称镜像解决所有前置条件。[DEPLOY01—DEPLOY03]")
    d.p("数据出网指把PDF、文本或日志发送到服务器之外的服务，包括LLM或外部解析API；不等于网络是否能连通。当前仅公开已发表论文且允许付费API。建议明确原PDF保存位置、发送必要文本的粒度、服务区域和日志保留，具体数据流和服务选择仍需讨论。")

    d.h("七 需要与用户共同决定的实现事项")
    for did, topic, status, detail, basis, options, stage, impact in DECISIONS:
        d.p(did + " " + topic + "（" + status + "）", bold=True)
        d.p(detail + "。")
        if basis:
            d.p("已确认依据：" + basis + "。", "Reference")
        if status != "confirmed":
            d.p("讨论选项：" + options + "。影响：" + impact + "。在" + stage + "阶段确定。", "Reference")
    d.p("已确认公开PDF上传、逐篇快速交互及渐进展示、国内用户、预算暂不约束、可租云服务器及付费API、优先Docker。具体等待目标、输入覆盖、审核方式和组件选择继续讨论。其他事项在对应阶段集中处理，不要求用户逐一决定普通函数、文件或内部变量。影响范围、数据流、质量和交付的变化需在实施前说明和确认。")

    d.h("八 结果契约和交付")
    d.p("继续采用证据记录的28个基础字段，包括文献身份、文件版本、原文位置、原文、上下文、病灶与模态、条件、标签建议、自动核对和真实审核事件。新增术语和缺失信息保持可表达，不由固定癌种枚举限制输入。")
    d.p("审核方式尚需讨论。在任何模式下，候选、自动定位已核对与人工批准状态必须分别记录；不能把模型自评变成人工批准。原文改选后重新校验并产生版本，翻译或归纳不能冒充引用。")
    d.p("最终交付需包含在目标环境可重复运行的程序、操作说明、版本配置、证据数据、评测与故障恢复结果及T2接口。单篇成功、漂亮界面或演示视频均不能替代独立文献集和实际负载上的验收。")
    d.p("本轮完成的是计划修订、开源候选核验与讨论项整理，未安装候选、运行医学论文抽取或做性能测试；各阶段均没有虚构的通过记录。")

    d.h("九 文件与来源")
    d.p("当前材料包括开发计划.json、开发阶段与验收.csv、开发任务清单.csv、开源项目调研.csv、待讨论实现决策.csv和质量与性能验收契约.json。旧稿移入历史版本/v0.1；当前任务分解指向修订讨论稿。")
    d.p("GitHub身份、Star、维护和README证据快照保存在research目录；本调研是候选筛选，不是已完成的技术基准测试。医学资料来源继续沿用已有记录，仅用于构建样例和评估覆盖。")
    for src in DEPLOYMENT_SOURCES:
        d.link("[" + src["id"] + "] " + src["title"], src["url"])
    tool = next(s for s in SOURCES if s["id"] == "TOOL01")
    d.p("检索工具流程来源单列，不作为医学或性能依据：", "Reference")
    d.link("Kassis, T., Agarwal, V., He, Y., Patel, D., & Brueckner, A. M. (2026). "
           + tool["title"] + ". DOI: " + tool["doi"], tool["url"])
    return d


def csv_write(path, header, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(header)
        writer.writerows(rows)


def inspect_doc(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if name.endswith((".xml", ".rels")):
                ET.fromstring(z.read(name))
        root = ET.fromstring(z.read("word/document.xml"))
        rels = {r.attrib["Id"]: r for r in ET.fromstring(z.read("word/_rels/document.xml.rels"))}
        for h in root.iter(q("w:hyperlink")):
            assert h.attrib[q("r:id")] in rels
        return "\n".join(t.text or "" for t in root.iter(q("w:t")))


def archive_previous():
    old = OUT / "开发计划.json"
    if not old.exists():
        return
    old_data = json.loads(old.read_text(encoding="utf-8"))
    if old_data.get("version") == VERSION:
        return
    folder = OUT / "历史版本" / ("v" + old_data.get("version", "unknown"))
    folder.mkdir(parents=True, exist_ok=True)
    hashes = {}
    for src in OUT.iterdir():
        if not src.is_file() or src.name == "当前版本.json":
            continue
        dst = folder / src.name
        if not dst.exists():
            shutil.copy2(src, dst)
        hashes[src.name] = hashlib.sha256(dst.read_bytes()).hexdigest()
    hfile = BASE / "任务分解.json"
    if hfile.exists():
        dst = folder / "原任务分解.json"
        if not dst.exists():
            shutil.copy2(hfile, dst)
    write_json(folder / "归档记录.json", {"archived_at": datetime.now(timezone.utc).isoformat(), "sha256": hashes})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--overwrite-current-revision", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    current = OUT / "开发计划.json"
    if current.exists():
        version = json.loads(current.read_text(encoding="utf-8")).get("version")
        if version == VERSION and not args.overwrite_current_revision:
            raise SystemExit("Current revision already exists; inspect changes before replacing.")
    archive_previous()
    candidates = load_candidates()
    p = revised_plan(candidates)
    write_json(current, p)
    write_json(OUT / "质量与性能验收契约.json", quality_contract())
    write_json(OUT / "当前版本.json", {
        "version": VERSION, "status": "discussion_draft",
        "plan_document": CHILD_DOC.name, "plan_data": "开发计划.json",
        "historical_version": "历史版本/v0.1", "architecture_frozen": False,
        "quality_thresholds_frozen": False, "stage_acceptances": [],
    })
    csv_write(OUT / "开发阶段与验收.csv",
              ["阶段", "名称", "前置阶段", "工作", "交付物", "通过条件", "未通过处理", "状态"],
              [[s["id"], s["name"], ";".join(s["dependencies"]), s["work"], s["deliverables"],
                s["gate"], s["fail_action"], s["status"]] for s in STAGES])
    csv_write(OUT / "开发任务清单.csv",
              ["编号", "阶段", "依赖", "工作项", "具体工作", "交付物", "状态"],
              [(*t, "待开发") for t in TASKS])
    csv_write(OUT / "开源项目调研.csv",
              ["仓库", "官方链接", "查询时Star", "查询时间UTC", "所在层", "可借鉴内容",
               "候选角色", "本任务局限", "许可记录", "最近推送", "最近所见发布标签", "已实测", "已选定"],
              [[c["repository"], c["url"], c["stars_at_check"], c["checked_at"], c["layer"], c["borrow"],
                c["candidate_role"], c["limitations"], c["license_note"], c["pushed_at"],
                (c["latest_release_seen"] or {}).get("tag_name", "未查到正式发布记录"), "否", "否"]
               for c in candidates])
    csv_write(OUT / "待讨论实现决策.csv",
              ["编号", "主题", "状态", "具体内容", "已确认依据", "讨论选项", "确定阶段", "影响"], DECISIONS)
    csv_write(OUT / "抽取结果字段规范.csv",
              ["字段", "名称", "类型", "是否必需", "用途", "核对要求"], FIELD_ROWS)
    csv_write(OUT / "验收清单.csv",
              ["编号", "名称", "定义", "测量依据", "已约定阈值", "阶段", "状态"],
              [[r[0], r[1], r[2], r[3], "待讨论", r[5], "未执行"] for r in METRICS])
    write_json(OUT / "资料来源.json", {
        "checked_date": DATE, "review_type": "official_repository_discovery_not_benchmark",
        "repository_candidates": candidates,
        "previous_medical_sources": [s for s in SOURCES if s["id"].startswith("MED") or s["id"] == "TOOL01"],
        "deployment_sources": DEPLOYMENT_SOURCES,
        "snapshot_files": ["research/t1_open_source_candidates.json",
                           "research/t1_open_source_readme_evidence.json"],
    })

    hpath = BASE / "任务分解.json"
    h = json.loads(hpath.read_text(encoding="utf-8"))
    h["version"] = PARENT_VERSION
    h["updated"] = DATE
    t1 = next(t for t in h["subtasks"] if t["id"] == "T1")
    t1.update({"planning_status": "revision_for_discussion", "plan_version": VERSION,
               "input": "user_uploaded_pdf", "fixed_paper_allowlist": None,
               "progression": "stage_acceptance", "current_stage": "S0",
               "architecture_frozen": False, "development_status": "not_started"})
    t1["plan_file"] = "子任务T1/" + CHILD_DOC.name
    h["current_parent_plan_file"] = PARENT_DOC.name
    h["status_note"] = "T1按用户补充修订，首版上传PDF、跨肿瘤文献、阶段验收；关键实现和门槛待讨论，原总任务保留。"
    write_json(hpath, h)
    build_doc(candidates).save(CHILD_DOC)
    build_document(document_version=PARENT_VERSION, include_subtask=True,
                   literature_plan_mode="stage_gated").save(PARENT_DOC)

    task_ids = {t[0] for t in TASKS}
    assert len(task_ids) == len(TASKS)
    seen = set()
    for t in TASKS:
        if t[2]:
            assert t[2] in seen
        seen.add(t[0])
    seen = set()
    for s in STAGES:
        assert set(s["dependencies"]) <= seen
        seen.add(s["id"])
    assert len({c["repository"] for c in candidates}) == len(REPO_CARDS)
    assert all(not c["selected_for_implementation"] and not c["implementation_benchmarked"] for c in candidates)
    assert p["scope"]["automatic_paper_discovery"] is False
    assert p["scope"]["fetch_link_as_input"] is False
    assert p["scope"]["fixed_paper_allowlist"] is None
    assert p["progression"]["acceptance_records"] == []
    assert all(m["agreed_threshold"] is None for m in quality_contract()["metrics"])
    text, parent_text = inspect_doc(CHILD_DOC), inspect_doc(PARENT_DOC)
    assert "阶段" in text and "用户上传PDF" in text
    assert "第1周" not in text and "20个工作日" not in text
    assert "论文文本提取智能体的范围、流程、四周排期和验收" not in parent_text
    assert "人工审核与四周计划范围" not in parent_text
    assert all(c["repository"] in text for c in candidates)
    with (OUT / "开发任务清单.csv").open(encoding="utf-8-sig", newline="") as fp:
        reader = csv.DictReader(fp)
        assert "周次" not in reader.fieldnames and "预计开发工日" not in reader.fieldnames
        assert len(list(reader)) == len(TASKS)
    report = {
        "version": VERSION, "status": "planning_revision_checked",
        "checks": {"stage_dependencies": "pass", "no_time_based_schedule": "pass",
                   "pdf_upload_scope": "pass", "unagreed_choices_not_frozen": "pass",
                   "official_repositories_and_snapshot_links": "pass",
                   "word_zip_xml_and_links": "pass"},
        "counts": {"stages": len(STAGES), "development_tasks": len(TASKS),
                   "repository_candidates": len(candidates), "result_fields": len(FIELD_ROWS),
                   "implementation_decisions": len(DECISIONS), "quality_performance_metrics": len(METRICS)},
        "not_done": ["用户未答复的实现决策", "组件安装与基准测试", "智能体开发", "医学效果与性能验证", "Word分页视觉预览"],
    }
    write_json(OUT / "材料检查结果.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(str(CHILD_DOC))
    print(str(PARENT_DOC))


if __name__ == "__main__":
    main()

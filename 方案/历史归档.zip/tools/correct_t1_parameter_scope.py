#!/usr/bin/env python3
"""Correct the T1/T2 boundary while preserving the user's edited DOCX.

Only selected text runs are replaced inside existing Office XML. Other ZIP
members and all unaffected paragraphs are preserved, with original files backed
up before writing. The advisor document is the authoritative T1 scope source.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import html
import json
from pathlib import Path
import re
from datetime import datetime, timezone
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import ROOT, write_json

BASE = ROOT / "方案"
T1 = BASE / "子任务T1"
MAIN = T1 / "T1智能体开发计划_导师审核简版.docx"
AUTHORITY = "T1智能体开发计划_导师审核简版.docx"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
BACKUP = T1 / "历史版本" / ("参数边界修正前_" + STAMP)
P_RE = re.compile(r"<w:p(?:\s[^>]*)?>.*?</w:p>", re.S)
T_RE = re.compile(r"(<w:t\b[^>]*>)(.*?)(</w:t>)", re.S)
W = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
CHANGES = []


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, data):
    backup(path)
    write_json(path, data)


def backup(path):
    relative = path.relative_to(ROOT)
    dst = BACKUP / relative
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists():
        dst.write_bytes(path.read_bytes())
    return dst


def paragraph_text(xml):
    return "".join(html.unescape(m.group(2)) for m in T_RE.finditer(xml))


def replace_span(xml, old, new):
    """Replace one text span across Word runs, preserving all run markup."""
    matches = list(T_RE.finditer(xml))
    texts = [html.unescape(m.group(2)) for m in matches]
    whole = "".join(texts)
    start = whole.index(old)
    end = start + len(old)
    offset = 0
    edits = []
    inserted = False
    for m, text in zip(matches, texts):
        stop = offset + len(text)
        if offset < end and stop > start:
            left, right = max(0, start - offset), min(len(text), end - offset)
            value = text[:left] + (new if not inserted else "") + text[right:]
            edits.append((m.start(2), m.end(2), html.escape(value, quote=False)))
            inserted = True
        offset = stop
    assert inserted
    for a, b, value in reversed(edits):
        xml = xml[:a] + value + xml[b:]
    assert paragraph_text(xml) == whole[:start] + new + whole[end:]
    return xml


def edit_doc(path, replacements, require_all=False):
    original = path.read_bytes()
    with ZipFile(path) as z:
        members = {i.filename: z.read(i.filename) for i in z.infolist()}
        infos, comment = z.infolist(), z.comment
    source = members["word/document.xml"].decode("utf-8")
    counts = {old: 0 for old in replacements}
    before = [paragraph_text(m.group()) for m in P_RE.finditer(source)]

    def modify(m):
        xml = m.group()
        for old, new in replacements.items():
            while old in paragraph_text(xml):
                xml = replace_span(xml, old, new)
                counts[old] += 1
                # A replacement may intentionally contain the original words.
                if old in new:
                    break
        return xml

    updated = P_RE.sub(modify, source)
    if require_all:
        assert all(counts.values()), [s for s, n in counts.items() if not n]
    ET.fromstring(updated)
    after = [paragraph_text(m.group()) for m in P_RE.finditer(updated)]
    assert len(before) == len(after)
    for prior, now in zip(before, after):
        if not any(old in prior for old in replacements):
            assert prior == now
    backup(path)
    assert path.read_bytes() == original, "File changed during the edit; stop to preserve user edits"
    tmp = path.with_name(path.name + ".tmp")
    with ZipFile(tmp, "w") as z:
        z.comment = comment
        for info in infos:
            z.writestr(info, updated.encode("utf-8") if info.filename == "word/document.xml" else members[info.filename])
    with ZipFile(tmp) as z:
        assert z.testzip() is None
        assert z.namelist() == [i.filename for i in infos]
        for name, value in members.items():
            if name != "word/document.xml":
                assert z.read(name) == value
    output = path
    try:
        tmp.replace(path)
    except PermissionError:
        if not require_all:
            raise
        output = path.with_name(path.stem + "_参数边界修正版.docx")
        if output.exists():
            raise RuntimeError(f"Refusing to replace an existing corrected copy: {output}")
        tmp.replace(output)
    CHANGES.append({"file": str(path.relative_to(ROOT)), "written_file": str(output.relative_to(ROOT)), "changed_paragraphs": sum(a != b for a, b in zip(before, after)),
                    "original_sha256": hashlib.sha256(original).hexdigest(),
                    "unaffected_paragraphs_preserved": True, "other_zip_members_preserved": True})
    return output


def mirror_text(doc):
    with ZipFile(doc) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    lines = []
    for node in root.find("w:body", W):
        if node.tag.endswith("}p"):
            text = "".join(x.text or "" for x in node.findall(".//w:t", W))
            if text: lines.append(text)
        elif node.tag.endswith("}tbl"):
            rows = []
            for row in node.findall("w:tr", W):
                rows.append(" | ".join("".join(x.text or "" for x in cell.findall(".//w:t", W)) for cell in row.findall("w:tc", W)))
            lines.append("\n".join(rows))
    target = doc.with_suffix(".txt")
    if target.exists(): backup(target)
    target.write_text("\n\n".join(lines) + "\n", encoding="utf-8")


def rows_write(path, rows):
    backup(path)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(rows)


def changed_strings(before, after):
    result = {}
    if isinstance(before, dict) and isinstance(after, dict):
        for k in before.keys() & after.keys():
            result.update(changed_strings(before[k], after[k]))
    elif isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        for a, b in zip(before, after): result.update(changed_strings(a, b))
    elif isinstance(before, str) and isinstance(after, str) and before != after and len(before) > 12:
        result[before] = after
    return result


def main():
    global MAIN, AUTHORITY
    old_para = "实现采用Pi作为智能体基座，由Pi组织模型交互和工具调用。参数确认独立实现：先展示抽取配置和默认建议，由用户逐项处理并确认，再将确认后的配置版本传入Pi执行节点。PDF解析、原文定位、结果校验、审核界面和导出使用适合的普通程序或工具接口；任务规则可按需封装为Skill。业务存储及权限由项目配置，运行中任务是否续跑按实际需要决定。"
    new_para = "实现采用Pi作为智能体基座，由Pi组织模型交互和工具调用。系统根据用户上传的论文PDF，按照预先明确的抽取规则开展处理。PDF解析、原文定位、结果校验、审核界面和导出使用适合的普通程序或工具接口；任务规则可按需封装为Skill。模型、解析工具等技术配置由开发和部署侧管理，业务存储及权限由项目配置，运行中任务是否续跑按实际需要决定。"
    primary = {
        old_para: new_para,
        "上传PDF → 抽取参数确认 → 解析与原文定位 → 特征表述抽取及语境核验 → 渐进展示与人工审核 → 导出证据并衔接后续建模。": "上传PDF → 解析与原文定位 → 特征表述抽取及语境核验 → 结果展示与人工审核（展示方式待确认） → 导出证据并衔接后续建模。",
        "S1 Pi接入与参数前置节点": "S1 Pi接入与工具集成",
        "接入Pi，完成独立参数确认、工具调用和进度回传的最小原型。": "接入Pi，完成论文输入、工具调用和处理状态回传的最小原型。",
        "确认后的配置正确传入；未确认配置不执行；权限边界有效。": "上传论文可进入处理；工具调用和结果返回正确；权限边界有效。",
        "接通上传、参数确认、渐进结果、原文回看、修订和导出。": "接通上传、结果展示、原文回看、修订和导出。",
        "完整交互流程可用；配置、审核版本与成果可追溯；中断状态明确。": "完整交互流程可用；运行记录、审核版本与成果可追溯；中断状态明确。",
        "其他使用者能重复完成上传、确认、抽取、审核和导出。": "其他使用者能重复完成上传、抽取、审核和导出。",
    }
    MAIN = edit_doc(MAIN, primary, require_all=True)
    AUTHORITY = MAIN.name
    mirror_text(MAIN)

    notes = ["癌种是否也无限制？", "图像模态待确认，是否不限图像模态？放射、病理、内镜都支持？",
             "具体需要提取哪些视觉特征还需要明确一下", "也可以考虑全部处理完后再展示结果，两种方式二选一"]
    current_text = MAIN.with_suffix(".txt").read_text()
    assert all(s in current_text for s in notes)
    scoped_confirmation = "数据集生成需求的默认参数逐项确认属于T2至T3的前置流程；T1论文抽取不设置用户参数逐项确认节点。"
    display_note = "结果展示方式待导师确认：渐进展示或全文处理完成后统一展示；两种方式均保留处理完整性和失败状态。"
    before = read(T1 / "开发计划.json")
    p = copy.deepcopy(before)
    p["authoritative_review_document"] = AUTHORITY
    p["user_review_notes_pending"] = notes
    p["scope_correction"] = {"issue": "将生成任务参数确认误用于T1", "resolution": scoped_confirmation, "status": "corrected_in_plan"}
    p["user_confirmed_changes"] = [
        scoped_confirmation if s.startswith("默认参数逐项确认") else
        display_note if s.startswith("采用渐进展示") else
        "适用于用户新增上传的论文；首版癌种、影像模态及特征范围以审核稿中的待确认备注为准。" if s.startswith("适用于持续新增") else s
        for s in p["user_confirmed_changes"]]
    p["scope"].update(presentation="pending_supervisor_review_progressive_or_full_result",
                      cancer_scope_status="pending_supervisor_review", feature_scope_status="pending_supervisor_review",
                      batch_processing="possible_later_extension", input_parameter_confirmation_required=False)
    p["architecture"].update(configuration_confirmation="not_required_for_T1", runtime_configuration_owner="developer_or_operator",
        boundaries=["PDF上传与输入检查", "Pi模型交互与业务工具调用", "论文解析和原文证据核验", "结果审核与导出", "业务存储与权限"])
    stages = {s["id"]: s for s in p["progression"]["stages"]}
    stages["S0"]["work"] = "记录Pi已选定；以用户审核稿明确癌种、模态、特征、PDF类型、展示方式及质量性能口径。"
    stages["S1"].update(name="Pi接入与工具集成", work="确定SDK/RPC接入方式与兼容版本；实现PDF输入、受限工具调用和处理状态回传的最小原型。",
        deliverables="可运行接入原型、论文输入与工具结果契约、开发侧运行配置及基础权限配置。",
        gate="有效论文输入能进入处理；工具调用、结果及状态回传正确；越界工具/目录访问被拒绝。")
    stages["S5"].update(work="接通逐篇上传、结果展示、进度、取消、原页回看、修订与导出；展示方式待审核；按必要对象实现存储和中断处理。",
        deliverables="可交互应用、运行及证据版本、审核事件、导出契约和中断策略记录。",
        gate="候选与批准状态准确；证据关联正确论文及处理版本；按所选方式展示和处理中断，不重复交付；实际工具权限生效。")
    stages["S6"]["deliverables"] = "质量报告、全文处理时延（采用渐进展示时另报首条候选时延）、资源成本及人工工作量报告。"
    stages["S7"]["gate"] = "其他使用者按说明完成上传、抽取、审核与导出；成果及开发侧运行版本可还原；T2能区分候选与已审核证据。"
    tasks = {t["id"]: t for t in p["tasks"]}
    tasks["T1-R01"]["work"] = "记录Pi与任务边界；癌种、模态、特征范围和展示方式以用户审核稿为准，在S0落实。"
    tasks["T1-R25"].update(name="实现论文输入与工具交接", work="传递论文标识、文件引用和开发侧运行版本，核对工具输入输出；不加入用户参数确认节点。", deliverable="论文输入与工具结果契约")
    tasks["T1-R26"]["work"] = "验证论文引用、工具结果、处理状态与运行记录一致；保留故障及权限检查。"
    tasks["T1-R13"]["work"] = "接通论文上传和处理；按最终确定的展示方式呈现结果，明确全文覆盖、取消与失败状态。"
    tasks["T1-R14"]["work"] = "保存开发侧运行记录及证据/审核版本；按需要决定重跑或续跑，避免重复交付。"
    tasks["T1-R22"]["work"] = "按实际流程完成上传、抽取、结果展示、审核、导出和选定的中断处理。"
    decisions = {d["id"]: d for d in p["decisions"]}
    decisions["D04"].update(topic="癌种、模态、特征及输入边界", detail="以用户审核稿的备注明确癌种范围、放射/病理/内镜等模态、具体视觉特征、语言及PDF类型。", options="在S0审核后形成首版支持矩阵；当前不把备注当成已确定范围。")
    decisions["D11"].update(topic="结果展示方式", status="to_discuss", detail=display_note,
        confirmed_basis="用户修改的导师审核稿重新列为二选一待确认", options="渐进展示；全文处理后统一展示")
    decisions["D13"].update(topic="生成参数确认的适用范围", status="not_applicable_to_T1", detail=scoped_confirmation,
        confirmed_basis="本轮用户指出原始要求归属；已核对导师原始任务描述", options="T1移除用户参数确认节点；总项目生成需求确认保留", decision_stage="S0", impact="防止将T2生成需求交互扩展为T1的额外输入要求")
    decisions["D18"]["options"] = "保存运行记录和已交付成果；重跑/续跑按耗时与使用场景选择，无T1用户参数确认要求。"
    p["shared_parent_work"] = {"M1": "共享T1 S1的Pi接入、工具接口与权限成果；生成参数确认由T2/M3另行实现。"}

    wf_before = read(BASE / "工作流与模块职责.json")
    wf = copy.deepcopy(wf_before)
    wf["modules"][0]["module"] = "生成需求草稿与参数确认（T2）"
    wf["modules"][1]["responsibility"] = "T1接收论文和开发侧运行配置；T2建模接收已确认生成需求；按工具结果组织处理。"
    wf["modules"][3]["responsibility"] = "按待确定方式展示候选；保留全文覆盖、原文证据及审核导出。"
    wf["t1_nodes"] = ["用户上传论文PDF并做文件基本检查", "Pi按照抽取规则调用解析、原文抽取与证据核验工具",
                      "按审核后确定的方式展示结果及处理完整性", "人工核对原文、修订和审核证据", "导出证据，已审核部分衔接T2"]
    wf["agent_input_contract"]["scope"] = "T2生成需求确认后的动态建模；不适用于T1论文输入"
    wf["t1_input_contract"] = {"fields": ["run_id", "document_id", "pdf_reference", "runtime_profile_version"],
        "runtime_profile_owner": "developer_or_operator", "user_parameter_confirmation_required": False,
        "checks": ["文件可读取且属于约定支持范围", "工具权限允许", "结果绑定论文及实际处理版本"]}
    wf["persistence"]["must_keep_for_delivery"] = ["T2生成需求参数与确认版本", "T1已审核证据及来源/审核版本", "运行记录与交付成果的必要关联"]
    wf["persistence"]["interruption_options"][0] = "明确标记中断，按原运行记录重新处理"
    wf["permissions"]["implementation_stage"] = "T1 S1基本边界，S5/S7验证实际工具与部署"
    wf["t1_authoritative_review_document"] = "子任务T1/" + AUTHORITY
    p["workflow"] = copy.deepcopy(wf)

    qc = read(T1 / "质量与性能验收契约.json")
    qc["confirmed_usage"].update(progressive_candidates_with_full_document_progress=None,
        presentation_status="pending_supervisor_review", confirmation_node="not_required_for_T1")
    f = {x["id"]: x for x in qc["functional_invariants"]}
    f["F01"].update(name="论文输入与执行", rule="有效论文输入可进入抽取流程；不存在用户参数逐项确认的前置要求。")
    f["F02"].update(name="运行与证据关联", rule="结果绑定论文、解析文本及实际运行版本；开发侧技术配置可追溯。")
    f["F03"].update(name="结果展示与覆盖", rule="展示方式由审核确定；任一方式均区分候选/审核结果和部分/完整处理，未处理内容明确标记。")
    for m in qc["metrics"]:
        if m["id"] == "P01": m["definition"] = "记录上传反馈与全文处理P50/P95；若采用渐进展示，另计首条可审核候选时延；人工等待另列。"

    parent_before = read(BASE / "实施计划.json")
    parent = copy.deepcopy(parent_before)
    parent["confirmed_architecture"][1] = scoped_confirmation
    parent["module_rows"] = [[m["module"], m["implementation"], m["responsibility"]] for m in wf["modules"]]
    parent["agent_integration"]["configuration_confirmation"] = "T2_generation_requirement_only"
    parent["agent_integration"]["t1_user_parameter_confirmation_required"] = False
    parent["stages"][1].update(name="共享Pi接入与工具集成", work="实现Pi接入、论文及工具输入输出契约与基础权限；生成需求确认在M3/T2实现。", gate="工具受限，论文与结果可关联，处理状态能回传；复用T1 S1成果。")
    parent["dependency_note"] += " 生成需求参数确认不作为T1开发或执行的前置条件。"
    parent["t1_authoritative_review_document"] = "子任务T1/" + AUTHORITY
    hierarchy = read(BASE / "任务分解.json")
    hierarchy["confirmed_architecture"][1] = scoped_confirmation
    hierarchy["status_note"] = "Pi已选定；生成需求逐项参数确认归属T2/T3前置流程；T1直接接收论文提取证据，以用户修改的审核简版为范围依据。"
    hierarchy["subtasks"][0]["implementation_responsibility"] = "Pi调用论文解析、抽取及证据核验工具；T1不设用户参数确认节点，保留结果审核、必要存储与权限。"
    hierarchy["subtasks"][0]["authoritative_review_document"] = "子任务T1/" + AUTHORITY

    for path, data in [(T1 / "开发计划.json", p), (T1 / "质量与性能验收契约.json", qc),
                       (BASE / "工作流与模块职责.json", wf), (BASE / "实施计划.json", parent), (BASE / "任务分解.json", hierarchy)]: save(path, data)
    rows_write(T1 / "开发阶段与验收.csv", [["阶段", "名称", "前置阶段", "工作", "交付物", "通过条件", "未通过处理", "状态"]] + [[s["id"],s["name"],";".join(s["dependencies"]),s["work"],s["deliverables"],s["gate"],s["fail_action"],s["status"]] for s in p["progression"]["stages"]])
    rows_write(T1 / "开发任务清单.csv", [["编号","阶段","依赖","工作项","具体工作","交付物","状态"]] + [[t[k] for k in ["id","stage","dependencies","name","work","deliverable","status"]] for t in p["tasks"]])
    rows_write(T1 / "待讨论实现决策.csv", [["编号","主题","状态","具体内容","已确认依据","讨论选项","确定阶段","影响"]] + [[d[k] for k in ["id","topic","status","detail","confirmed_basis","options","decision_stage","impact"]] for d in p["decisions"]])
    rows_write(T1 / "验收清单.csv", [["编号","名称","定义","测量依据","已约定阈值","阶段","状态"]] + [[m["id"],m["name"],m["definition"],m["measurement"],"待讨论",m["stage"],"未执行"] for m in qc["metrics"]] + [[m["id"],m["name"],m["rule"],"节点、状态与调用记录","明确规则",m["stage"],"未执行"] for m in qc["functional_invariants"]])
    rows_write(BASE / "开发阶段与验收.csv", [["阶段","名称","前置","归属","工作","通过条件","状态"]] + [[s["id"],s["name"],";".join(s["dependencies"]),s["owner"],s["work"],s["gate"],s["status"]] for s in parent["stages"]])
    for path in [T1 / "抽取结果字段规范.csv", BASE / "验收清单.csv"]:
        with path.open(encoding="utf-8-sig", newline="") as fp: rows=list(csv.reader(fp))
        for row in rows[1:]:
            if row[0] == "extraction_trace":
                row[4:6] = ["run_id、开发侧运行配置版本、Pi/模型/解析器/规则版本、所读块及工具调用；采用Skill时记录其版本", "追溯证据到论文与实际处理步骤；不要求T1用户确认技术配置"]
            elif row[0] == "A25":
                row[1:5] = ["T2生成需求前置确认", "生成需求存在未确认默认项或仍为草稿", "阻止派发T2正式建模/生成流程；该门禁不适用于T1论文抽取", "生成需求确认及拒绝记录"]
            elif row[0] == "A29": row[2:4] = ["工具返回候选结果与失败页面", "按选定展示方式呈现结果；区分部分失败与完整完成，状态来自实际处理记录"]
            if len(row) < len(rows[0]): row.extend(["未执行"] * (len(rows[0])-len(row)))
        rows_write(path, rows)

    full_replacements = changed_strings(before, p)
    # Limit field-to-text substitutions to meaningful prose, not paths or IDs.
    full_replacements = {a:b for a,b in full_replacements.items() if any('\u4e00' <= c <= '\u9fff' for c in a) and len(a) > 18}
    full_replacements.update({
        "S1 Pi接入与前置参数节点": "S1 Pi接入与工具集成",
        "二 工作流和配置交接": "二 论文处理工作流",
        "2. 独立模块展示抽取范围、参数及缺失项的默认建议": "2. 系统检查PDF可读性及处理能力，按预先明确的抽取规则处理",
        "3. 用户逐项处理默认项并最终确认；保存配置版本": "3. 开发侧设置模型、解析工具和运行方式；用户无需逐项确认技术配置",
        "4. Pi执行节点读取确认配置，调用解析、原文抽取和证据核验工具": "4. Pi接收论文输入，调用解析、原文抽取和证据核验工具",
        "5. 展示首批候选，继续处理全文并报告页面/文本块覆盖和失败状态": "5. 按审核后确定的方式展示结果，保留页面/文本块覆盖及失败状态",
        "前置参数模块完成默认项逐项告知、增删改、数值与依赖检查及最终确认。Pi接收配置ID、版本、已确认值、确认记录引用和输入文件引用。后端以实际确认记录校验交接，不能把模型输出的confirmed字段当成用户确认。": "T1接收论文PDF并按抽取规则处理，不设置用户参数逐项确认节点。Pi接收论文标识、文件引用及开发侧运行配置；系统保留实际版本和处理记录以便核对。",
        "Pi若发现缺项、冲突或需要改参数，应返回待修改事项，交由前置模块产生新版本并重新确认。正在运行的任务继续绑定原快照；是否停止或重新启动由业务流程明确处理。参数确认与抽取结果审核是两个节点，分别记录。": "PDF无法读取或证据上下文不足时，报告失败或待复核情况。用户审核的是抽取原文及结果，可修订证据；模型与解析工具的运行设置由开发和部署侧维护。",
        "自然语言结构化可以是独立的前处理服务，按需调用模型产生草稿。进入正式抽取或建模节点的仍是用户确认后的配置。T1的确认是抽取任务配置确认；T2的确认是生成需求确认；两者不要求相同字段。": scoped_confirmation,
        "S1的Pi接入、配置交接和权限接口直接复用于总课题M1/T5。": "S1的Pi接入、论文与工具接口及权限成果复用于总课题M1/T5；生成参数确认在T2实现。",
        "项目负责保存参数与确认版本、已审核证据及已交付文件。": "T1保存开发侧运行记录、已审核证据及已交付文件；T2另行保存生成参数和确认版本。",
        "逐篇交互采用渐进候选。": display_note,
        "D11 渐进展示与完成条件（confirmed）": "D11 结果展示方式（to_discuss）",
        "D13 参数确认节点（confirmed）": "D13 生成参数确认的适用范围（not_applicable_to_T1）",
        "总课题以肠癌、肺癌及放射学CT/MRI为起点；T1不设置固定论文、癌种或术语白名单。已有论文及35项特征清单用于启动和评测，不作为穷尽答案。其他影像模态、语言、扫描与混合PDF的首版支持矩阵在S0讨论确定。": "T1的癌种、模态、具体视觉特征范围及展示方式，以用户编辑的导师审核简版及其待确认备注为准，在S0审核后明确；既有文献和清单可用作启动资料。",
    })
    edit_doc(T1 / "医学论文肿瘤视觉特征提取智能体_开发计划.docx", full_replacements)
    parent_replacements = changed_strings(parent_before, parent)
    parent_replacements = {a:b for a,b in parent_replacements.items() if any('\u4e00' <= c <= '\u9fff' for c in a) and len(a)>18}
    parent_replacements.update({
        "参数确认由独立前置模块完成，确认后的配置版本再输入Pi执行节点": "生成需求参数确认由T2的独立前置模块完成，再输入Pi建模节点；T1直接接收论文，不设置逐项参数确认",
        "M1 共享Pi接入与参数确认": "M1 共享Pi接入与工具集成",
        "参数草稿与确认": "生成需求草稿与参数确认（T2）",
        "只接收当前任务已确认的配置；按工具结果组织下一步": wf["modules"][1]["responsibility"],
        "首版已确认用户上传公开已发表PDF，逐篇交互并渐进展示候选及全文进度": "首版接收用户上传PDF，逐篇交互；癌种、模态、特征范围及展示方式以用户修改的T1审核简版为准并待审核",
    })
    edit_doc(BASE / "毕业设计实施方案_导师审核稿_v0.4.docx", parent_replacements)
    brief = T1 / "发给导师_功能介绍与Pi实现说明.docx"
    edit_doc(brief, {
        "参数确认独立实现，用户逐项处理默认项并确认后，配置版本才交给Pi执行。": "用户上传论文后，Pi按抽取规则调用工具处理；模型及解析工具的技术配置由开发侧管理。",
        "Pi接入和参数前置节点": "Pi接入和工具集成",
        "尽快显示可核对的首批候选，同时继续处理全文并显示进度": "展示方式待审核选择渐进输出或全文处理后统一展示，并保留处理状态",
        "论文、癌种和术语不固定为某几项。": "癌种、模态及具体特征范围以最新审核简版的待确认备注为准。",
    })
    mirror_text(brief)
    for path in [T1 / "当前版本.json", BASE / "当前版本.json"]:
        d=read(path)
        if path.parent == T1:
            d.update(advisor_review_plan=AUTHORITY, advisor_review_text=MAIN.with_suffix(".txt").name)
        d["t1_scope_authority"] = AUTHORITY if path.parent==T1 else "子任务T1/"+AUTHORITY
        d["scope_correction"] = scoped_confirmation
        d["correction_record"] = "参数边界修正记录.json" if path.parent==T1 else "子任务T1/参数边界修正记录.json"
        save(path,d)
    source_path=BASE / "资料与选型核验.json"
    src=read(source_path)
    src["architecture_decisions"][1]=scoped_confirmation
    save(source_path,src)
    report={"scope":scoped_confirmation,"authoritative_document":AUTHORITY,"user_notes_preserved":notes,
            "backup_directory":str(BACKUP.relative_to(ROOT)),"docx_checks":CHANGES,
            "not_changed":"总项目生成需求的逐项参数确认规则和契约继续保留。",
            "validation_scope":"文档与计划一致性；不是应用功能或医学性能验收。"}
    write_json(T1 / "参数边界修正记录.json",report)
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()

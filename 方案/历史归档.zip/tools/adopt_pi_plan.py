#!/usr/bin/env python3
"""Revise T0/T1 planning artifacts for the user's confirmed Pi adoption.

Preserve the previous plans before writing. This generates documents and draft
contracts only; it does not install Pi, run an agent, or approve a medical job.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from build_review_pack import ROOT, DATE, Word, build_document, q, write_json

BASE = ROOT / "方案"
CHILD = BASE / "子任务T1"
PARENT_VERSION, CHILD_VERSION = "0.4", "0.3"
PARENT_DOC = BASE / "毕业设计实施方案_导师审核稿_v0.4.docx"
CHILD_DOC = CHILD / "医学论文肿瘤视觉特征提取智能体_开发计划.docx"
COMMIT = "2c8d1feb147f6b3d97e855da803bfe7b19f3c403"
REPO = "https://github.com/earendil-works/pi"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.reader(f))


def csv_write(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(rows)


def archive(files, dest):
    dest.mkdir(parents=True, exist_ok=True)
    hashes = {}
    for src in files:
        dst = dest / src.name
        if not dst.exists():
            shutil.copy2(src, dst)
        elif dst.read_bytes() != src.read_bytes():
            raise RuntimeError(f"Archive collision: {dst}")
        hashes[src.name] = hashlib.sha256(dst.read_bytes()).hexdigest()
    write_json(dest / "归档记录.json", {"date": DATE, "reason": "采用Pi基座前的计划版本", "sha256": hashes})


PI_SOURCES = [
    {"id": sid, "title": title, "url": f"{REPO}/blob/{COMMIT}/{path}",
     "path": path, "commit": COMMIT, "supports": support, "reviewed": "官方文档或源码静态核验，未运行应用"}
    for sid, title, path, support in [
        ("PI01", "Pi仓库定位与组件", "README.md", "智能体运行组件、SDK/RPC、可扩展机制及MIT许可"),
        ("PI02", "Pi智能体核心", "packages/agent/README.md", "工具执行、事件流和状态接口"),
        ("PI03", "Pi TypeScript SDK", "packages/coding-agent/docs/sdk.md", "应用嵌入、会话与资源管理"),
        ("PI04", "Pi RPC", "packages/coding-agent/docs/rpc.md", "基于子进程JSONL的跨语言接入，需自行接到业务服务"),
        ("PI05", "Pi Skills", "packages/coding-agent/docs/skills.md", "任务指令与辅助资源封装；Skill为可选实现形式"),
        ("PI06", "Pi扩展", "packages/coding-agent/docs/extensions.md", "自定义工具及生命周期扩展"),
        ("PI07", "Pi权限边界", "packages/coding-agent/docs/security.md", "默认继承启动进程权限，应用需配置实际隔离"),
        ("PI08", "Pi容器化", "packages/coding-agent/docs/containerization.md", "完整进程可放入Docker等隔离环境"),
        ("PI09", "Pi持久化运行时", "packages/durable/README.md", "实验性任务恢复组件；外部副作用的幂等仍由调用方实现"),
    ]
]

CONFIRMED = [
    "用户明确同意采用earendil-works/pi作为总课题及T1的智能体基座。",
    "默认参数逐项确认由独立前置模块实现，确认后的参数再交给Pi执行节点。",
    "功能可由普通程序、工具接口、扩展或Skill按需要实现，不要求全部使用Skill。",
    "外部状态按实际需要由项目实现存储与中断处理，不要求Pi内置所有持久化能力。",
    "工具、文件、服务和运行环境的权限边界由项目配置。",
]

MODULE_ROWS = [
    ["参数草稿与确认", "独立前端和业务后端；可选LLM结构化前处理", "逐项默认告知、增删改、合法性检查、最终确认和版本保存"],
    ["Pi智能体运行层", "Pi模型交互、工具调用、会话与事件接口", "只接收当前任务已确认的配置；按工具结果组织下一步"],
    ["任务规则", "按需采用Skill、提示模板或普通代码", "医学抽取规范、证据规则和输出要求；关键规则由程序核验"],
    ["T1论文处理", "PDF解析、原文定位、抽取与语境核验工具", "渐进候选、全文覆盖状态、原文证据与审核导出"],
    ["T2建模", "Pi加结构化需求编译与模型校验程序", "已确认需求到目标、约束和函数接口的映射及可执行性检查"],
    ["T3/T4生成与筛选", "独立优化、GPU生成、检查和导出程序/服务", "执行受约束生成、样本计数、分布校验与文件交付"],
    ["业务存储与权限", "项目业务程序及部署配置", "配置和成果存储；运行恢复按需；文件、工具与服务访问控制"],
]

FLOW = {
    "version": PARENT_VERSION,
    "status": "planning_contract_not_implemented",
    "selected_agent_base": "earendil-works/pi",
    "modules": [dict(zip(["module", "implementation", "responsibility"], row)) for row in MODULE_ROWS],
    "t1_nodes": [
        "用户上传公开论文PDF并做文件基本检查",
        "独立模块展示抽取范围、参数及缺失项的默认建议",
        "用户逐项处理默认项并最终确认；保存配置版本",
        "Pi执行节点读取确认配置，调用解析、原文抽取和证据核验工具",
        "展示首批候选，继续处理全文并报告页面/文本块覆盖和失败状态",
        "独立界面审核证据，保存修订及审核结果",
        "导出候选或已审核证据；已审核部分交付T2",
    ],
    "t2_to_t4_nodes": [
        "T1已审核证据或医生口述，加用户任务与数据要求",
        "独立前处理生成结构化草稿；可按需调用LLM，草稿不触发执行",
        "前端增删改指标、逐项确认默认建议，后端校验并保存确认版本",
        "Pi动态建模节点接收确认快照，形成候选目标、约束和生成配置",
        "业务程序校验函数、单位、后端能力、可行性及预算",
        "T3生成程序执行；T4按已确认规则检查、筛选和交付",
    ],
    "agent_input_contract": {
        "status": "planned",
        "fields": ["task_id", "task_type", "input_references", "config_id", "config_revision",
                   "confirmed_values", "confirmation_event_refs", "config_digest"],
        "owner": "独立参数模块的后端保存确认事实，Pi消费确认快照",
        "entry_checks": [
            "核验配置版本、真实确认事件与配置内容相符；所有应处理默认项均已处理",
            "草稿、示例、过期或被修改的配置不得进入正式执行节点",
            "参数确认允许进入对应Pi处理节点；图像生成另外要求数学模型及能力校验通过",
        ],
        "change_path": "Pi发现缺项、冲突或需改值时返回待修改事项；前置模块生成新版本并重新确认，再派发新输入",
        "running_version_rule": "运行任务绑定自己的确认快照；前端后续修改不得静默改变运行输入。停止或重启由业务流程明确处理。",
        "approval_scope": "框架选型确认、任务参数确认、原文证据审核是不同记录；本次只确认框架和职责，不产生实际任务授权。",
    },
    "persistence": {
        "owner": "application",
        "pi_durable_required": False,
        "must_keep_for_delivery": ["用户参数与确认版本", "已审核证据及来源/审核版本", "已导出成果及必要关联"],
        "conditional": [
            {"object": "解析缓存/运行中页面进度", "trigger": "恢复处理或性能复用确有需要时", "decision": "T1 S5讨论实现"},
            {"object": "异步GPU作业ID及已接受样本计数", "trigger": "T3采用长任务或批量生成时", "decision": "T3设计时按需实现"},
            {"object": "队列、检查点与自动续跑", "trigger": "重启续跑收益足以支持额外复杂度时", "decision": "不作为当前Pi接入的必备组件"},
        ],
        "interruption_options": ["明确标记中断，按原确认配置重新运行", "保存进度并恢复"],
        "chosen_interruption_policy": None,
        "invariants": ["不得把部分结果标成完整结果", "不得重复计入已交付记录", "已确认配置和已交付成果可还原"],
    },
    "permissions": {
        "owner": "application_and_deployment",
        "implementation_stage": "T1 S1基本边界，S5/S7验证实际工具与部署",
        "configuration": ["业务工具白名单", "上传与结果目录访问范围", "凭证和外部服务范围", "容器权限与挂载"],
        "acceptance": "允许的解析/抽取工具能完成任务；未授权的工具、目录和服务访问被阻止；不依赖模型口头遵守。",
    },
}

STAGES = [
    ("S0", "范围与验收契约", [],
     "记录已选Pi及外置确认节点；明确输入覆盖、审核方式与质量性能评测口径。",
     "范围矩阵、决策记录、验收契约草案。",
     "已确认事项不重复待选；影响输入、质量及交付的剩余事项有明确约定。"),
    ("S1", "Pi接入与前置参数节点", ["S0"],
     "比较SDK/RPC的接入成本并确定方式；锁定兼容版本；实现确认配置交接、受限工具调用和事件回传的最小原型。",
     "可运行接入原型、版本记录、配置输入契约和基础权限配置。",
     "未确认配置不进入执行；确认版本正确传入；变更触发新版本；进度可回传；越界工具/目录调用被拒绝。"),
    ("S2", "评测语料与人工金标准", ["S1"],
     "按癌种、来源、论文类型、语言、版式和文本层类型准备语料；制定完整标注与匹配规则。",
     "文献清单、人工金标准、开发/回归/独立验收划分和经讨论的阈值。",
     "覆盖已约定输入类型和未见论文；金标准不只标注模型已找到的段落；门槛获确认。"),
    ("S3", "文档解析与证据定位", ["S2"],
     "在相同PDF和资源下比较解析器，封装Pi可调用的解析工具，建立原页/文本块/字符对应和覆盖记录。",
     "解析工具、统一文档表示、定位映射、对照结果及组件选择记录。",
     "解析忠实性、覆盖、定位和资源达到约定要求；未支持或失败页面被明确记录。"),
    ("S4", "跨文献抽取与语境校验", ["S3"],
     "在Pi中实现提取和核验流程；规则可用Skill、提示或代码封装；比较模型及抽取策略，验证新术语、否定、条件与跨段语境。",
     "抽取工具、任务规则、原文证据、全文覆盖记录、模型与规则版本。",
     "独立新论文上达到约定质量底线；原文可追溯，语境错误计入错误，未知特征不被固定词表拒绝。"),
    ("S5", "独立审核界面与业务存储", ["S4"],
     "接通逐篇上传、前置确认、渐进候选、进度、取消、原页回看、修订和导出；按必要对象实现存储，确定中断后重跑或续跑策略。",
     "可交互应用、配置与证据版本、审核事件、导出契约、存储及中断策略记录。",
     "候选与批准状态准确；配置修改不会静默改写运行任务；按所选策略处理中断且不重复交付；实际工具权限生效。"),
    ("S6", "质量与性能验收", ["S5"],
     "对独立论文与约定分层运行质量、延迟、负载、故障处理及升级回归评估。",
     "质量报告、首批候选/全文P50与P95、资源与成本、失败及人工工作量报告。",
     "满足约定契约；失败论文保留统计；可复现配置明确；没有把模型输出流当成已核验候选或全文完成。"),
    ("S7", "Docker交付与T2衔接", ["S6"],
     "锁定依赖与配置，在目标环境验证安装、权限、必要存储及中断处理；完成证据导出和T2对接。",
     "Docker/Compose交付包、操作说明、能力矩阵、发布配置、证据接口与验收记录。",
     "其他使用者按说明完成上传、确认、抽取、审核和导出；已保存配置与成果可还原；T2能区分候选和已审核证据。"),
]

PARENT_STAGES = [
    ("M0", "范围与验收边界", [], "T0/T1", "保留两癌及CT/MRI项目方向，确认输入、输出、医学复核和质量门槛；Pi已选定。", "范围及验收契约明确，关键未决项进入对应阶段。"),
    ("M1", "共享Pi接入与参数确认", ["M0"], "T1 S1/T5", "实现独立确认节点、配置快照、Pi接入、业务工具接口和基础权限。", "确认前后节点及版本绑定正确，工具受限且进度能回传；复用T1 S1成果。"),
    ("M2", "文献证据子任务", ["M1"], "T1", "完成T1语料、解析、抽取、审核、性能与部署各阶段。", "T1 S0—S7逐阶段通过，有可审核证据和独立论文评测。"),
    ("M3", "需求审核与动态建模", ["M2"], "T2", "接收文献或医生描述；前置结构化与确认；Pi提出动态模型，程序校验变量、目标与约束。", "新增、修改和删除指标正确改变数学模型；缺项返回确认；可行性和单位校验可核对。"),
    ("M4", "生成能力与算法适配", ["M3"], "T3", "取得并核对候选影像数据与后端；校准可测特征；比较基线和适配算法，按需实现作业管理。", "相同预算下报告约束满足率、质量、成本及失败；后端能力有实测依据。"),
    ("M5", "筛选与数据集交付", ["M4"], "T4", "实施图文核验、配额与上限、数据划分、文件导出和缺口报告。", "数量、分布、图文关联和来源一致；导出文件可读且适配目标训练接口。"),
    ("M6", "整体集成与扩展", ["M5"], "T5", "验证完整工作流、权限、必要存储、中断策略和Docker交付；按证据扩展癌种、特征及MRI生成。", "端到端运行与质量契约通过；扩展能力有独立验证；记录实际限制。"),
]


def make_stages():
    return [dict(id=sid, name=name, dependencies=deps, work=work, deliverables=deliverables,
                 gate=gate, fail_action="针对未通过项修正并复验；范围、门槛或关键实现变化与用户讨论，不按时间自动推进。",
                 status="awaiting_remaining_scope_decisions" if sid == "S0" else "not_started")
            for sid, name, deps, work, deliverables, gate in STAGES]


def update_child(plan):
    p = copy.deepcopy(plan)
    p.update(version=CHILD_VERSION, status="pi_selected_plan_updated", date=DATE,
             supersedes="历史版本/v0.2", implementation_started=False, benchmarks_run=False)
    p["user_confirmed_changes"].extend(CONFIRMED)
    p["progression"]["stages"] = make_stages()
    p["architecture"] = {
        "status": "agent_base_selected_other_components_open", "selected_agent_base": "earendil-works/pi",
        "selection_basis": "用户明确答复：可以采用pi，需要更新原计划，包括子任务。",
        "source_snapshot_commit": COMMIT, "deployment_version": None,
        "integration_mode": None, "integration_options": ["TypeScript SDK", "RPC subprocess"],
        "integration_decision_stage": "S1", "configuration_confirmation": "external_predecessor_node",
        "skill_required_for_every_function": False, "pi_durable_required": False,
        "business_state_owner": "application", "permission_owner": "application_and_deployment",
        "boundaries": [row[0] for row in MODULE_ROWS],
        "note": "Pi已选定；SDK/RPC、解析器、LLM、存储、界面和具体发布版本仍按阶段讨论确定。",
    }
    p["workflow"] = copy.deepcopy(FLOW)
    p["shared_parent_work"] = {"M1": "直接复用T1 S1接入、外置确认与权限成果，避免重复开发"}
    mapping = {"S0": "S0", "S1": "S2", "S2": "S3", "S3": "S4", "S4": "S5", "S5": "S6", "S6": "S7"}
    tasks = p["tasks"]
    for t in tasks:
        t["stage"] = mapping[t["stage"]]
    new_tasks = []
    for tid, dep, name, work, deliverable in [
        ("T1-R23", "T1-R02", "确定Pi接入方式及版本", "在已选Pi前提下比较SDK/RPC与现有技术栈的适配，锁定经测试版本", "接入决策与版本配置"),
        ("T1-R24", "T1-R23", "接入受限工具与事件流", "实现最小业务工具及进度事件回传，配置文件与工具访问边界", "运行原型与权限核验"),
        ("T1-R25", "T1-R24", "实现前置参数确认与交接", "独立模块生成确认快照；验证未确认、改值、旧版本、新缺项返回等路径", "输入契约与节点联调"),
        ("T1-R26", "T1-R25", "验收Pi基础集成", "确认工具结果、配置版本与事件回传一致；保留中断、失败和版本记录", "S1接入验收证据"),
    ]:
        new_tasks.append(dict(id=tid, stage="S1", dependencies=dep, name=name, work=work,
                              deliverable=deliverable, status="planned_not_started"))
    tasks[2:2] = new_tasks
    by_id = {t["id"]: t for t in tasks}
    by_id["T1-R01"]["work"] = "记录Pi和模块职责已确认；论文、癌种及术语不写死；首版用户上传公开PDF"
    by_id["T1-R02"]["work"] = "继续讨论输入类型、审核方式和响应目标；具体模型、解析器与云资源随实测确定"
    by_id["T1-R03"]["dependencies"] = "T1-R26"
    by_id["T1-R09"]["work"] = "在Pi运行层下比较模型、LangExtract等抽取机制与直接抽取基线；医学规则按需用Skill或代码封装"
    by_id["T1-R13"]["work"] = "接通上传与前置参数节点，展示首批可审核候选、全文覆盖、取消及失败状态"
    by_id["T1-R14"].update(name="实现必要存储与中断策略", work="保存配置及证据版本；讨论采用明确中断后重跑或续跑；避免重复交付，不预设队列或pi-durable", deliverable="存储清单、策略记录与故障核验")
    by_id["T1-R20"]["work"] = "锁定Pi、工具和模型配置；验证Docker环境、权限、已存成果还原及所选中断策略"
    by_id["T1-R22"]["work"] = "按真实流程完成上传、参数确认、渐进抽取、审核、导出和选定的中断处理"
    for c in p["open_source_candidates"]:
        if c["repository"] in {"langchain-ai/langgraph", "pydantic/pydantic-ai"}:
            c["candidate_role"] = "架构或校验思路参考；Pi已选定，不再并列竞选主基座"
            c["selected_for_implementation"] = False
    p["open_source_candidates"].insert(0, {
        "repository": "earendil-works/pi", "url": REPO, "stars_at_check": None,
        "checked_at": read_json(ROOT / "research/pi_review/snapshot.json")["checked_at"],
        "pushed_at": None, "archived": None, "layer": "已选智能体运行基座",
        "borrow": "模型接入、工具执行、会话、事件流、SDK/RPC及可选Skill/扩展",
        "candidate_role": "用户已选定；具体版本与接入方式在S1验证",
        "limitations": "需开发医学工具与业务模块；任务恢复按需；pi-durable为实验性非必选组件",
        "license_note": "仓库MIT；所接入模型和外部组件分别核对",
        "readme_url": PI_SOURCES[0]["url"], "readme_sha": None, "latest_release_seen": None,
        "source_commit": COMMIT, "implementation_benchmarked": False, "selected_for_implementation": True,
    })
    for d in p["decisions"]:
        d["decision_stage"] = "/".join(mapping.get(x, x) for x in d["decision_stage"].split("/"))
        if d["id"] == "D07":
            d.update(topic="Pi以外的技术组件", detail="Pi已选定；解析器、模型、抽取策略及回退组合待实测", confirmed_basis="用户确认采用Pi", options="在Pi下比较候选；不再进行主基座竞选")
        elif d["id"] == "D08":
            d.update(detail="优先Docker/Compose；应用自行保存必要配置和成果；数据库、服务拆分及GPU配置待确定", options="按真实需求决定存储对象；不预设队列、自动续跑或pi-durable")
    for did, topic, detail, stage in [
        ("D12", "智能体基座", CONFIRMED[0], "S1"),
        ("D13", "参数确认节点", CONFIRMED[1], "S1/S5"),
        ("D14", "功能封装方式", CONFIRMED[2], "S1/S4"),
        ("D15", "外部状态职责", CONFIRMED[3], "S5"),
        ("D16", "权限职责", CONFIRMED[4], "S1/S5/S7"),
    ]:
        p["decisions"].append(dict(id=did, topic=topic, status="confirmed", detail=detail,
            confirmed_basis="用户本轮明确答复", options="已确认职责，具体实现随所属阶段落实",
            decision_stage=stage, impact="总课题与T1采用同一职责边界"))
    for did, topic, detail, options, stage in [
        ("D17", "Pi接入与版本", "SDK或RPC、锁定的Pi版本及工具接入形式", "比较接入成本和工具事件验证后共同确定", "S1"),
        ("D18", "必要存储与中断方式", "哪些运行中状态需要保存；中断后重跑或恢复", "已确认参数和已交付成果保存；重跑/续跑按耗时及使用场景选择", "S5"),
    ]:
        p["decisions"].append(dict(id=did, topic=topic, status="to_discuss", detail=detail,
            confirmed_basis="Pi及应用责任已确认，具体实现未确定", options=options,
            decision_stage=stage, impact="维护复杂度、恢复成本与部署"))
    return p


def update_quality(old):
    qc = copy.deepcopy(old)
    qc["plan_version"] = CHILD_VERSION
    qc["confirmed_usage"]["agent_base"] = "earendil-works/pi"
    qc["confirmed_usage"]["confirmation_node"] = "external_predecessor"
    mapping = {"S2": "S3", "S3": "S4", "S4": "S5", "S5": "S6", "S6": "S7"}
    for m in qc["metrics"]:
        m["stage"] = "/".join(mapping.get(s, s) for s in m["stage"].split("/"))
        if m["id"] == "R01":
            m.update(name="中断处理与状态一致性", definition="超时、限流、取消或重启后按已选的重跑/续跑策略处理；不虚报全文完成，不重复交付；必要配置和已保存成果可还原", measurement="依据所选策略进行故障核验，不以自动续跑作为唯一通过方式")
    qc["functional_invariants"] = [
        {"id": "F01", "name": "独立参数前置节点", "rule": "默认项逐项处理且配置有效后才派发正式Pi执行；未确认、关闭或超时不算确认", "stage": "S1/S5", "status": "not_executed"},
        {"id": "F02", "name": "配置版本交接", "rule": "运行任务绑定已确认版本；改值、缺项或冲突进入重新确认路径", "stage": "S1/S5", "status": "not_executed"},
        {"id": "F03", "name": "渐进候选与覆盖", "rule": "首批可审核候选、处理中和全文完成分开；未处理页面保持可见", "stage": "S4/S5/S6", "status": "not_executed"},
        {"id": "F04", "name": "权限配置", "rule": "许可业务工具可用，越界文件及工具调用被阻止", "stage": "S1/S5/S7", "status": "not_executed"},
        {"id": "F05", "name": "任务规则形式", "rule": "采用Skill或代码均满足同一证据契约，关键校验不依赖模型自述", "stage": "S4/S6", "status": "not_executed"},
    ]
    return qc


def build_child_doc(p, qc):
    d = Word(title="基于Pi的医学论文肿瘤视觉特征提取智能体开发计划",
             subject="独立参数前置节点、Pi接入、证据抽取与阶段验收",
             header="医学读片图文数据生成总课题 / 子任务T1 / Pi已选定")
    d.p("肿瘤医学论文视觉特征文本提取智能体", "Title")
    d.p("基于Pi的子任务T1阶段开发计划", "Subtitle")
    d.p(f"版本 {CHILD_VERSION}  日期 {DATE}  Pi基座已确认；应用尚未开发或实测", "Reference")
    d.p("本子任务落实总课题的文献特征来源环节。用户上传公开已发表的肿瘤相关论文PDF，系统提取医学图像中肿瘤视觉特征的原文表述，保留出处、必要上下文和审核状态，为T2提供可追溯证据。")
    d.h("一 已确认的范围与架构")
    for text in p["user_confirmed_changes"]:
        d.bullet(text)
    d.p("总课题以肠癌、肺癌及放射学CT/MRI为起点；T1不设置固定论文、癌种或术语白名单。已有论文及35项特征清单用于启动和评测，不作为穷尽答案。其他影像模态、语言、扫描与混合PDF的首版支持矩阵在S0讨论确定。")
    d.p("T1可独立实施，不依赖两篇候选生成算法论文的身份确认、医学影像数据集下载、MAISI后端或三维生成GPU。首版不包含自动检索论文或链接抓取。")
    d.table(["模块", "实现责任", "交付边界"], MODULE_ROWS[:4] + MODULE_ROWS[-1:], [1800, 3300, 4100])
    d.p("Pi是已选定基座。SDK/RPC、具体发布版本、解析器、LLM、数据库和前端技术仍按阶段决定。Skill用于适合指令封装的任务规则，普通程序负责需要可靠执行的校验、界面和数据处理；不要求每个节点都是智能体或Skill。")
    d.h("二 工作流和配置交接")
    for i, node in enumerate(FLOW["t1_nodes"], 1):
        d.p(f"{i}. {node}")
    d.p("前置参数模块完成默认项逐项告知、增删改、数值与依赖检查及最终确认。Pi接收配置ID、版本、已确认值、确认记录引用和输入文件引用。后端以实际确认记录校验交接，不能把模型输出的confirmed字段当成用户确认。")
    d.p("Pi若发现缺项、冲突或需要改参数，应返回待修改事项，交由前置模块产生新版本并重新确认。正在运行的任务继续绑定原快照；是否停止或重新启动由业务流程明确处理。参数确认与抽取结果审核是两个节点，分别记录。")
    d.p("自然语言结构化可以是独立的前处理服务，按需调用模型产生草稿。进入正式抽取或建模节点的仍是用户确认后的配置。T1的确认是抽取任务配置确认；T2的确认是生成需求确认；两者不要求相同字段。")
    d.h("三 阶段推进与验收")
    d.p("按交付成果推进：未开始 → 开发中 → 提交验收 → 通过；未通过则修正。下一阶段依赖前一阶段的通过证据，不按周或固定工期推进。Pi选型已确认，但源码调研不等于接入原型、医学抽取或阶段验收通过。")
    for s in p["progression"]["stages"]:
        d.p(s["id"] + " " + s["name"], bold=True)
        d.p("前置：" + ("、".join(s["dependencies"]) if s["dependencies"] else "无前置开发阶段") + "。")
        d.p("工作：" + s["work"])
        d.p("交付：" + s["deliverables"])
        d.p("通过条件：" + s["gate"])
    d.p("S1的Pi接入、配置交接和权限接口直接复用于总课题M1/T5。若后续组件或输入范围变化影响已通过成果，补充对应回归；不需要另建一套相同基础设施。详细依赖和工作项见开发任务清单.csv。")
    d.h("四 证据抽取和医学质量要求")
    for text in [
        "保留原始PDF、解析文本版本、原页/文本块/字符映射；跨块原文分段定位。规范化或OCR修复保留到原文的映射，不能覆盖原证据。",
        "原文、译文、模型归纳分别存储。保留癌种或病灶范围、影像模态、序列或期相、否定、不确定性、条件、数值单位及引用归属；肺结节不直接等同于肺癌。",
        "新术语可保留为待分类；冲突来源分别保留；未知、未评估和否定分别表达，不自动补成临床结论。",
        "全文覆盖显式记录应处理页面和文本块；检索或RAG可帮助排序，但只读Top-K片段不能证明全篇抽取完成。处理不完整时报告部分完成及原因。",
        "没有符合目标表述的论文可以是有效输入；仅在范围已完整处理后报告未找到。图表、图注、表头或跨段上下文按约定输入范围评测。",
        "渐进输出的是带定位且可核对的候选；后续上下文可能触发修订并显示版本。模型字符流、首条候选与全文完成分别计时和标识。",
    ]:
        d.bullet(text)
    d.p("评测按癌种、来源、体裁、语言、版式及文本层类型分层；同篇论文的不同版本按论文族关联，避免跨开发和测试混入。人工金标准在明确范围内完整标注相关原文与上下文，不能只核对模型已找到的条目来估计召回。")
    d.p("保留开发集、回归集和独立验收集。报告精确率、召回率、原文定位、医学语境错误、最弱分层及人工修订量；解析失败不能从总体统计中静默删除。具体阈值保持待讨论，不把原有建议数字视为已接受门槛。")
    d.h("五 必要存储、中断与权限")
    d.p("项目负责保存参数与确认版本、已审核证据及已交付文件。解析缓存、运行进度、任务队列与自动续跑仅在具体需求出现时实现；不以Pi必须内置这些能力作为选型条件，也不把pi-durable列为必选依赖。")
    d.p("S5按处理成本和使用方式决定：中断后明确标记并重新运行，或保存进度后续跑。两种方式都必须保证已保存成果可还原、部分结果不冒充完整结果、不重复计入交付。T3日后若存在长时间GPU作业，再按需要增加作业ID和样本计数存储。")
    d.p("S1配置基础工具和文件边界，S5/S7验证实际业务工具与部署。Pi仅访问许可工具、任务文件目录和必要服务；凭证由应用配置，明确挂载和网络范围。权限是否有效由实际拒绝越界调用来验证。")
    d.h("六 性能、部署和交付")
    d.p("逐篇交互采用渐进候选。分别报告上传反馈、首条可审核候选、全文自动完成的P50/P95；拆分解析/OCR、模型、核验及排队耗时。记录冷/热启动、缓存、文档复杂度、并发、CPU/RAM/显存和实际API成本，人工等待另计。")
    d.p("使用者主要在国内，预算暂不约束，允许付费LLM。沿用阿里云ECS/GPU ECS作为部署候选、腾讯CVM作为对照；厂商、地域和规格未选定。先确认瓶颈，再决定是否需要GPU解析服务，不能直接用更大GPU代替网络或模型响应优化。")
    d.p("Docker/Compose交付包含锁定的Pi及工具版本、配置示例、必要存储、健康检查、权限和中断处理说明。明确宿主机、API凭证和可选GPU环境前置条件，再验证其他使用者可重复运行。")
    d.h("七 开源项目与技术选择")
    d.p("Pi已选定；其余项目按实际职责借鉴，不要求全部集成。LangGraph与PydanticAI作为架构或校验思路参考，不再作为并列主基座候选。Star与历史维护信息只作调研记录，不代替医学效果实测。")
    for c in p["open_source_candidates"]:
        d.link(c["repository"] + " — " + c["candidate_role"], c["url"])
        d.p(c["borrow"] + "。边界：" + c["limitations"], "Reference")
    d.h("八 决策、字段与下游接口")
    for x in p["decisions"]:
        d.p(x["id"] + " " + x["topic"] + "（" + x["status"] + "）", bold=True)
        d.p(x["detail"] + "；落实阶段：" + x["decision_stage"] + "。")
        if x["status"] != "confirmed":
            d.p(x["options"], "Reference")
    d.p("沿用28个基础证据字段，extraction_trace增加运行ID、配置版本、Pi版本、模型/解析/任务规则版本与工具记录；只有实际采用Skill时才记录Skill版本。字段数量保持28项，运行元数据作为已有object字段的子项。")
    d.p("候选、自动定位已核对与人工批准分别记录；人工审核模式在S0/S2讨论。已审核证据才进入T2已审核输入，候选导出必须明确状态。T1提供原文和证据，不提前产生已确认数学约束或生成可控性承诺。")
    d.p("最终交付为可运行应用、必要任务规则/Skill与工具、操作说明、版本配置、证据数据、质量性能报告及T2接口。当前开发与性能验证均未开始，没有阶段通过记录。")
    d.h("九 来源与版本")
    d.p("本版替代v0.2；旧材料保存在历史版本/v0.2。当前总计划为v0.4。技术事实沿用已核验Pi提交，具体安装版本在S1确定；旧医学与部署来源见资料来源.json。")
    for src in PI_SOURCES:
        d.link("[" + src["id"] + "] " + src["title"], src["url"])
    return d


def update_requirement_contract(schema, example):
    schema, example = copy.deepcopy(schema), copy.deepcopy(example)
    schema["description"] = "规划阶段结构契约：外置参数确认后可交给Pi建模；生成执行另需编译及能力校验。真实事件、版本与摘要一致性由后端校验，JSON字段本身不构成授权。"
    props = schema["properties"]
    props["schema_version"]["const"] = "0.2"
    props["workflow_status"]["enum"].insert(2, "confirmed_for_agent")
    schema["required"].append("agent_input_ready")
    props["agent_input_ready"] = {"type": "boolean", "description": "仅表达结构状态；后端必须验证真实确认记录才能派发Pi任务。"}
    for rule in schema["allOf"]:
        states = rule["if"]["properties"]["workflow_status"]
        rule["then"]["properties"]["agent_input_ready"] = {"const": states.get("const") == "approved_for_pilot"}
    schema["allOf"].append({
        "if": {"properties": {"workflow_status": {"const": "confirmed_for_agent"}}, "required": ["workflow_status"]},
        "then": {"properties": {
            "is_example": {"const": False}, "agent_input_ready": {"const": True},
            "execution_authorized": {"const": False}, "approval_snapshot": {"type": "object"},
            "requirements": {"items": {"properties": {"review": {"properties": {"state": {"const": "confirmed"}}}}}},
            "distribution_constraints": {"items": {"properties": {"review": {"properties": {"state": {"const": "confirmed"}}}}}},
        }},
    })
    example.update(schema_version="0.2", agent_input_ready=False)
    return schema, example


def advisor_brief():
    return "\n\n".join([
        "老师您好，关于提取医学论文中肿瘤视觉特征表述的子任务，我将开发方案更新为基于Pi智能体框架的应用。",
        "功能：用户逐篇上传公开已发表的肿瘤相关论文PDF，系统提取医学图像中肿瘤视觉特征的原文描述，保留论文身份、页码或文本位置，以及模态、否定、不确定性和适用条件。尽快显示可核对的首批候选，同时继续处理全文并显示进度；用户审核、修订后导出，为后续特征整理与数学建模提供证据。论文、癌种和术语不固定为某几项。",
        "实现：Pi负责模型交互和工具调用。参数确认独立实现，用户逐项处理默认项并确认后，配置版本才交给Pi执行。PDF解析、原文定位、结果校验、审核界面和文件导出可以使用普通程序；适合的抽取规则按需封装为Skill，不要求所有功能都使用Skill。业务存储和权限由项目实现。",
        "整体关系：Pi也作为总课题的智能体层基座，后续接入需求建模、优化生成和筛选工具；医学规则、数学模型和图像生成算法仍由课题开发。T1是总课题的文献证据来源子任务，可以先独立验收。",
        "计划按阶段成果验收推进：范围与验收契约 → Pi接入和参数前置节点 → 评测语料 → PDF解析与证据定位 → 原文抽取及语境核验 → 审核界面与必要存储 → 质量性能验收 → Docker交付及T2衔接。",
        "目前已确定采用Pi和上述模块职责。具体模型、解析器、接入方式和质量性能指标仍需按阶段验证与讨论。希望请您核对上述功能范围与课题衔接是否符合您的预期。",
    ]) + "\n"


def inspect_doc(path):
    with ZipFile(path) as z:
        assert z.testzip() is None
        for n in z.namelist():
            if n.endswith((".xml", ".rels")):
                ET.fromstring(z.read(n))
        doc = ET.fromstring(z.read("word/document.xml"))
        return "\n".join(t.text or "" for t in doc.iter(q("w:t")))


EXTRA_ACCEPTANCE = [
    ["A25", "Pi前置配置", "存在未确认默认项或配置仍为草稿", "前置模块阻止派发正式Pi执行任务；逐项显示待处理状态", "后端派发记录与拒绝原因", "P0"],
    ["A26", "确认与编译分步", "参数已确认但数学模型尚未编译", "可提交Pi建模；不得启动图像生成；模型通过可执行性校验后才进入后继节点", "确认快照与两个节点的状态", "P0"],
    ["A27", "配置版本绑定", "确认后改值、传入旧版本或Pi提出新缺项", "新版本返回前置确认；旧任务输入不被静默改写；旧确认不能授权新值", "配置差异、确认事件与运行版本", "P0"],
    ["A28", "工具权限", "Pi或输入文档诱导访问许可范围外的工具和目录", "业务工具/容器边界阻止调用；许可的解析与抽取功能仍可用", "允许与拒绝调用核验", "P0"],
    ["A29", "Pi集成与事件", "自定义工具返回分批候选及失败页面", "界面区分候选、处理中、部分失败和完整完成；状态来自工具与覆盖记录", "事件轨迹、配置版本与覆盖记录", "P0"],
    ["A30", "交付与中断策略", "容器重启或同一处理请求重试", "按已选重跑/续跑规则处理；参数和已保存成果可还原，不重复计入交付", "Docker操作记录与产物关联", "P0"],
]


def verify_contract(schema, example):
    from jsonschema import Draft202012Validator, FormatChecker
    Draft202012Validator.check_schema(schema)
    v = Draft202012Validator(schema, format_checker=FormatChecker())
    assert not list(v.iter_errors(example))
    confirmed = copy.deepcopy(example)
    confirmed.update(is_example=False, workflow_status="confirmed_for_agent", agent_input_ready=True,
                     execution_authorized=False, blockers=[])
    confirmed["approval_snapshot"] = {"requirement_revision": 1, "canonical_sha256": "a" * 64, "event_id": "unit-test-only-not-a-real-approval"}
    for item in confirmed["requirements"]:
        item["review"].update(state="confirmed", action="confirm", event_id="test-only",
                              confirmed_at="2026-11-01T00:00:00Z")
    # In-memory schema fixture only: never persisted as real user authorization.
    assert not list(v.iter_errors(confirmed)), "Confirmed parameters must allow later compilation"
    bad = copy.deepcopy(confirmed)
    bad["requirements"][0]["review"]["state"] = "pending"
    assert list(v.iter_errors(bad))
    bad = copy.deepcopy(confirmed)
    bad["execution_authorized"] = True
    assert list(v.iter_errors(bad))
    bad = copy.deepcopy(confirmed)
    bad.update(workflow_status="approved_for_pilot", execution_authorized=True)
    assert list(v.iter_errors(bad)), "Unvalidated compiler/capability must block generation"
    bad = copy.deepcopy(example)
    bad["agent_input_ready"] = True
    assert list(v.iter_errors(bad))
    return "draft rejected for dispatch; confirmed input permits modeling; unvalidated generation rejected"


def main():
    current = read_json(CHILD / "开发计划.json")
    if current["version"] != "0.2":
        raise SystemExit("Expected T1 v0.2; inspect the current revision before generating again.")
    hierarchy = read_json(BASE / "任务分解.json")
    assert hierarchy["version"] == "0.3"
    qc = update_quality(read_json(CHILD / "质量与性能验收契约.json"))
    child_sources = read_json(CHILD / "资料来源.json")
    parent_sources = read_json(BASE / "资料与选型核验.json")
    schema, example = update_requirement_contract(read_json(BASE / "需求结构.schema.json"), read_json(BASE / "需求确认示例.json"))
    acceptance = read_csv(BASE / "验收清单.csv")
    for row in acceptance[1:]:
        if row[0] == "A16":
            row[2:5] = ["单次生成失败或进程中断", "按预算和已选重跑/续跑规则处理；不重复计入已导出的样本", "必要任务记录、样本计数及中断处理"]
    acceptance.extend(EXTRA_ACCEPTANCE)
    fields = read_csv(CHILD / "抽取结果字段规范.csv")
    for row in fields[1:]:
        if row[0] == "extraction_trace":
            row[4] = "run_id、配置ID/版本/摘要、Pi版本、模型/解析器/任务规则版本及所读块和工具调用；使用Skill时记录其版本"
            row[5] = "追溯证据到已确认配置和实际处理步骤；不在记录中保存凭证"

    plan = update_child(current)
    stages = [dict(id=sid, name=name, dependencies=deps, owner=owner, work=work, gate=gate,
                   status="not_started", acceptance_record=None)
              for sid, name, deps, owner, work, gate in PARENT_STAGES]
    parent_plan = {
        "version": PARENT_VERSION, "date": DATE, "status": "pi_selected_plan_updated",
        "task": "T0 医学读片大模型图文训练数据生成工具", "current_priority": "T1",
        "confirmed_architecture": CONFIRMED, "selected_agent_base": "earendil-works/pi",
        "agent_integration": copy.deepcopy(plan["architecture"]),
        "module_rows": MODULE_ROWS, "workflow_contract_file": "工作流与模块职责.json",
        "stages": stages, "progression": "stage_acceptance", "stage_acceptances": [],
        "dependency_note": "M3的完整文献路径使用M2成果；医生口述/人工填写路径及接口准备可独立推进。M1共享T1 S1成果。",
        "sources": PI_SOURCES, "acceptance_count": len(acceptance) - 1,
        "still_open": ["Pi SDK/RPC和部署版本", "PDF解析器及LLM", "前端和存储实现", "中断后重跑或恢复", "输入覆盖与审核模式", "质量性能阈值", "云资源与部署地域", "生成器、优化算法和目标训练接口"],
        "implementation_started": False, "benchmarks_run": False,
    }
    parent_backup_files = [BASE / n for n in ["任务分解.json", "验收清单.csv", "需求结构.schema.json", "需求确认示例.json", "资料与选型核验.json", "材料检查结果.json", "毕业设计实施方案_导师审核稿_v0.3.docx"]]
    archive(parent_backup_files, BASE / "历史版本/v0.3")
    archive([p for p in CHILD.iterdir() if p.is_file()], CHILD / "历史版本/v0.2")

    hierarchy.update(version=PARENT_VERSION, updated=DATE,
                     current_parent_plan_file=PARENT_DOC.name, current_parent_plan_data="实施计划.json",
                     selected_agent_base="earendil-works/pi", confirmed_architecture=CONFIRMED,
                     status_note="用户已选定Pi；参数确认是独立前置节点，Skill按需；业务存储和权限由项目负责。总计划与T1按阶段验收，具体组件及质量门槛待对应阶段确定。")
    roles = {
        "T1": "Pi调用解析、抽取及证据核验工具；配置确认、审核界面及必要存储由普通业务模块实现。",
        "T2": "独立结构化草稿与确认模块输出版本快照，Pi据此建模；程序检查单位、函数、能力及可行性，新缺项返回确认。",
        "T3": "Pi调用独立优化/生成程序；算法与GPU服务单独开发；长任务存储与计数按实际需要实现。",
        "T4": "Pi可调用检查和导出工具；业务程序负责图文校验、配额、上限及文件交付。",
        "T5": "共享Pi接口、独立前后端、权限与Docker部署；按阶段验证完整工作流。",
    }
    for t in hierarchy["subtasks"]:
        t.update(agent_base="earendil-works/pi", implementation_responsibility=roles[t["id"]])
        if t["id"] == "T1":
            t.update(plan_version=CHILD_VERSION, planning_status="pi_selected_plan_updated", architecture_frozen=False,
                     agent_base_selected=True, integration_mode_pending=True,
                     plan_file="子任务T1/" + CHILD_DOC.name, current_stage="S0")
    parent_sources.update(version=PARENT_VERSION, architecture_decisions=CONFIRMED, pi_review_commit=COMMIT)
    parent_sources["sources"].extend(PI_SOURCES)
    parent_sources["runtime_status"].update(pi_source_reviewed=True, pi_integration_executed=False)
    child_sources.update(plan_version=CHILD_VERSION, review_type="official_sources_and_user_confirmed_architecture_not_benchmark",
                         repository_candidates=plan["open_source_candidates"], pi_sources=PI_SOURCES)
    child_sources["snapshot_files"].extend(["research/pi_review/snapshot.json", "research/pi_review/source_evidence_manifest.json"])

    for path, data in [
        (BASE / "实施计划.json", parent_plan), (BASE / "工作流与模块职责.json", FLOW),
        (BASE / "任务分解.json", hierarchy), (BASE / "资料与选型核验.json", parent_sources),
        (BASE / "需求结构.schema.json", schema), (BASE / "需求确认示例.json", example),
        (CHILD / "开发计划.json", plan), (CHILD / "质量与性能验收契约.json", qc),
        (CHILD / "资料来源.json", child_sources),
    ]:
        write_json(path, data)
    csv_write(BASE / "验收清单.csv", acceptance)
    csv_write(BASE / "开发阶段与验收.csv", [["阶段", "名称", "前置", "归属", "工作", "通过条件", "状态"]] +
              [[s[k] if k != "dependencies" else ";".join(s[k]) for k in ["id", "name", "dependencies", "owner", "work", "gate", "status"]] for s in stages])
    csv_write(CHILD / "抽取结果字段规范.csv", fields)
    csv_write(CHILD / "开发阶段与验收.csv", [["阶段", "名称", "前置阶段", "工作", "交付物", "通过条件", "未通过处理", "状态"]] +
              [[s["id"], s["name"], ";".join(s["dependencies"]), s["work"], s["deliverables"], s["gate"], s["fail_action"], s["status"]] for s in plan["progression"]["stages"]])
    csv_write(CHILD / "开发任务清单.csv", [["编号", "阶段", "依赖", "工作项", "具体工作", "交付物", "状态"]] +
              [[t[k] for k in ["id", "stage", "dependencies", "name", "work", "deliverable", "status"]] for t in plan["tasks"]])
    csv_write(CHILD / "待讨论实现决策.csv", [["编号", "主题", "状态", "具体内容", "已确认依据", "讨论选项", "确定阶段", "影响"]] +
              [[x[k] for k in ["id", "topic", "status", "detail", "confirmed_basis", "options", "decision_stage", "impact"]] for x in plan["decisions"]])
    csv_write(CHILD / "开源项目调研.csv", [["仓库", "官方链接", "查询时Star", "查询时间UTC", "所在层", "可借鉴内容", "角色", "局限", "许可记录", "已实测", "已选定"]] +
              [[c["repository"], c["url"], c["stars_at_check"] or "未重新查询", c["checked_at"], c["layer"], c["borrow"], c["candidate_role"], c["limitations"], c["license_note"], "否", "是" if c["selected_for_implementation"] else "否"] for c in plan["open_source_candidates"]])
    csv_write(CHILD / "验收清单.csv", [["编号", "名称", "定义", "测量依据", "已约定阈值", "阶段", "状态"]] +
              [[m["id"], m["name"], m["definition"], m["measurement"], "待讨论", m["stage"], "未执行"] for m in qc["metrics"]] +
              [[m["id"], m["name"], m["rule"], "节点、状态与调用记录", "明确规则", m["stage"], "未执行"] for m in qc["functional_invariants"]])
    build_document(document_version=PARENT_VERSION, include_subtask=True,
                   literature_plan_mode="stage_gated", architecture_plan=parent_plan).save(PARENT_DOC)
    build_child_doc(plan, qc).save(CHILD_DOC)
    brief_path = CHILD / "发给导师_功能介绍与Pi实现说明"
    brief_path.with_suffix(".txt").write_text(advisor_brief(), encoding="utf-8")
    brief = Word(title="医学论文肿瘤视觉特征提取功能及Pi实现说明", header="子任务T1 / 导师功能确认稿")
    brief.p("医学论文肿瘤视觉特征提取：功能与Pi实现", "Title")
    for paragraph in advisor_brief().strip().split("\n\n"):
        brief.p(paragraph)
    brief.link("已核验Pi仓库", PI_SOURCES[0]["url"])
    brief.save(brief_path.with_suffix(".docx"))
    for suffix in [".txt", ".docx"]:
        old = CHILD / ("发给导师_功能介绍与两种实现方式确认稿" + suffix)
        assert old.read_bytes() == (CHILD / "历史版本/v0.2" / old.name).read_bytes()
        old.unlink()  # Preserved byte-for-byte in the archived version above.
    write_json(BASE / "当前版本.json", dict(version=PARENT_VERSION, status="pi_selected_plan_updated",
        plan_document=PARENT_DOC.name, plan_data="实施计划.json", task_hierarchy="任务分解.json",
        workflow_contract="工作流与模块职责.json", child_plan_version=CHILD_VERSION,
        child_plan_document="子任务T1/" + CHILD_DOC.name, previous_version="历史版本/v0.3",
        agent_base="earendil-works/pi", implementation_started=False, stage_acceptances=[]))
    write_json(CHILD / "当前版本.json", dict(version=CHILD_VERSION, status="pi_selected_plan_updated",
        plan_document=CHILD_DOC.name, plan_data="开发计划.json", historical_version="历史版本/v0.2",
        agent_base="earendil-works/pi", agent_base_selected=True, architecture_frozen=False,
        quality_thresholds_frozen=False, stage_acceptances=[],
        advisor_brief=brief_path.with_suffix(".docx").name))

    # Verify real cross-artifact relationships, not application behavior.
    seen = set()
    for t in plan["tasks"]:
        assert not t["dependencies"] or t["dependencies"] in seen
        assert t["id"] not in seen
        seen.add(t["id"])
    for stage_list in [plan["progression"]["stages"], stages]:
        seen = set()
        for s in stage_list:
            assert set(s["dependencies"]) <= seen
            seen.add(s["id"])
    for m in qc["metrics"]:
        assert m["agreed_threshold"] is None
    assert not plan["scope"]["automatic_paper_discovery"] and plan["scope"]["fixed_paper_allowlist"] is None
    assert [c["repository"] for c in plan["open_source_candidates"] if c["selected_for_implementation"]] == ["earendil-works/pi"]
    texts = [inspect_doc(p) for p in [PARENT_DOC, CHILD_DOC, brief_path.with_suffix(".docx")]]
    assert all("Pi" in t and "确认" in t for t in texts)
    assert "LangGraph、PydanticAI或轻量状态机" not in texts[1]
    assert "并列竞选主基座" in texts[0]
    assert "四周" not in texts[0] + texts[1]
    assert "pi-durable不是必选依赖" in texts[0]
    assert "confirmed_for_agent" in json.dumps(schema)
    contract_check = verify_contract(schema, example)
    check = dict(status="planning_artifacts_checked_not_application_tested", date=DATE,
        parent_version=PARENT_VERSION, child_version=CHILD_VERSION,
        checks={"archives": "pass", "stage_and_task_dependencies": "pass", "selected_base_consistency": "pass",
                "word_zip_xml": "pass", "unagreed_thresholds_remain_open": "pass", "requirement_contract": contract_check},
        counts={"parent_stages": len(stages), "child_stages": len(STAGES), "child_tasks": len(plan["tasks"]),
                "parent_acceptance_cases": len(acceptance) - 1, "child_metrics": len(qc["metrics"]),
                "child_functional_rules": len(qc["functional_invariants"]), "evidence_fields": len(fields) - 1},
        not_done=["Pi安装和接入测试", "医学论文抽取开发", "质量性能实测", "Word分页视觉预览"])
    write_json(BASE / "材料检查结果.json", check)
    write_json(CHILD / "材料检查结果.json", check)
    print(json.dumps(check, ensure_ascii=False, indent=2))
    print(PARENT_DOC)
    print(CHILD_DOC)


if __name__ == "__main__":
    main()
